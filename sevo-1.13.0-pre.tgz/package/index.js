/**
 * sevo-pipeline — OpenClaw extension plugin.
 * SEVO pipeline auto-advance via L2/L3 hooks.
 *
 * Hooks:
 *   subagent_ended  (priority 200) — detect SEVO task completion, advance pipeline
 *   before_prompt_build (priority 850) — inject next-stage instructions into main session
 *   before_prompt_build (priority 50) — terminal gap check: idle agents + pending work → force advance
 *   before_tool_call (priority 800) — inject sevo label into sessions_spawn
 *
 * Fail-open: all hooks wrapped in try-catch; errors logged, never block dispatch.
 * Graceful degrade: if SEVO dist/ missing, plugin becomes no-op.
 */

import fs from 'fs';
import path from 'path';
import { decode, isSevoLabel, encode } from './label-protocol.js';
import { isAvailable, getPipelineEngine, getLedgerEngine, getRoute, setBridgeConfig, getOrchestrator, getAdapter, getClarificationCoordinator, getWowHarnessFindings, getWowHarnessInjectedFragments } from './bridge.js';
import { buildTaskPrompt as _buildTaskPrompt, getStageMapping, setTaskMapperConfig, extractACsFromSpec, collectArtifactPaths as collectArtifactPathsFromMapper, parseFRTrackingFromArtifacts, discoverAgents, classifyAgent, STAGE_FALLBACK_CHAIN, DEFAULT_PATHS } from './task-mapper.js';
import { normalizePlainObject, resolveConfiguredPath } from './utils.js';
import { injectAllRoleTemplates } from './role-templates.js';
import { handleSevoInit } from './sevo-init.js';

// ─── Stage Prompt Supplements ──────────────────────────────────────────────

const STAGE_PROMPT_SUPPLEMENTS = {
  'publish-generalization-gate': '\n- Documentation-Code Consistency: verify that all command examples in README.md match the actual command regex patterns in the source code. Any syntax mismatch between documented usage and actual parser = P0 blocker.',
  'ux-acceptance': '\n- Stranger Dry-Run Gate (FR-V09 hard gate): simulate a first-time user who has NEVER seen this project. Execute 4-dimension walkthrough:\n  1. clone/install: clone URL correct? deps install with one command? all prerequisites documented?\n  2. first-use: first command documented? runs without error? meaningful result within 5 min?\n  3. core-flow: every documented step executable? no undocumented manual steps? no hardcoded paths?\n  4. error-handling: error messages actionable? recovery steps documented?\n  Any dimension where a stranger cannot complete the step = P0 blocker.\n  P0 in walkthrough report = stage verdict FAIL (hard gate, not advisory).\n  Walkthrough report MUST be written to reports/ directory.',
  'verify': '\n- FR Coverage Gate (终局收敛): 验证完成后，必须逐条对照 spec 中所有 FR，列出每个 FR 的覆盖状态（covered / partial / uncovered）。未覆盖项 > 0 则验证不通过。\n  输出格式：\n  [FR-COVERAGE-START]\n  <FR-ID> | <covered/partial/uncovered> | <evidence or reason>\n  [FR-COVERAGE-END]',
};

function buildTaskPrompt(stageId, ...args) {
  const base = _buildTaskPrompt(stageId, ...args);
  const supplement = STAGE_PROMPT_SUPPLEMENTS[stageId];
  return supplement ? base + supplement : base;
}

// ─── FR-22: Role Navigation ────────────────────────────────────────────────

/**
 * Get the expected (primary) role for a SEVO stage.
 * Derived from STAGE_FALLBACK_CHAIN — the first entry is the expected role.
 */
function getExpectedRole(stageId) {
  const chain = STAGE_FALLBACK_CHAIN[stageId];
  if (!chain || chain.length === 0) return null;
  // First entry in fallback chain is the expected/preferred role
  return chain[0];
}

/**
 * Classify an agent by its id using the pool.
 * Reads openclaw.json agent list and classifies via classifyAgent.
 */
function classifyAgentById(agentId) {
  if (!agentId || agentId === 'main') return 'general';
  try {
    const cfgPath = path.resolve(PLUGIN_DIR, '../../openclaw.json');
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    const agentList = cfg?.agents?.list || [];
    const entry = agentList.find(e => e.id === agentId);
    if (entry) return classifyAgent(entry);
  } catch { /* fail-open */ }
  return 'general';
}

/**
 * Find agents matching a given role from the current pool.
 * Returns array of agentIds sorted by pool priority.
 */
function findAgentsByRole(role) {
  const pool = sevoGlobal.agentPool || discoverAgents();
  return pool[role] || [];
}

/**
 * Check role match and produce navigation suggestion if mismatched.
 * Returns null if role matches, or a navigation object if mismatched.
 */
function checkRoleNavigation(stageId, targetAgentId) {
  const expectedRole = getExpectedRole(stageId);
  if (!expectedRole) return null; // unknown stage, no navigation

  const actualRole = classifyAgentById(targetAgentId);

  // Match: exact role match, or 'general' agents are always acceptable
  if (actualRole === expectedRole || actualRole === 'general') return null;

  // Find agents that match the expected role
  const suggestedAgents = findAgentsByRole(expectedRole);

  return {
    stageId,
    expectedRole,
    actualRole,
    targetAgentId,
    suggestedAgents,
    suggestion: suggestedAgents.length > 0
      ? `当前阶段 "${stageId}" 期望角色 ${expectedRole}，建议派发给 ${suggestedAgents[0]}（${expectedRole}）`
      : `当前阶段 "${stageId}" 期望角色 ${expectedRole}，但未发现匹配角色的 agent`,
  };
}

/**
 * Sort agent list by role relevance for a given stage.
 * Agents matching the expected role come first, preserving original order within groups.
 */
function sortAgentsByStageRelevance(stageId, agentIds) {
  const expectedRole = getExpectedRole(stageId);
  if (!expectedRole) return agentIds;

  // Read openclaw.json once, classify all agents from the cached list
  let agentList = [];
  try {
    const cfgPath = path.resolve(PLUGIN_DIR, '../../openclaw.json');
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    agentList = cfg?.agents?.list || [];
  } catch { /* fail-open: fall back to per-agent classification */ }

  const matching = [];
  const nonMatching = [];

  for (const id of agentIds) {
    let role;
    if (agentList.length > 0) {
      const entry = agentList.find(e => e.id === id);
      role = entry ? classifyAgent(entry) : 'general';
    } else {
      role = classifyAgentById(id);
    }
    if (role === expectedRole) {
      matching.push(id);
    } else {
      nonMatching.push(id);
    }
  }

  return [...matching, ...nonMatching];
}

// ─── Constants ─────────────────────────────────────────────

const SEVO_VERSION = '0.4.1';
const PLUGIN_ID = 'sevo-pipeline';
const PLUGIN_DIR = path.dirname(new URL(import.meta.url).pathname);
const STATE_DIR = path.join(PLUGIN_DIR, 'state');
const ACTIVE_PIPELINES_PATH = path.join(STATE_DIR, 'active-pipelines.json');
const DEFAULT_WORKSPACE_ROOT = path.resolve(PLUGIN_DIR, '../../workspace');
const DEFAULT_EVENTS_PATH = path.join(DEFAULT_WORKSPACE_ROOT, 'logs', 'sevo-pipeline-events.jsonl');

// ─── FR-D06: Error Code Definition ─────────────────────────────────────────────

const SEVO_ERRORS = {
  'SEVO-E001': { desc: 'No coding agent available', cause: 'All coding agents are busy or not configured', fix: 'Wait for running tasks to complete, or add more agents in openclaw.json' },
  'SEVO-E002': { desc: 'Spec file not found', cause: 'The spec stage did not produce a spec file', fix: 'Check the spec task output and retry: sevo:retry <id> spec' },
  'SEVO-E003': { desc: 'Stage gate failed', cause: 'Review found P0 blocking issues', fix: 'Fix the P0 issues and retry: sevo:retry <id> <stage>' },
  'SEVO-E004': { desc: 'Task timeout', cause: 'Agent task exceeded timeout limit', fix: 'Increase timeout or split the task into smaller pieces' },
  'SEVO-E005': { desc: 'Pipeline state corrupted', cause: 'active-pipelines.json is unreadable or malformed', fix: 'Check file permissions and JSON syntax' },
  'SEVO-E006': { desc: 'Agent task failed', cause: 'The dispatched agent returned an error', fix: 'Check agent logs and retry: sevo:retry <id> <stage>' },
  'SEVO-E007': { desc: 'Hook registration missing', cause: 'SEVO hooks not registered in openclaw.json', fix: 'Run init.sh to re-register hooks' },
  'SEVO-E008': { desc: 'Project directory creation failed', cause: 'Cannot create projects/<slug>/ directory', fix: 'Check disk space and directory permissions' },
};

function formatError(code, context = {}) {
  const err = SEVO_ERRORS[code];
  if (!err) return `Unknown error: ${code}`;
  let msg = `❌ ${code}: ${err.desc}\n`;
  msg += `   Cause: ${err.cause}\n`;
  msg += `   Fix: ${err.fix}`;
  if (context.stage) msg += `\n   Stage: ${context.stage}`;
  if (context.pipelineId) msg += `\n   Pipeline: ${context.pipelineId}`;
  if (context.error) msg += `\n   Error: ${context.error}`;
  return msg;
}

// Tier upgrade chain: T4 → T2 → T1 → null (ceiling, no further upgrade)
const TIER_UPGRADE_MAP = { 'T4': 'T2', 'T2': 'T1', 'T1': null };

// Agent resolution for upgrade chain: tier → preferred agentId (null = auto-assign)
const TIER_DEFAULT_AGENT = { 'T2': 'codex', 'T1': 'cc' };

// ─── AC Coverage Parsing ───

const AC_COVERAGE_BLOCK_RE = /\[AC-COVERAGE-START\]\s*\n([\s\S]*?)\[AC-COVERAGE-END\]/i;
const AC_COVERAGE_LINE_RE = /^\s*(AC[-_]?[A-Z0-9][-A-Z0-9_.]*?)\s*\|\s*(covered|partial|uncovered)\s*\|\s*(.*)$/i;

// ─── Long Document & Artifact Verification Constants ───
const LONG_DOC_STAGES = new Set(['spec', 'contract', 'review']);
const LONG_DOC_MIN_LINES = 150;

/**
 * Parse AC coverage checklist from subagent output.
 * Returns { found: boolean, items: [{ id, status, detail }], uncovered: [...], partial: [...] }
 */
function parseACCoverageChecklist(output) {
  const result = { found: false, items: [], uncovered: [], partial: [] };
  if (typeof output !== 'string') return result;

  const blockMatch = output.match(AC_COVERAGE_BLOCK_RE);
  if (!blockMatch) return result;

  result.found = true;
  const body = blockMatch[1];

  for (const line of body.split('\n')) {
    const m = line.match(AC_COVERAGE_LINE_RE);
    if (!m) continue;
    const item = { id: m[1].trim(), status: m[2].trim().toLowerCase(), detail: m[3].trim() };
    result.items.push(item);
    if (item.status === 'uncovered') result.uncovered.push(item);
    if (item.status === 'partial') result.partial.push(item);
  }

  return result;
}

/**
 * Build a supplement task prompt for uncovered/partial ACs.
 */
function buildACSupplementPrompt(pipelineId, projectSlug, uncoveredACs, partialACs, artifactPaths) {
  const lines = [
    `[SEVO AC Supplement] Pipeline ${pipelineId} (${projectSlug})`,
    '',
    'The previous implementation left some Acceptance Criteria uncovered or partially covered.',
    'Implement the following ACs:',
    '',
  ];

  for (const ac of uncoveredACs) {
    lines.push(`- [UNCOVERED] ${ac.id}: ${ac.detail || '(no detail)'}`);
  }
  for (const ac of partialACs) {
    lines.push(`- [PARTIAL] ${ac.id}: ${ac.detail || '(no detail)'}`);
  }

  const specRef = artifactPaths['spec'];
  if (specRef && specRef.length > 0) {
    lines.push('', `Spec reference: ${specRef.join(', ')}`);
  }
  const contractRef = artifactPaths['contract'];
  if (contractRef && contractRef.length > 0) {
    lines.push(`Architecture reference: ${contractRef.join(', ')}`);
  }

  lines.push('', 'After implementation, output the AC coverage checklist in the same format:');
  lines.push('[AC-COVERAGE-START]');
  lines.push('<AC-ID> | <covered/partial/uncovered> | <location or reason>');
  lines.push('[AC-COVERAGE-END]');

  return lines.join('\n');
}

// ─── FR-O15: FR-Level Tracking Helpers ───

const FR_TRACKING_STAGES = new Set(['implement', 'review', 'smoke-test', 'e2e-verification', 'regression']);

function loadFRTracking(pipelineId) {
  const active = loadActivePipelines();
  return active.pipelines?.[pipelineId]?.frTracking || null;
}

function saveFRTracking(pipelineId, frTracking) {
  const active = loadActivePipelines();
  if (!active.pipelines?.[pipelineId]) return;
  active.pipelines[pipelineId].frTracking = frTracking;
  saveActivePipelines(active);
}

function initFRTracking(pipelineId, pipelineState) {
  const artifactPaths = collectArtifactPathsFromMapper(pipelineState);
  const tracking = parseFRTrackingFromArtifacts(artifactPaths);
  if (tracking.total.length === 0) return null;
  saveFRTracking(pipelineId, {
    total: tracking.total,
    completed: tracking.completed,
    remaining: tracking.remaining,
    lastUpdatedAt: nowIso(),
  });
  return tracking;
}

function refreshFRTracking(pipelineId, pipelineState) {
  const artifactPaths = collectArtifactPathsFromMapper(pipelineState);
  const fresh = parseFRTrackingFromArtifacts(artifactPaths);
  if (fresh.total.length === 0) return null;
  const tracking = {
    total: fresh.total,
    completed: fresh.completed,
    remaining: fresh.remaining,
    lastUpdatedAt: nowIso(),
  };
  saveFRTracking(pipelineId, tracking);
  return tracking;
}

function isFRTrackingComplete(frTracking) {
  return frTracking && frTracking.remaining.length === 0;
}

// ─── FR-D09: Convergence Loop Helpers ───

function initConvergenceLoop(pipelineId, projectGoal) {
  const active = loadActivePipelines();
  if (!active.pipelines?.[pipelineId]) return;
  active.pipelines[pipelineId].convergenceLoop = {
    enabled: true,
    maxIterations: CONVERGENCE_MAX_ITERATIONS,
    currentIteration: 0,
    projectGoal: projectGoal || '',
    lastGapReport: null,
  };
  saveActivePipelines(active);
}

function getConvergenceLoop(pipelineId) {
  const active = loadActivePipelines();
  return active.pipelines?.[pipelineId]?.convergenceLoop || null;
}

function updateConvergenceLoop(pipelineId, updates) {
  const active = loadActivePipelines();
  if (!active.pipelines?.[pipelineId]?.convergenceLoop) return;
  Object.assign(active.pipelines[pipelineId].convergenceLoop, updates);
  saveActivePipelines(active);
}

function shouldTriggerConvergence(stageId, pipelineId) {
  const active = loadActivePipelines();
  const pipeline = active.pipelines?.[pipelineId];
  if (!pipeline?.convergenceLoop?.enabled) return false;
  const tier = pipeline.tier || 3;
  if (tier === 3 && stageId === CONVERGENCE_TRIGGER_TIER3) return true;
  if (tier === 2 && stageId === CONVERGENCE_TRIGGER_TIER2) return true;
  return false;
}

function parseConvergenceGapReport(reportPath) {
  try {
    const content = fs.readFileSync(reportPath, 'utf8');
    const p0p1Matches = content.match(CONVERGENCE_GAP_P0P1_RE) || [];
    return { hasP0P1: p0p1Matches.length > 0, p0p1Count: p0p1Matches.length, reportPath };
  } catch {
    return { hasP0P1: false, p0p1Count: 0, reportPath };
  }
}

// ─── Terminal Gap Scan (终局差距扫描) ───

async function runTerminalGapScan(pipelineId) {
  const engine = await getPipelineEngine();
  if (!engine) return null;
  const state = engine.load(pipelineId);
  if (!state) return null;

  const frTracking = refreshFRTracking(pipelineId, state);
  if (!frTracking || frTracking.total.length === 0) {
    return { allCovered: true, uncoveredFRs: [], total: 0, covered: 0, round: 0, maxRounds: CONVERGENCE_MAX_ITERATIONS };
  }

  const uncovered = frTracking.remaining || [];
  const allCovered = uncovered.length === 0;

  const active = loadActivePipelines();
  const pipeline = active.pipelines?.[pipelineId];
  if (!pipeline) return null;

  if (!pipeline.terminalConvergence) {
    pipeline.terminalConvergence = { rounds: 0, maxRounds: CONVERGENCE_MAX_ITERATIONS, history: [] };
  }
  const tc = pipeline.terminalConvergence;

  if (!allCovered) tc.rounds += 1;
  tc.history.push({ round: tc.rounds, uncoveredFRs: [...uncovered], timestamp: nowIso() });
  tc.lastUncoveredFRs = uncovered;
  saveActivePipelines(active);

  appendEvent({
    type: 'sevo_terminal_gap_scan',
    pipelineId,
    round: tc.rounds,
    totalFRs: frTracking.total.length,
    coveredFRs: frTracking.completed.length,
    uncoveredFRs: uncovered,
    allCovered,
  });

  return { allCovered, uncoveredFRs: uncovered, total: frTracking.total.length, covered: frTracking.completed.length, round: tc.rounds, maxRounds: tc.maxRounds };
}

function buildTerminalGapFixPrompt(pipelineId, projectSlug, scanResult) {
  const lines = [
    `[SEVO Terminal Gap Fix] Pipeline ${pipelineId} (${projectSlug})`,
    '',
    `终局差距扫描（第 ${scanResult.round}/${scanResult.maxRounds} 轮）发现以下 FR 未覆盖：`,
    '',
    ...scanResult.uncoveredFRs.map(fr => `- ${fr}`),
    '',
    `总计 ${scanResult.total} 个 FR，已覆盖 ${scanResult.covered} 个，未覆盖 ${scanResult.uncoveredFRs.length} 个。`,
    '',
    '请实现以上未覆盖的 FR。完成后输出 AC coverage checklist：',
    '[AC-COVERAGE-START]',
    '<AC-ID> | <covered/partial/uncovered> | <location or reason>',
    '[AC-COVERAGE-END]',
  ];
  return lines.join('\n');
}

const SEVO_PIPELINE_GLOBAL_KEY = Symbol.for('openclaw.sevo-pipeline.instance');
const sevoGlobal = globalThis[SEVO_PIPELINE_GLOBAL_KEY] || (globalThis[SEVO_PIPELINE_GLOBAL_KEY] = {
  registeredLogged: false,
  degraded: false,
  runtimeConfig: null,
  pendingAdvances: new Map(),
  pendingNotices: [],
  pendingSupplements: new Map(),
  pendingClarifications: new Map(),
  clarificationCoordinator: null,
  activeStageTimers: new Map(),
  failureHistory: new Map(),
  reviewFixLoops: new Map(),
});

// ─── Helpers ───

function nowIso() { return new Date().toISOString(); }

function ensureDir(filePath) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function readPluginStateConfig() {
  try {
    return normalizePlainObject(JSON.parse(fs.readFileSync(path.join(STATE_DIR, 'config.json'), 'utf8')));
  } catch {
    return {};
  }
}

function resolvePluginConfig(api) {
  const pluginConfig = normalizePlainObject(api?.config);
  const stateConfig = readPluginStateConfig();
  const merged = { ...stateConfig, ...pluginConfig };
  const workspaceRoot = resolveConfiguredPath(
    PLUGIN_DIR,
    merged.workspaceRoot ?? process.env.OPENCLAW_WORKSPACE_ROOT,
    DEFAULT_WORKSPACE_ROOT,
  );
  const eventsPath = resolveConfiguredPath(
    workspaceRoot,
    merged.eventsPath ?? process.env.OPENCLAW_SEVO_EVENTS_PATH,
    path.join(workspaceRoot, 'logs', 'sevo-pipeline-events.jsonl'),
  );

  return {
    ...merged,
    workspaceRoot,
    eventsPath,
    paths: { ...DEFAULT_PATHS, ...normalizePlainObject(merged.paths) },
  };
}

function getEventsPath() {
  return sevoGlobal.runtimeConfig?.eventsPath || DEFAULT_EVENTS_PATH;
}

function extractLabelCandidate(value) {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (isSevoLabel(trimmed)) return trimmed;
    const markerMatch = trimmed.match(/Label \(required\):\s*(sevo:[^\s\n]+)/);
    if (markerMatch?.[1] && decode(markerMatch[1])) return markerMatch[1];
    return null;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      const candidate = extractLabelCandidate(item);
      if (candidate) return candidate;
    }
    return null;
  }

  if (value && typeof value === 'object') {
    for (const key of ['label', 'prompt', 'taskDescription', 'task', 'message', 'messages', 'input', 'description']) {
      if (key in value) {
        const candidate = extractLabelCandidate(value[key]);
        if (candidate) return candidate;
      }
    }
  }

  return null;
}

function getPendingAdvanceByLabel(label) {
  const parsed = decode(label);
  if (!parsed) return null;

  const pipelineId = resolvePipelineId(parsed.projectSlug);
  if (!pipelineId) return null;

  const entries = sevoGlobal.pendingAdvances.get(pipelineId) || [];
  return entries.find(entry => entry.label === label) || null;
}

// ─── FR-S01: SEVO Pipeline Trigger Evaluation (LLM-based) ───

// ─── FR-D02: Quickstart Stages ─────────────────────────────────────────────
const QUICKSTART_STAGES = ['spec', 'spec-review-gate', 'implement', 'review', 'smoke-test', 'verify', 'ledger'];

// ─── FR-D08: Tier-2 Lightweight Pipeline Stages ────────────────────────────
const TIER2_STAGES = ['spec', 'implement', 'review', 'verify', 'ledger'];

// ─── FR-D09: Convergence Loop Constants ─────────────────────────────────────
const CONVERGENCE_MAX_ITERATIONS = 3;
const CONVERGENCE_TRIGGER_TIER3 = 'publish-generalization-gate';
const CONVERGENCE_TRIGGER_TIER2 = 'review';
const CONVERGENCE_STAGE_ID = 'convergence-gap-analysis';
const CONVERGENCE_GAP_P0P1_RE = /\[P[01]\]/gm;

// (V1 evaluateSevoTrigger removed — keyword matching permanently retired)

// ─── FR-S01-L2: SEVO Intercept Mode (env-controlled) ───────────────────────
const SEVO_INTERCEPT_MODE = (process.env.SEVO_INTERCEPT_MODE || 'block').toLowerCase();

// ─── Deterministic Path-Match Interception (2026-05-18) ─────────────────────
// Bypasses LLM judgment entirely. If task text contains tracked project source
// paths or build commands targeting tracked projects, block unconditionally.
// This layer is NOT subject to exemption rules (hotfix/infra/doc exemptions
// do NOT apply when source paths are explicitly referenced).

const DETERMINISTIC_BUILD_COMMANDS = [
  /npm\s+run\s+build/i,
  /npx\s+tsc/i,
  /npx\s+next\s+build/i,
  /npx\s+webpack/i,
  /npx\s+vite\s+build/i,
  /npm\s+run\s+compile/i,
  /npm\s+run\s+dist/i,
];

// Read-only intent patterns — if the ENTIRE task is clearly read-only, skip deterministic block
const DETERMINISTIC_READONLY_PATTERNS = [
  /^(?:查询|查看|读取|read|检查|check|列出|list|获取|get|确认|verify status|cat |head |tail |ls |grep |wc |审计|audit|review|分析|analysis)/i,
  /^(?:status|状态|日志|log|排查|diagnose|debug|调试)/i,
];

// Cache for tracked projects (refreshed every 60s)
let _trackedProjectsCache = null;
let _trackedProjectsCacheTime = 0;
const TRACKED_PROJECTS_CACHE_TTL = 60000;

/**
 * Load tracked projects from sevo.json files in each project directory.
 * Returns array of { slug, sourceRoots, projectPath }.
 */
function loadTrackedProjects() {
  const now = Date.now();
  if (_trackedProjectsCache && (now - _trackedProjectsCacheTime) < TRACKED_PROJECTS_CACHE_TTL) {
    return _trackedProjectsCache;
  }
  const wsRoot = process.env.OPENCLAW_WORKSPACE || '/root/.openclaw/workspace';
  const projectsDir = path.join(wsRoot, 'projects');
  const tracked = [];
  try {
    const dirs = fs.readdirSync(projectsDir, { withFileTypes: true });
    for (const d of dirs) {
      if (!d.isDirectory()) continue;
      const sevoJsonPath = path.join(projectsDir, d.name, 'sevo.json');
      try {
        const sevoConfig = JSON.parse(fs.readFileSync(sevoJsonPath, 'utf8'));
        const sourceRoots = Array.isArray(sevoConfig.sourceRoots) ? sevoConfig.sourceRoots : ['src'];
        tracked.push({
          slug: d.name,
          sourceRoots,
          projectPath: `projects/${d.name}`,
        });
      } catch { /* no sevo.json or invalid — skip */ }
    }
  } catch { /* projects dir unreadable */ }
  _trackedProjectsCache = tracked;
  _trackedProjectsCacheTime = now;
  return tracked;
}

/**
 * Deterministic path-match interception.
 * Returns { shouldBlock, reason, slug } or null if no match.
 */
function deterministicPathIntercept(taskText) {
  if (typeof taskText !== 'string' || taskText.length < 10) return null;

  // Check if the task is purely read-only (no code changes implied)
  const firstLine = taskText.split('\n')[0].trim();
  for (const pat of DETERMINISTIC_READONLY_PATTERNS) {
    if (pat.test(firstLine)) return null;
  }

  const tracked = loadTrackedProjects();
  if (tracked.length === 0) return null;

  // Build path patterns for each tracked project
  for (const proj of tracked) {
    for (const root of proj.sourceRoots) {
      // Match patterns like: projects/kivo/src/, projects/sevo/src/
      const pathPattern = `projects/${proj.slug}/${root}/`;
      const pathPatternAlt = `projects/${proj.slug}/${root}\\`; // Windows-style (unlikely but safe)

      if (taskText.includes(pathPattern) || taskText.includes(pathPatternAlt)) {
        // Source path found — check if it's a write/modify context (not just a read reference)
        // We block unless the task is clearly just reading/querying
        const readOnlyVerbs = /(?:^|\n)\s*(?:读取?|read|cat|head|tail|grep|查看|检查|check|审计|audit|review)\s/i;
        const writeVerbs = /(?:修改|改|写入|write|edit|create|新增|add|implement|实现|fix|修复|重构|refactor|update|更新|删除|delete|remove|移除)/i;

        // If write verbs present OR no read-only verbs dominate, block
        if (writeVerbs.test(taskText) || !readOnlyVerbs.test(taskText)) {
          return {
            shouldBlock: true,
            reason: `task references tracked source path "${pathPattern}"`,
            slug: proj.slug,
            matchType: 'source-path',
          };
        }
      }
    }

    // Also check for build commands targeting this project
    const projectMention = taskText.includes(`projects/${proj.slug}`) ||
      taskText.includes(proj.slug + '/') ||
      new RegExp(`\\b${proj.slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(taskText);

    if (projectMention) {
      for (const cmdPat of DETERMINISTIC_BUILD_COMMANDS) {
        if (cmdPat.test(taskText)) {
          return {
            shouldBlock: true,
            reason: `task contains build command targeting tracked project "${proj.slug}"`,
            slug: proj.slug,
            matchType: 'build-command',
          };
        }
      }
    }
  }

  return null;
}

// ─── FR-S01-L2: LLM Semantic Trigger Evaluation ────────────────────────────
// Keyword matching permanently retired. All trigger decisions go through LLM.

const LLM_TRIGGER_TIMEOUT_MS = 15000;

const LLM_TRIGGER_SYSTEM_PROMPT = `You are a SEVO Pipeline Guard. Your job is to evaluate whether a task description should trigger the SEVO software engineering pipeline.

Evaluate the task against these trigger conditions:

- Level 2+ triggers (MUST trigger pipeline):
  1. Any task that involves creating or modifying code files (regardless of size)
  2. Building a new module or system from scratch
  3. Changes spanning two or more domain boundaries
  4. Data model / schema changes
  5. Changes to governance rules, scheduling logic, or quality gates

- Level 1+ triggers (SHOULD trigger pipeline):
  6. Changes to release targets or delivery methods
  7. Modifications to an existing product requirements spec (add/modify/delete FR or AC)

- Level 0 (no pipeline needed):
  8. Single-line typo fixes in non-logic code (comments, strings only)
  9. Config file value changes (not structure changes)

- No trigger at all:
  10. Queries, chat, config checks, status lookups, research, audits, reviews — anything that doesn't involve code file changes

Respond with ONLY a JSON object (no markdown, no explanation outside JSON):
{"shouldTrigger": true/false, "level": 0/1/2, "matchedConditions": ["condition descriptions"], "reasoning": "brief explanation"}

If the task clearly does not involve code changes, set shouldTrigger=false and level=0.`;

/**
 * Read LLM provider config from openclaw.json.
 * Priority: penguin-main > openai (chat-capable).
 * Returns { baseUrl, apiKey, model } or null.
 */
function readLLMConfig() {
  try {
    const cfgPath = path.resolve(PLUGIN_DIR, '../../openclaw.json');
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    const providers = cfg?.models?.providers || {};

    // Priority 1: penguin-main
    const penguinMain = providers['penguin-main'];
    if (penguinMain?.apiKey && penguinMain?.baseUrl) {
      const chatModel = (penguinMain.models || []).find(m =>
        m.id && !m.id.includes('thinking') && !m.id.includes('image')
      );
      return {
        baseUrl: penguinMain.baseUrl.replace(/\/+$/, ''),
        apiKey: penguinMain.apiKey,
        model: chatModel?.id || 'claude-opus-4-6',
      };
    }

    // Priority 2: openai provider (if it has chat models)
    const openaiProvider = providers['openai'];
    if (openaiProvider?.apiKey && openaiProvider?.baseUrl) {
      const chatModel = (openaiProvider.models || []).find(m =>
        m.id && !m.id.includes('image')
      );
      if (chatModel) {
        return {
          baseUrl: openaiProvider.baseUrl.replace(/\/+$/, ''),
          apiKey: openaiProvider.apiKey,
          model: chatModel.id,
        };
      }
    }

    return null;
  } catch {
    return null;
  }
}

// ─── Shared LLM Classification Utilities ────────────────────────────────────

class SevoLRUCache {
  constructor(maxSize = 64) {
    this._max = maxSize;
    this._map = new Map();
  }
  get(key) {
    if (!this._map.has(key)) return undefined;
    const val = this._map.get(key);
    this._map.delete(key);
    this._map.set(key, val);
    return val;
  }
  set(key, val) {
    if (this._map.has(key)) this._map.delete(key);
    this._map.set(key, val);
    if (this._map.size > this._max) {
      const oldest = this._map.keys().next().value;
      this._map.delete(oldest);
    }
  }
}

const _sevoClassificationCache = new SevoLRUCache(64);

/**
 * Generic LLM classification call with timeout, caching, and fallback.
 * @param {string} systemPrompt - System prompt for classification
 * @param {string} userMessage - User message to classify
 * @param {string} cacheKey - Cache key (null to skip cache)
 * @param {*} fallbackValue - Value to return on failure
 * @param {number} timeoutMs - Timeout in ms (default 10000)
 * @returns {Promise<string>} - Raw LLM response content
 */
async function callLlmClassification(systemPrompt, userMessage, cacheKey, fallbackValue, timeoutMs = 10000) {
  if (cacheKey) {
    const cached = _sevoClassificationCache.get(cacheKey);
    if (cached !== undefined) return cached;
  }

  const llmConfig = readLLMConfig();
  if (!llmConfig) return fallbackValue;

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    const base = llmConfig.baseUrl;
    const chatUrl = base.endsWith('/v1') || base.includes('/v1/')
      ? `${base}/chat/completions`
      : `${base}/v1/chat/completions`;

    const response = await fetch(chatUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${llmConfig.apiKey}`,
      },
      body: JSON.stringify({
        model: llmConfig.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage },
        ],
        max_tokens: 300,
        temperature: 0,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!response.ok) return fallbackValue;

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content || '';
    const result = content.trim();

    if (cacheKey && result) {
      _sevoClassificationCache.set(cacheKey, result);
    }

    return result || fallbackValue;
  } catch {
    return fallbackValue;
  }
}

/**
 * LLM-based SEVO trigger evaluation.
 * Calls the configured LLM to semantically judge whether a task needs the SEVO pipeline.
 * Degrades to pass-through (no block) on timeout/error.
 *
 * @param {string} taskText - The task description
 * @param {string} label - The task label (if any)
 * @returns {Promise<{shouldTrigger: boolean, level: number, matchedConditions: string[], reasoning: string, source: string}>}
 */
async function llmTriggerCheck(taskText, label) {
  const fallbackResult = {
    shouldTrigger: false,
    level: 0,
    matchedConditions: [],
    reasoning: 'LLM unavailable — fallback to pass-through',
    source: 'fallback',
  };

  if (typeof taskText !== 'string' || taskText.length < 10) {
    return { ...fallbackResult, reasoning: 'task text too short to evaluate', source: 'skip' };
  }

  const llmConfig = readLLMConfig();
  if (!llmConfig) {
    appendInterceptEvent({
      type: 'sevo_llm_trigger',
      decision: 'fallback',
      reason: 'llm-unavailable: no provider configured',
      taskTextPreview: taskText.slice(0, 200),
    });
    return { ...fallbackResult, reasoning: 'no LLM provider configured', source: 'fallback' };
  }

  const userMessage = `Task label: ${label || '(none)'}\n\nTask description:\n${taskText.slice(0, 3000)}`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), LLM_TRIGGER_TIMEOUT_MS);

    // Construct the chat completions URL, handling baseUrl with or without /v1
    const base = llmConfig.baseUrl;
    const chatUrl = base.endsWith('/v1') || base.includes('/v1/')
      ? `${base}/chat/completions`
      : `${base}/v1/chat/completions`;

    const response = await fetch(chatUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${llmConfig.apiKey}`,
      },
      body: JSON.stringify({
        model: llmConfig.model,
        messages: [
          { role: 'system', content: LLM_TRIGGER_SYSTEM_PROMPT },
          { role: 'user', content: userMessage },
        ],
        max_tokens: 500,
        temperature: 0,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      const errText = await response.text().catch(() => 'unknown');
      appendInterceptEvent({
        type: 'sevo_llm_trigger',
        decision: 'fallback',
        reason: `llm-unavailable: HTTP ${response.status}`,
        errorDetail: errText.slice(0, 300),
        taskTextPreview: taskText.slice(0, 200),
      });
      return { ...fallbackResult, reasoning: `LLM HTTP ${response.status}`, source: 'fallback' };
    }

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content || '';

    // Parse JSON from LLM response (handle possible markdown wrapping)
    const jsonStr = content.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
    const parsed = JSON.parse(jsonStr);

    const result = {
      shouldTrigger: !!parsed.shouldTrigger,
      level: typeof parsed.level === 'number' ? parsed.level : 0,
      matchedConditions: Array.isArray(parsed.matchedConditions) ? parsed.matchedConditions : [],
      reasoning: String(parsed.reasoning || ''),
      source: 'llm',
    };

    appendInterceptEvent({
      type: 'sevo_llm_trigger',
      decision: result.shouldTrigger ? 'trigger' : 'pass',
      level: result.level,
      matchedConditions: result.matchedConditions,
      reasoning: result.reasoning,
      model: llmConfig.model,
      taskTextPreview: taskText.slice(0, 200),
      label: label || null,
    });

    return result;
  } catch (err) {
    const isTimeout = err?.name === 'AbortError';
    appendInterceptEvent({
      type: 'sevo_llm_trigger',
      decision: 'fallback',
      reason: isTimeout ? 'llm-timeout' : `llm-error: ${String(err?.message || err).slice(0, 200)}`,
      taskTextPreview: taskText.slice(0, 200),
    });
    return {
      ...fallbackResult,
      reasoning: isTimeout ? 'LLM call timed out (15s)' : `LLM error: ${String(err?.message || err).slice(0, 100)}`,
      source: 'fallback',
    };
  }
}

// ─── FR-S01-L2: Keyword Fallback Trigger (when LLM unavailable) ──────────

const KEYWORD_GROUPS_L2 = [
  {
    group: 'new-module',
    patterns: [
      /(?:新建|创建|初始化).{0,20}(?:模块|系统|服务|项目|包|库|组件|微服务)/i,
      /(?:from\s+scratch|new\s+(?:module|system|service|project|package|component))/i,
      /(?:bootstrap|scaffold)/i,
      /从零开始/i,
      /全新(?:模块|系统|服务|项目)/i,
    ],
  },
  {
    group: 'cross-domain',
    patterns: [
      /跨(?:域|模块|服务|系统)/i,
      /(?:cross[\-_]?(?:domain|module|service|system)|multi[\-_]?domain)/i,
      /涉及多个(?:域|模块|服务)的?边界/i,
    ],
  },
  {
    group: 'large-scale',
    patterns: [
      /(?:重构|重写|重新设计|大改|全面改造)/i,
      /(?:refactor|rewrite|redesign|overhaul)/i,
      /(?:500\s*行以上|10\s*个文件以上|大规模)/i,
      /(?:large[\-_]?scale|massive\s+(?:change|refactor|rewrite))/i,
    ],
  },
  {
    group: 'data-model',
    patterns: [
      /(?:schema|migration|数据模型|表结构|字段变更|数据库迁移)/i,
      /(?:ALTER\s+TABLE|CREATE\s+TABLE|DROP\s+TABLE)/i,
      /(?:新增|删除|修改)\s*字段(?:类型)?/i,
      /(?:ORM|entity|model)\s*(?:定义)?\s*变更/i,
      /(?:database\s+migration|schema\s+change)/i,
    ],
  },
  {
    group: 'governance',
    patterns: [
      /(?:门禁|gate|guard|pipeline|流水线|质量规则)/i,
      /(?:调度逻辑|编排|routing|dispatch)/i,
      /(?:权限|认证|授权|access\s*control|auth(?:entication|orization))/i,
      /(?:quality\s+gate|ci[\/_]cd\s+pipeline)/i,
    ],
  },
];

const KEYWORD_GROUPS_L1 = [
  {
    group: 'spec-change',
    patterns: [
      /(?:spec|需求|FR|AC|需求规格|product[\-_]?requirements)/i,
      /(?:新增|修改|删除)\s*需求/i,
      /(?:功能需求|验收标准)/i,
      /(?:requirement\s+(?:change|update|add|remove|modify))/i,
    ],
  },
  {
    group: 'release',
    patterns: [
      /(?:发布|publish|release|deploy|上线)/i,
      /(?:npm\s+publish|git\s+tag|version\s+bump)/i,
      /(?:发版|部署|go\s+live)/i,
    ],
  },
  {
    group: 'medium-change',
    patterns: [
      /(?:新增功能|feature|新特性)/i,
      /(?:API|接口|endpoint)\s*变更/i,
      /(?:配置变更|config\s+change)/i,
      /(?:new\s+feature|add\s+(?:feature|capability|endpoint|api))/i,
      /(?:add\s+.{0,20}(?:endpoint|api|route))/i,
      /(?:api\s+(?:change|breaking|migration))/i,
    ],
  },
];

const KEYWORD_GROUPS_L0 = [
  {
    group: 'bugfix',
    patterns: [
      /(?:bug\s*fix|修复|hotfix|patch)/i,
      /(?:fix\s+(?:bug|issue|error|crash))/i,
    ],
  },
  {
    group: 'trivial',
    patterns: [
      /(?:typo|拼写|格式化|lint|formatting)/i,
      /(?:注释|文档更新|README|changelog)/i,
      /(?:配置调整|env|环境变量)/i,
      /(?:依赖更新|upgrade\s+dependency|bump\s+dep)/i,
    ],
  },
];

const KEYWORD_GROUPS_NO_TRIGGER = [
  {
    group: 'query',
    patterns: [
      /^(?:查询|搜索|分析|调研|报告|查看|检查|列出|获取)/i,
      /^(?:search|query|analyze|research|report|check|list|get|fetch|inspect)/i,
    ],
  },
  {
    group: 'chat',
    patterns: [
      /^(?:聊天|讨论|问答|请问|帮我看|你觉得)/i,
      /^(?:chat|discuss|question|what\s+(?:is|are|do)|how\s+(?:to|do|does))/i,
    ],
  },
  {
    group: 'status-check',
    patterns: [
      /(?:状态检查|健康检查|监控|status\s+check|health\s*check|monitor)/i,
    ],
  },
];

/**
 * Keyword-based fallback trigger evaluation.
 * Only called when LLM is unavailable/timed out.
 *
 * @param {string} taskText
 * @param {string} label
 * @returns {{ shouldTrigger: boolean, level: number, matchedPatterns: string[], source: string, reasoning: string }}
 */
function keywordFallbackCheck(taskText, label) {
  const combined = `${label || ''} ${taskText || ''}`;
  const result = {
    shouldTrigger: false,
    level: 0,
    matchedPatterns: [],
    matchedConditions: [],
    reasoning: '',
    source: 'keyword-fallback',
  };

  if (typeof taskText !== 'string' || taskText.length < 5) {
    result.reasoning = 'task text too short for keyword fallback';
    return result;
  }

  // Check no-trigger patterns first (early exit)
  for (const grp of KEYWORD_GROUPS_NO_TRIGGER) {
    for (const pat of grp.patterns) {
      if (pat.test(combined)) {
        result.reasoning = `matched no-trigger group: ${grp.group}`;
        return result;
      }
    }
  }

  let highestLevel = -1;

  // Check L0 (no trigger)
  for (const grp of KEYWORD_GROUPS_L0) {
    for (const pat of grp.patterns) {
      if (pat.test(combined)) {
        if (highestLevel < 0) highestLevel = 0;
        result.matchedPatterns.push(`L0:${grp.group}`);
      }
    }
  }

  // Check L1
  for (const grp of KEYWORD_GROUPS_L1) {
    for (const pat of grp.patterns) {
      if (pat.test(combined)) {
        if (highestLevel < 1) highestLevel = 1;
        result.matchedPatterns.push(`L1:${grp.group}`);
      }
    }
  }

  // Check L2
  for (const grp of KEYWORD_GROUPS_L2) {
    for (const pat of grp.patterns) {
      if (pat.test(combined)) {
        if (highestLevel < 2) highestLevel = 2;
        result.matchedPatterns.push(`L2:${grp.group}`);
      }
    }
  }

  if (highestLevel >= 1) {
    result.shouldTrigger = true;
    result.level = highestLevel;
    result.matchedConditions = result.matchedPatterns.filter(p => !p.startsWith('L0:'));
    result.reasoning = `keyword fallback: matched ${result.matchedPatterns.join(', ')}`;
  } else if (highestLevel === 0) {
    result.shouldTrigger = false;
    result.level = 0;
    result.reasoning = `keyword fallback: only L0 matches (${result.matchedPatterns.join(', ')}), no trigger`;
  } else {
    result.reasoning = 'keyword fallback: no patterns matched';
  }

  return result;
}

// ─── FR-S01-L2: Exemption Rules (Whitelist) ───────────────────────────────
const SEVO_EXEMPTION_RULES = [
  {
    ruleId: 'exempt.audit',
    promptPatterns: [/审计|audit|review|质量检查|code review|安全审查|security review/i],
    labelPatterns: [/^(?:audit|review|code-review|security-review)(?:[_\-]|$)/i],
    description: 'Audit/review tasks are exempt from SEVO',
  },
  {
    ruleId: 'exempt.research',
    promptPatterns: [/调研|research|分析|analysis|对比|compare|评测|benchmark|舆情|竞品/i],
    labelPatterns: [/^(?:research|analysis|report|survey)(?:[_\-]|$)/i],
    description: 'Research/analysis tasks are exempt from SEVO',
  },
  {
    ruleId: 'exempt.query',
    promptPatterns: [/^(?:查询|查看|status|状态|读取|read|检查|check|列出|list|获取|get|确认|verify status)/i],
    description: 'Simple query tasks are exempt from SEVO',
  },
  {
    ruleId: 'exempt.hotfix',
    promptPatterns: [/P0\s*fix|P0\s*修复|hotfix|紧急修复|urgent fix|emergency/i],
    labelPatterns: [/^(?:hotfix|p0-fix|emergency)(?:[_\-]|$)/i],
    description: 'Emergency/hotfix tasks (P0 fix) are exempt from SEVO',
  },
  {
    ruleId: 'exempt.sevo_internal',
    labelPatterns: [/^sevo[_\-]/i],
    description: 'SEVO internal tasks are exempt (already in pipeline)',
  },
  {
    ruleId: 'exempt.infra',
    promptPatterns: [/插件维护|plugin maintenance|watchdog|gateway.*维护|基础设施|infrastructure|配置修复|config fix/i],
    labelPatterns: [/^(?:plugin-maint|watchdog|gateway-maint|infra|maintenance)(?:[_\-]|$)/i],
    description: 'Infrastructure maintenance tasks are exempt from SEVO',
  },
  {
    ruleId: 'exempt.doc_only',
    promptPatterns: [/^(?:更新文档|update doc|写.*README|write.*CHANGELOG|纯文档|doc.only|文档更新)/i],
    labelPatterns: [/^(?:doc-update|readme-update|changelog)(?:[_\-]|$)/i],
    description: 'Pure documentation tasks are exempt from SEVO',
  },
];

function checkSevoExemption(taskText, agentId, label) {
  for (const rule of SEVO_EXEMPTION_RULES) {
    if (rule.promptPatterns) {
      for (const pat of rule.promptPatterns) {
        if (pat.test(taskText)) return rule;
      }
    }
    if (rule.labelPatterns && label) {
      for (const pat of rule.labelPatterns) {
        if (pat.test(label)) return rule;
      }
    }
  }
  // [REMOVED 2026-05-14] exempt: manual prefix bypass deleted.
  // Reason: main session abused this to bypass SEVO when user explicitly required pipeline.
  // Automatic category exemptions (audit, research, query, hotfix, infra, doc) remain.
  // For R&D tasks that need to skip early stages, use from:<stage> instead.
  return null;
}

function inferProjectSlug(taskText) {
  // Dynamic matching: check registered pipeline slugs first
  try {
    const active = loadActivePipelines();
    const registeredSlugs = Object.values(active.pipelines || {}).map(p => p.projectSlug).filter(Boolean);
    for (const slug of registeredSlugs) {
      // Match slug as a word boundary in task text (case-insensitive)
      const escaped = slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(`\\b${escaped}\\b`, 'i');
      if (re.test(taskText)) return slug;
    }
  } catch { /* fall through to static list */ }

  // Static fallback for projects not yet registered as pipelines
  const projectMatch = taskText.match(/(?:KIVO|SEVO|GBrain|Claw Design|AEO|ACO|Cortex)/i);
  if (projectMatch) return projectMatch[0].toLowerCase().replace(/\s+/g, '-');
  return null;
}

// ─── FR-S01-L2: Intercept Audit Log ───────────────────────────────────────
const SEVO_INTERCEPT_LOG_PATH = path.join(
  process.env.OPENCLAW_WORKSPACE || '/root/.openclaw/workspace',
  'logs', 'sevo-intercept-events.jsonl'
);

function appendInterceptEvent(event) {
  try {
    const dir = path.dirname(SEVO_INTERCEPT_LOG_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(SEVO_INTERCEPT_LOG_PATH, JSON.stringify({ timestamp: nowIso(), ...event }) + '\n');
  } catch { /* fail-open */ }
}

// ─── FR-D08: Pipeline Scale Routing (Tier Evaluation) ──────────────────────

const TIER_EVAL_SYSTEM_PROMPT = `You are a task complexity classifier for a software development pipeline.
Classify the task into exactly one tier:
- Tier 1: Trivial changes (config toggle, status check, single-file hotfix, query)
- Tier 2: Small-to-medium features (local change, script, single module, <10 files)
- Tier 3: Large/complex work (new product/module, cross-domain, scaffold, >10 files, full system)

Respond with ONLY a JSON object: {"tier": <1|2|3>, "reason": "<brief explanation>"}`;

/**
 * Evaluate task complexity tier using LLM semantic classification.
 * Falls back to tier 2 (safe default) on LLM failure.
 */
async function evaluateTier(taskText, scope) {
  if (typeof taskText !== 'string') return { tier: 3, reason: 'default: non-string input' };

  // Structured data shortcut: if scope explicitly marks new module, no LLM needed
  if (scope?.isNewModule) {
    return { tier: 3, reason: 'scope.isNewModule is true' };
  }

  const cacheKey = `tier:${taskText.slice(0, 500)}`;
  const fallback = { tier: 2, reason: 'default: LLM unavailable, assuming medium complexity' };

  const result = await callLlmClassification(
    TIER_EVAL_SYSTEM_PROMPT,
    taskText.slice(0, 2000),
    cacheKey,
    null,
    10000,
  );

  if (!result) return fallback;

  try {
    const jsonStr = result.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
    const parsed = JSON.parse(jsonStr);
    const tier = [1, 2, 3].includes(parsed.tier) ? parsed.tier : 2;
    return { tier, reason: String(parsed.reason || 'LLM classification') };
  } catch {
    return fallback;
  }
}

// ─── FR-E05: Long Document Segmentation Detection ───

// Heuristic fallback keywords — only used when LLM is unavailable
const LONG_DOC_KEYWORDS_FALLBACK = /(?:spec|arc42|设计文档|深度报告|architecture|product.requirements|需求规格)/i;
const LONG_DOC_HEAVY_FALLBACK = /(?:arc42|完整架构|full architecture|完整需求|full spec|深度报告|comprehensive)/i;

const LLM_LONG_DOC_SYSTEM_PROMPT = `You are a document-size estimator. Given a task description, determine:
1. Whether the task will produce a long document (>300 lines or >15KB).
2. Your estimated line count (null if uncertain).

Respond with JSON only: {"isLong": boolean, "estimatedLines": number|null, "reasoning": "string"}

Examples of long documents: full specs, arc42 architecture docs, comprehensive design docs, deep research reports.
Examples of short documents: code reviews, bug fixes, config changes, simple scripts.`;

async function detectLongDocument(taskText) {
  if (typeof taskText !== 'string') return { isLong: false };

  // Priority 1: Explicit estimatedLines declaration in task prompt
  const lineMatch = taskText.match(/(?:预估|estimate|~|约|approx|estimatedLines\s*[:=])\s*(\d+)\s*(?:行|lines?)?/i);
  if (lineMatch && parseInt(lineMatch[1], 10) > 300) {
    return { isLong: true, estimatedLines: parseInt(lineMatch[1], 10), source: 'explicit-declaration' };
  }

  // Priority 2: LLM semantic judgment
  try {
    const llmConfig = readLLMConfig();
    if (llmConfig) {
      const base = llmConfig.baseUrl;
      const chatUrl = base.endsWith('/v1') || base.includes('/v1/')
        ? `${base}/chat/completions`
        : `${base}/v1/chat/completions`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(chatUrl, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${llmConfig.apiKey}` },
        body: JSON.stringify({
          model: llmConfig.model,
          messages: [
            { role: 'system', content: LLM_LONG_DOC_SYSTEM_PROMPT },
            { role: 'user', content: taskText.slice(0, 2000) },
          ],
          temperature: 0,
          max_tokens: 200,
        }),
      });
      clearTimeout(timeout);

      if (response.ok) {
        const data = await response.json();
        const text = data?.choices?.[0]?.message?.content || '';
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          return {
            isLong: !!parsed.isLong,
            estimatedLines: parsed.estimatedLines ?? null,
            source: 'llm',
          };
        }
      }
    }
  } catch { /* LLM unavailable, fall through to heuristic fallback */ }

  // Priority 3: Heuristic fallback (keyword-based, lower confidence)
  if (!LONG_DOC_KEYWORDS_FALLBACK.test(taskText)) return { isLong: false, source: 'fallback' };
  if (LONG_DOC_HEAVY_FALLBACK.test(taskText)) return { isLong: true, estimatedLines: null, source: 'fallback-heuristic' };

  return { isLong: false, source: 'fallback' };
}

function findSevoLabelFromSpawnParams(params) {
  if (!params || typeof params !== 'object') return null;

  const direct = extractLabelCandidate(params.label);
  if (direct) return direct;

  for (const key of ['prompt', 'taskDescription', 'task', 'message', 'messages', 'input']) {
    const candidate = extractLabelCandidate(params[key]);
    if (candidate) return candidate;
  }

  return null;
}

function appendEvent(event) {
  try {
    const eventsPath = getEventsPath();
    ensureDir(eventsPath);
    fs.appendFileSync(eventsPath, JSON.stringify({ timestamp: nowIso(), ...event }) + '\n');
  } catch { /* fail-open */ }
}

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    // P1-1 fix: if file exists but JSON is corrupt, backup before returning fallback
    if (err instanceof SyntaxError && fs.existsSync(filePath)) {
      const ts = Date.now();
      const backupPath = `${filePath}.corrupt.${ts}`;
      try { fs.copyFileSync(filePath, backupPath); } catch { /* best-effort */ }
      appendEvent({ type: 'sevo_state_corrupt_backup', filePath, backupPath });
    }
    return fallback;
  }
}

function writeJson(filePath, data) {
  ensureDir(filePath);
  const tmp = filePath + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n');
  fs.renameSync(tmp, filePath);
}

const PIPELINES_LOCK_PATH = path.join(STATE_DIR, '.pipelines.lock');

function withFileLock(lockPath, fn) {
  const MAX_RETRIES = 5;
  const RETRY_DELAY_MS = 100;
  let acquired = false;
  for (let i = 0; i < MAX_RETRIES; i++) {
    try {
      fs.writeFileSync(lockPath, String(process.pid), { flag: 'wx' });
      acquired = true;
      break;
    } catch {
      if (i < MAX_RETRIES - 1) {
        const start = Date.now();
        while (Date.now() - start < RETRY_DELAY_MS) { /* spin wait */ }
      }
    }
  }
  if (!acquired) {
    appendEvent({ type: 'sevo_lock_timeout', lockPath, pid: process.pid });
  }
  try {
    return fn();
  } finally {
    if (acquired) {
      try { fs.unlinkSync(lockPath); } catch { /* best-effort */ }
    }
  }
}

function loadActivePipelines() {
  return readJson(ACTIVE_PIPELINES_PATH, { pipelines: {} });
}

function saveActivePipelines(data) {
  withFileLock(PIPELINES_LOCK_PATH, () => writeJson(ACTIVE_PIPELINES_PATH, data));
}

// ─── FR-D05 AC3: State Schema Migration ───

const CURRENT_SCHEMA_VERSION = 2;

function migrateState(state) {
  if (!state || typeof state !== 'object') return state;
  const v = state.schemaVersion || 1;
  if (v >= CURRENT_SCHEMA_VERSION) return state;

  // v1 → v2: add frTracking defaults to each pipeline entry
  if (v < 2) {
    const pipelines = state.pipelines || {};
    for (const pid of Object.keys(pipelines)) {
      if (!pipelines[pid].frTracking) {
        pipelines[pid].frTracking = { total: [], completed: [], remaining: [], lastUpdatedAt: null };
      }
    }
  }

  state.schemaVersion = CURRENT_SCHEMA_VERSION;
  return state;
}

function loadActivePipelinesWithMigration() {
  const data = loadActivePipelines();
  const before = data.schemaVersion || 1;
  const migrated = migrateState(data);
  if (migrated.schemaVersion !== before) {
    saveActivePipelines(migrated);
    appendEvent({ type: 'sevo_state_migrated', from: before, to: migrated.schemaVersion });
  }
  return migrated;
}

function getProjectSlug(pipelineId) {
  const active = loadActivePipelines();
  return active.pipelines?.[pipelineId]?.projectSlug || 'unknown';
}

/**
 * Resolve a projectSlug back to the active pipelineId (UUID).
 * Returns the UUID string or null if no active pipeline matches.
 */
function resolvePipelineId(projectSlug) {
  if (!projectSlug) return null;
  const active = loadActivePipelines();
  for (const [pid, info] of Object.entries(active.pipelines || {})) {
    if (info.projectSlug === projectSlug) return pid;
  }
  return null;
}

function getProjectRoot(pipelineId) {
  const active = loadActivePipelines();
  return active.pipelines?.[pipelineId]?.projectRoot || null;
}

function getProjectDir(pipelineId) {
  const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
  const projectSlug = getProjectSlug(pipelineId);
  const projectRoot = getProjectRoot(pipelineId) || `projects/${projectSlug}`;
  return path.resolve(wsRoot, projectRoot);
}

function isPublishStage(stageId) {
  return typeof stageId === 'string' && (stageId === 'publish' || stageId.startsWith('publish'));
}

function collectSourceFiles(dirPath, acc = []) {
  if (!fs.existsSync(dirPath)) return acc;

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      collectSourceFiles(fullPath, acc);
      continue;
    }
    if (entry.isFile() && /\.(?:js|ts)$/i.test(entry.name)) {
      acc.push(fullPath);
    }
  }

  return acc;
}

function evaluateCommercializationGate(projectDir) {
  try {
    const checks = [];
    const packageJsonPath = path.join(projectDir, 'package.json');
    const readmePath = path.join(projectDir, 'README.md');
    const srcDir = path.join(projectDir, 'src');

    let pkg = null;
    if (fs.existsSync(packageJsonPath)) {
      pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
    }

    const requiredFields = ['name', 'version', 'description', 'main', 'license'];
    const missingFields = pkg
      ? requiredFields.filter((field) => typeof pkg[field] !== 'string' || !pkg[field].trim())
      : requiredFields;
    checks.push({
      id: 'package-json-required-fields',
      status: missingFields.length === 0 ? 'passed' : 'failed',
      detail: missingFields.length === 0
        ? 'package.json exists and required fields are complete.'
        : `Missing required package.json fields: ${missingFields.join(', ')}`,
    });

    let readmeSize = 0;
    if (fs.existsSync(readmePath)) {
      readmeSize = fs.statSync(readmePath).size;
    }
    checks.push({
      id: 'readme-size',
      status: readmeSize > 500 ? 'passed' : 'failed',
      detail: readmeSize > 500
        ? `README.md exists (${readmeSize} bytes).`
        : (readmeSize > 0 ? `README.md too small (${readmeSize} bytes).` : 'README.md missing.'),
    });

    const sourceFiles = collectSourceFiles(srcDir);
    const annotationPattern = /(?:TODO|FIXME|HACK)/;
    const flaggedAnnotations = [];
    for (const filePath of sourceFiles) {
      const content = fs.readFileSync(filePath, 'utf8');
      const matchedLine = content.split('\n').find((line) => annotationPattern.test(line));
      if (matchedLine) {
        flaggedAnnotations.push(`${path.relative(projectDir, filePath)}: ${matchedLine.trim().slice(0, 160)}`);
      }
    }
    checks.push({
      id: 'source-annotations',
      status: flaggedAnnotations.length === 0 ? 'passed' : 'failed',
      detail: flaggedAnnotations.length === 0
        ? `No TODO/FIXME/HACK markers found in ${sourceFiles.length} src JS/TS files.`
        : `Found TODO/FIXME/HACK markers: ${flaggedAnnotations.slice(0, 5).join(' | ')}`,
    });

    const buildScript = typeof pkg?.scripts?.build === 'string' ? pkg.scripts.build.trim() : '';
    checks.push({
      id: 'build-script',
      status: buildScript ? 'passed' : 'failed',
      detail: buildScript ? `Build script present: ${buildScript}` : 'Missing package.json scripts.build entry.',
    });

    const hasMain = typeof pkg?.main === 'string' && pkg.main.trim().length > 0;
    const hasBin = typeof pkg?.bin === 'string'
      ? pkg.bin.trim().length > 0
      : !!(pkg?.bin && typeof pkg.bin === 'object' && Object.keys(pkg.bin).length > 0);
    checks.push({
      id: 'package-entrypoint',
      status: hasMain || hasBin ? 'passed' : 'failed',
      detail: hasMain || hasBin
        ? `Entrypoint present via ${hasBin ? 'bin' : 'main'}.`
        : 'Missing both package.json main and bin entrypoints.',
    });

    const failedChecks = checks.filter((check) => check.status === 'failed');
    const status = failedChecks.length === 0 ? 'passed' : 'rejected';
    const summary = failedChecks.length === 0
      ? 'Commercialization gate passed: package metadata, docs, entrypoint, build script, and source hygiene checks all passed.'
      : `Commercialization gate rejected: ${failedChecks.length}/${checks.length} checks failed (${failedChecks.map((check) => check.id).join(', ')}).`;

    return { status, checks, summary };
  } catch (err) {
    return {
      status: 'conditional',
      checks: [{
        id: 'commercialization-gate-evaluation',
        status: 'conditional',
        detail: `Evaluation error: ${String(err?.message || err)}`,
      }],
      summary: `Commercialization gate degraded to conditional due to evaluation error: ${String(err?.message || err)}`,
    };
  }
}

function formatCommercializationGateResult(result, projectDir) {
  const lines = [
    '[Commercialization Gate Precheck]',
    `Project dir: ${projectDir}`,
    `Status: ${result.status}`,
    `Summary: ${result.summary}`,
    'Checks:',
  ];

  for (const check of result?.checks || []) {
    lines.push(`- ${check.id} | ${check.status} | ${check.detail}`);
  }

  lines.push('Use this precheck as publish-stage context. Fail-open note: conditional may be caused by evaluation errors, not necessarily project defects.');
  return lines.join('\n');
}

// FR-D02 AC5: Build completion artifact list message
function buildCompletionMessage(pipelineId, projectSlug) {
  const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
  const projectRoot = getProjectRoot(pipelineId) || `projects/${projectSlug}`;
  const absRoot = path.resolve(wsRoot, projectRoot);
  const lines = [
    `🎉 Pipeline ${projectSlug} completed!`,
    'Artifacts:',
    `  - Spec: ${projectRoot}/docs/design/spec.md`,
    `  - Code: ${projectRoot}/src/`,
    `  - Review: ${projectRoot}/reports/review.md`,
  ];
  try {
    const progress = loadProgress();
    const prog = progress.pipelines?.[pipelineId];
    if (prog?.stages) {
      const startAt = prog.stages[0]?.startedAt;
      const endAt = prog.stages[prog.stages.length - 1]?.completedAt;
      if (startAt && endAt) {
        const diffMs = new Date(endAt) - new Date(startAt);
        const diffMin = Math.round(diffMs / 60000);
        if (diffMin > 0) lines.push(`Total time: ~${diffMin} minutes`);
      }
    }
  } catch { /* fail-open */ }
  if (sevoGlobal.agentPool?._isSingleAgent) {
    lines.push('');
    lines.push('⚠ Single-Agent Mode: quality assurance level reduced.');
    lines.push('  Dimensions not independently verified: security, boundary compliance, spec consistency.');
    lines.push('  Consider multi-agent re-review for production use.');
  }
  return lines.join('\n');
}

/**
 * Parse gate verdict from subagent event.
 *
 * Checks two sources:
 *   1. Pre-computed verdict (from gate-engine evaluate()) in evt.result
 *   2. Raw review bundles — aggregated following verdict-aggregator.ts logic
 *
 * Returns null for non-gate stages (no review data).
 */
function parseGateVerdict(evt) {
  const result = evt?.result || evt?.output;

  // 1. Pre-computed verdict from gate-engine
  if (result?.conclusion && ['passed', 'conditional', 'rejected'].includes(result.conclusion)) {
    return {
      conclusion: result.conclusion,
      blockers: Array.isArray(result.blockers) ? result.blockers : [],
      reviewBundles: Array.isArray(result.reviewBundles) ? result.reviewBundles : [],
    };
  }

  // 2. Raw review bundles — aggregate per verdict-aggregator.ts rules:
  //    any MUST failure → rejected; only SHOULD failures → conditional; else → passed
  const bundles = evt?.reviewBundles || result?.reviewBundles;
  if (!Array.isArray(bundles) || bundles.length === 0) return null;

  let hasMustFailure = false;
  let hasShouldFailure = false;
  const blockers = [];

  for (const bundle of bundles) {
    if (bundle.conclusion === 'passed') continue;
    const priority = bundle.priority || 'MUST';
    for (const issue of (bundle.issues || [])) {
      blockers.push({
        item: typeof issue === 'string' ? issue : (issue.item || issue.message || String(issue)),
        owner: bundle.reviewer || bundle.role || 'unknown',
      });
    }
    if (priority === 'MUST') {
      hasMustFailure = true;
    } else {
      hasShouldFailure = true;
    }
  }

  const conclusion = hasMustFailure ? 'rejected'
    : hasShouldFailure ? 'conditional'
    : 'passed';

  return { conclusion, blockers, reviewBundles: bundles };
}

/**
 * Safe wrapper — all hook handlers go through this.
 * Errors are logged but never propagated.
 */
function safeSevoHook(hookName, handler) {
  return (...args) => {
    try {
      const result = handler(...args);
      // If handler is async, catch Promise rejections
      if (result && typeof result.catch === 'function') {
        return result.catch(err => {
          appendEvent({
            type: 'sevo_hook_error',
            hook: hookName,
            error: String(err?.message || err),
            stack: String(err?.stack || '').slice(0, 500),
          });
          return null;
        });
      }
      return result;
    } catch (err) {
      appendEvent({
        type: 'sevo_hook_error',
        hook: hookName,
        error: String(err?.message || err),
        stack: String(err?.stack || '').slice(0, 500),
      });
      return null;
    }
  };
}

/**
 * Consume all pending advance notices (called by before_prompt_build).
 */
function consumePendingAdvances() {
  const all = [];
  for (const [pipelineId, stages] of sevoGlobal.pendingAdvances.entries()) {
    for (const s of stages) {
      all.push({ pipelineId, ...s });
    }
  }
  sevoGlobal.pendingAdvances.clear();

  const notices = [...sevoGlobal.pendingNotices];
  sevoGlobal.pendingNotices.length = 0;

  return { advances: all, notices };
}

// ─── Stage Timeout Helpers ───

function startStageTimer(pipelineId, stageId, timeoutMs, agentId, label) {
  sevoGlobal.activeStageTimers.set(
    `${pipelineId}::${stageId}`,
    { pipelineId, stageId, startTime: Date.now(), timeoutMs, agentId, label },
  );
}

function clearStageTimer(pipelineId, stageId) {
  sevoGlobal.activeStageTimers.delete(`${pipelineId}::${stageId}`);
}

function checkExpiredTimers() {
  const now = Date.now();
  const expired = [];
  for (const [key, timer] of sevoGlobal.activeStageTimers.entries()) {
    if (now - timer.startTime >= timer.timeoutMs) {
      expired.push(timer);
      sevoGlobal.activeStageTimers.delete(key);
    }
  }
  return expired;
}

// ─── Clarification Bridge Helpers ───

const CLARIFICATION_MARKER_RE = /\[SEVO[_-]CLARIF(?:ICATION)?[_-](?:REQUEST|NEEDED)]\s*\n([\s\S]*?)(?:\[\/SEVO|$)/i;
const CLARIFICATION_RESPONSE_RE = /\[SEVO[_-]CLARIF(?:ICATION)?[_-]RESPONSE]\s*#(\S+)\s*\n([\s\S]*?)(?:\[\/SEVO|$)/i;

async function ensureClarificationCoordinator() {
  if (sevoGlobal.clarificationCoordinator) return sevoGlobal.clarificationCoordinator;

  const clarMod = await getClarificationCoordinator();
  if (!clarMod?.ClarificationCoordinator) return null;

  sevoGlobal.clarificationCoordinator = new clarMod.ClarificationCoordinator({
    getStageRecord: async (stageId) => {
      try {
        const eng = await getPipelineEngine();
        if (!eng) return undefined;
        const active = loadActivePipelines();
        for (const pid of Object.keys(active.pipelines || {})) {
          const state = eng.load(pid);
          if (state?.stages?.[stageId]) return state.stages[stageId];
        }
      } catch { /* fail-open */ }
      return undefined;
    },
    updateStageRecord: async (stageId, updater) => {
      try {
        const eng = await getPipelineEngine();
        if (!eng) return undefined;
        const active = loadActivePipelines();
        for (const pid of Object.keys(active.pipelines || {})) {
          const state = eng.load(pid);
          if (state?.stages?.[stageId]) {
            const updated = updater(state.stages[stageId]);
            state.stages[stageId] = updated;
            eng.save(pid, state);
            return updated;
          }
        }
      } catch { /* fail-open */ }
      return undefined;
    },
  });

  return sevoGlobal.clarificationCoordinator;
}

function detectClarificationRequest(evt) {
  const output = evt?.output || evt?.result?.output || evt?.result?.message || '';
  if (typeof output !== 'string') return null;

  const match = output.match(CLARIFICATION_MARKER_RE);
  if (!match) return null;

  const body = match[1].trim();
  // Parse questions — each line starting with "- " or "Q:" or numbered
  const questions = [];
  for (const line of body.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const cleaned = trimmed.replace(/^(?:\d+[.)]\s*|-\s*|Q:\s*)/i, '').trim();
    if (cleaned.length > 5) {
      questions.push(cleaned);
    }
  }

  if (questions.length === 0) return null;

  return {
    questions,
    rawBody: body,
    blockingLevel: /block(?:ing)?/i.test(body) ? 'blocking' : 'advisory',
  };
}

function detectClarificationResponse(message) {
  if (typeof message !== 'string') return null;
  const match = message.match(CLARIFICATION_RESPONSE_RE);
  if (!match) return null;
  return {
    clarificationId: match[1].trim(),
    content: match[2].trim(),
  };
}

function consumePendingClarifications() {
  const items = [];
  for (const [clarId, entry] of sevoGlobal.pendingClarifications.entries()) {
    items.push({ clarificationId: clarId, ...entry });
  }
  // Don't clear — keep until resolved
  return items;
}

// ─── Review-Fix Loop (RFL) Helpers ───

const MAX_RFL_ROUNDS = 3;
const REVIEW_STAGE_IDS = new Set([
  'review', 'spec-review-gate', 'contract-review-gate',
  'publish-generalization-gate', 'verify',
]);
const RFL_FIX_RE = /^(.+)-rfl-fix-(\d+)$/;
const RFL_REVAL_RE = /^(.+)-rfl-reval-(\d+)$/;

function isReviewStage(sid) { return REVIEW_STAGE_IDS.has(sid); }

function parseRflStage(sid) {
  let m = sid.match(RFL_FIX_RE);
  if (m) return { type: 'fix', origin: m[1], round: +m[2] };
  m = sid.match(RFL_REVAL_RE);
  if (m) return { type: 'reval', origin: m[1], round: +m[2] };
  return null;
}

const SEVERITY_SYSTEM_PROMPT = `You classify the severity of a code review blocker issue.
Respond with ONLY one of: P0, P1, P2, P3

Guidelines:
- P0: Critical/security issues, data loss, system crash, spec violation that blocks release
- P1: Important issues that should be fixed before release but aren't critical
- P2: Minor issues, style problems, non-blocking improvements
- P3: Trivial, cosmetic, nice-to-have`;

async function classifyBlockerSeverity(blocker) {
  const text = (blocker.item || '').trim();
  if (!text) return 'P1';

  const cacheKey = `severity:${text.slice(0, 200)}`;
  const fallbackSeverity = 'P1'; // conservative default

  const result = await callLlmClassification(
    SEVERITY_SYSTEM_PROMPT,
    text.slice(0, 500),
    cacheKey,
    fallbackSeverity,
    10000,
  );

  const normalized = (result || '').trim().toUpperCase();
  if (['P0', 'P1', 'P2', 'P3'].includes(normalized)) return normalized;
  // Try to extract from response
  const match = normalized.match(/\b(P[0-3])\b/);
  if (match) return match[1];
  return fallbackSeverity;
}

function buildFixPrompt(pipelineId, projectSlug, reviewStageId, issues, round) {
  const lines = [
    `[SEVO Review-Fix Loop] Pipeline ${pipelineId} (${projectSlug})`,
    `Round ${round}/${MAX_RFL_ROUNDS} — Fix P0/P1 issues from "${reviewStageId}"`,
    '',
    'Issues to fix:',
  ];
  for (const issue of issues) {
    lines.push(`- [${issue.severity}] ${issue.item} (reporter: ${issue.owner})`);
  }
  lines.push('', 'Fix all listed issues. Commit with descriptive messages.');
  lines.push('After fixing, the review will re-run automatically.');
  return lines.join('\n');
}

function buildRevalPrompt(pipelineId, projectSlug, reviewStageId, round) {
  return [
    `[SEVO Review-Fix Loop] Pipeline ${pipelineId} (${projectSlug})`,
    `Round ${round}/${MAX_RFL_ROUNDS} — Revalidation of "${reviewStageId}"`,
    '',
    'Previous review issues have been fixed. Re-run the full review.',
    `Evaluate stage "${reviewStageId}" for project "${projectSlug}".`,
    'Conclusion: passed / conditional / rejected.',
  ].join('\n');
}

async function extractP0P1FromVerdict(verdict) {
  if (!verdict || !Array.isArray(verdict.blockers)) return [];
  const classified = await Promise.all(
    verdict.blockers.map(async b => ({ ...b, severity: await classifyBlockerSeverity(b) }))
  );
  return classified.filter(b => b.severity === 'P0' || b.severity === 'P1');
}

function updateRflStatus(pipelineId, status, loopState, extra) {
  const active = loadActivePipelines();
  if (!active.pipelines?.[pipelineId]) return;
  active.pipelines[pipelineId].rflStatus = {
    status,
    round: loopState?.round || extra?.round || 0,
    maxRounds: loopState?.maxRounds || MAX_RFL_ROUNDS,
    currentIssues: (loopState?.issues || []).length,
    resolvedIssues: extra?.resolvedIssues || 0,
    origin: loopState?.stageId || extra?.origin || null,
    updatedAt: nowIso(),
  };
  saveActivePipelines(active);
}

function queueRflFix(pipelineId, reviewStageId, issues, round) {
  const projectSlug = getProjectSlug(pipelineId);
  const fixStageId = `${reviewStageId}-rfl-fix-${round}`;
  const fixPrompt = buildFixPrompt(pipelineId, projectSlug, reviewStageId, issues, round);
  const implMapping = getStageMapping('implement');

  const entries = sevoGlobal.pendingAdvances.get(pipelineId) || [];
  entries.push({
    stageId: fixStageId,
    label: encode(getProjectSlug(pipelineId), fixStageId),
    taskDescription: fixPrompt,
    agentId: implMapping?.agentId || null,
    timeout: implMapping?.timeout || 1200,
  });
  sevoGlobal.pendingAdvances.set(pipelineId, entries);
}

function queueRflReval(pipelineId, reviewStageId, round) {
  const projectSlug = getProjectSlug(pipelineId);
  const revalStageId = `${reviewStageId}-rfl-reval-${round}`;
  const revalPrompt = buildRevalPrompt(pipelineId, projectSlug, reviewStageId, round);
  const reviewMapping = getStageMapping(reviewStageId);

  const entries = sevoGlobal.pendingAdvances.get(pipelineId) || [];
  entries.push({
    stageId: revalStageId,
    label: encode(getProjectSlug(pipelineId), revalStageId),
    taskDescription: revalPrompt,
    agentId: reviewMapping?.agentId || 'audit-01',
    timeout: reviewMapping?.timeout || 1200,
  });
  sevoGlobal.pendingAdvances.set(pipelineId, entries);
}

// ─── Failure Retry Helpers ──────────────────────────────────

const TASK_DESC_LENGTH_THRESHOLD = 2000;
const OUTPUT_TOKENS_THRESHOLD = 3000;

/**
 * Determine the tier string from an agentId string.
 * Returns null for non-coding tiers (pm, arch, audit, T4-native).
 */
function getTierFromAgentId(agentId) {
  if (!agentId || typeof agentId !== 'string') return null;
  const lower = agentId.toLowerCase();
  // Native subagents → T4
  if (lower === 'dev-01' || lower === 'dev-02') return 'T4';
  // ACP coding agents → their own tier
  if (lower === 'cc' || lower === 'free-code') return 'T1';
  if (lower === 'codex' || lower === 'opencode') return 'T2';
  return null; // pm-01, sa-01, audit-01, hermes, etc.
}

/**
 * Record a failure attempt for a pipeline+stage combo.
 * Returns the existing history entry (or null).
 */
function recordFailure(pipelineId, stageId, agentId, tier, reason) {
  const key = `${pipelineId}:${stageId}`;
  if (!sevoGlobal.failureHistory.has(key)) {
    sevoGlobal.failureHistory.set(key, { attempts: [] });
  }
  const history = sevoGlobal.failureHistory.get(key);
  const entry = {
    agentId: agentId || null,
    tier: tier || null,
    timestamp: nowIso(),
    reason: reason || 'unknown',
  };
  history.attempts.push(entry);

  // P1-2 fix: persist failure to active-pipelines.json so diagnose can read it
  try {
    const active = loadActivePipelines();
    const info = active.pipelines?.[pipelineId];
    if (info) {
      if (!Array.isArray(info.failures)) info.failures = [];
      info.failures.push({ stage: stageId, error: entry.reason, timestamp: entry.timestamp, agentId: entry.agentId });
      saveActivePipelines(active);
    }
  } catch { /* fail-open: don't break pipeline on persistence error */ }

  return history;
}

/**
 * Check whether a given tier has already failed for this pipeline+stage.
 */
function hasTierFailed(pipelineId, stageId, tier) {
  const key = `${pipelineId}:${stageId}`;
  const history = sevoGlobal.failureHistory.get(key);
  if (!history) return false;
  return history.attempts.some(a => a.tier === tier);
}

/**
 * Compute the upgrade tier for a given current tier.
 * Returns null if no further upgrade is available.
 */
function getUpgradeTier(currentTier) {
  return TIER_UPGRADE_MAP[currentTier] ?? null;
}

/**
 * Resolve the agentId to use for an upgraded tier.
 * Returns null to signal auto-assign when no specific agent is preferred.
 */
function getAgentForTier(tier) {
  if (!tier) return null;
  return TIER_DEFAULT_AGENT[tier] ?? null;
}

/**
 * Detect substantial failure: output_tokens < 3k AND no files written.
 * Returns true if the task result indicates a substantively failed task.
 */
function detectSubstantialFailure(result) {
  if (!result || typeof result !== 'object') return false;

  const outputTokens = result?.outputTokens ?? result?.output_tokens ?? 0;
  const outputFiles = result?.outputFiles ?? result?.output_files ?? [];

  if (typeof outputTokens === 'number' && outputTokens < OUTPUT_TOKENS_THRESHOLD) {
    const hasFiles = Array.isArray(outputFiles) && outputFiles.length > 0;
    if (!hasFiles) {
      appendEvent({
        type: 'sevo_substantial_failure_detected',
        outputTokens,
        outputFileCount: outputFiles?.length ?? 0,
      });
      return true;
    }
  }
  return false;
}

/**
 * Check if task description exceeds threshold and suggest split.
 * Returns split suggestion if exceeds, null otherwise.
 */
function checkTaskDescriptionSplitNeeded(taskDescription) {
  if (!taskDescription || typeof taskDescription !== 'string') return null;
  if (taskDescription.length > TASK_DESC_LENGTH_THRESHOLD) {
    appendEvent({
      type: 'sevo_task_split_suggested',
      descLength: taskDescription.length,
      threshold: TASK_DESC_LENGTH_THRESHOLD,
    });
    return {
      suggestion: 'Consider splitting this task into smaller stages.',
      estimatedSplits: Math.ceil(taskDescription.length / TASK_DESC_LENGTH_THRESHOLD),
    };
  }
  return null;
}

/**
 * Verify expected output files exist for a completed stage.
 * Uses collectArtifactPathsFromMapper to resolve expected paths from pipeline state.
 * Fail-open: returns verified=true on any error.
 */
function verifyStageArtifacts(stageId, pipelineState) {
  try {
    const artifactPaths = collectArtifactPathsFromMapper(pipelineState);
    let expected = artifactPaths[stageId] || [];
    // Fallback: read artifacts directly from stage record (regardless of status)
    // to avoid fail-open when the stage just completed but isn't marked 'passed' yet
    if (expected.length === 0) {
      const stageRecord = pipelineState?.stages?.[stageId];
      if (stageRecord && Array.isArray(stageRecord.artifacts)) {
        expected = stageRecord.artifacts.map(a => a.path).filter(Boolean);
      }
    }
    if (expected.length === 0) return { verified: true, missing: [] };
    const missing = expected.filter(p => !fs.existsSync(p));
    return { verified: missing.length === 0, missing };
  } catch {
    return { verified: true, missing: [] };
  }
}

/**
 * Check if a long-doc stage produced a file that's too short, needing continuation.
 * Returns a continuation descriptor or null.
 */
function checkLongDocContinuation(stageId, pipelineId, pipelineState) {
  if (!LONG_DOC_STAGES.has(stageId)) return null;
  try {
    const artifactPaths = collectArtifactPathsFromMapper(pipelineState);
    const paths = artifactPaths[stageId] || [];
    for (const p of paths) {
      if (!fs.existsSync(p)) continue;
      const lineCount = fs.readFileSync(p, 'utf8').split('\n').length;
      if (lineCount < LONG_DOC_MIN_LINES) {
        return {
          filePath: p,
          lineCount,
          threshold: LONG_DOC_MIN_LINES,
          prompt:
            `[SEVO Continuation] File "${path.basename(p)}" has ${lineCount} lines (min: ${LONG_DOC_MIN_LINES}).\n` +
            `Continue writing from where you left off. Append remaining chapters/sections.\n` +
            `Target file: ${p}\nUse Edit/append — do NOT overwrite existing content.`,
        };
      }
    }
  } catch { /* fail-open */ }
  return null;
}

/**
 * Safety-net AC injection: if buildTaskPrompt didn't inject ACs (e.g. missing
 * artifact records), extract them here and append to the implement prompt.
 */
function ensureACInjection(taskPrompt, pipelineState) {
  if (taskPrompt.includes('[AC-COVERAGE-START]')) return taskPrompt;
  try {
    const artifactPaths = collectArtifactPathsFromMapper(pipelineState);
    const acs = extractACsFromSpec(artifactPaths);
    if (acs.length === 0) return taskPrompt;
    const block = [
      '', '## AC Checklist (SEVO safety-net)',
      'Implement ALL Acceptance Criteria:',
      '',
    ];
    for (const ac of acs) {
      block.push(`- ${ac.id}: ${ac.summary || ac.text || ac}`);
    }
    block.push('', 'Output coverage checklist after implementation:');
    block.push('[AC-COVERAGE-START]');
    block.push('<AC-ID> | <covered/partial/uncovered> | <file:line or reason>');
    block.push('[AC-COVERAGE-END]');
    return taskPrompt + block.join('\n');
  } catch { return taskPrompt; }
}

// Heuristic fallback keywords for process improvement detection
const PROCESS_IMPROVEMENT_KEYWORDS_FALLBACK = [
  '流程改进', '规则建议', '新增约束', 'process improvement',
  'rule suggestion', 'new constraint', 'should add', 'recommend adding',
];

const LLM_PROCESS_IMPROVEMENT_SYSTEM_PROMPT = `You are a process-improvement detector. Given agent output text, determine whether it contains process improvement suggestions (new rules, workflow changes, constraint additions, methodology recommendations).

Respond with JSON only: {"detected": boolean, "category": "rule"|"workflow"|"constraint"|"methodology"|null, "reasoning": "string"}

Only flag genuine process improvement suggestions. Ignore normal task output, code, or status reports.`;

async function detectProcessImprovement(result) {
  if (!result) return null;

  const output = result?.output || result?.message || '';
  if (typeof output !== 'string' || !output.trim()) return null;

  // Priority 1: LLM semantic classification
  try {
    const llmConfig = readLLMConfig();
    if (llmConfig) {
      const base = llmConfig.baseUrl;
      const chatUrl = base.endsWith('/v1') || base.includes('/v1/')
        ? `${base}/chat/completions`
        : `${base}/v1/chat/completions`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(chatUrl, {
        method: 'POST',
        signal: controller.signal,
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${llmConfig.apiKey}` },
        body: JSON.stringify({
          model: llmConfig.model,
          messages: [
            { role: 'system', content: LLM_PROCESS_IMPROVEMENT_SYSTEM_PROMPT },
            { role: 'user', content: output.slice(0, 3000) },
          ],
          temperature: 0,
          max_tokens: 200,
        }),
      });
      clearTimeout(timeout);

      if (response.ok) {
        const data = await response.json();
        const text = data?.choices?.[0]?.message?.content || '';
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          if (!parsed.detected) return null;

          appendEvent({
            type: 'sevo_process_improvement_detected',
            source: 'llm',
            category: parsed.category,
            pipelineId: result?.pipelineId,
            stageId: result?.stageId,
          });

          return {
            keyword: `llm:${parsed.category}`,
            reminder: `[SEVO Process Improvement] A process improvement suggestion was detected (category: "${parsed.category}"). Please apply the dual-write rule: write to both local md (AGENTS.md/SOUL.md, L6 layer) AND SEVO product layer (spec → arc42 → code).`,
          };
        }
      }
    }
  } catch { /* LLM unavailable, fall through to heuristic fallback */ }

  // Priority 2: Heuristic fallback (keyword-based)
  const lower = output.toLowerCase();
  const found = PROCESS_IMPROVEMENT_KEYWORDS_FALLBACK.find(kw => lower.includes(kw.toLowerCase()));
  if (!found) return null;

  appendEvent({
    type: 'sevo_process_improvement_detected',
    source: 'fallback-keyword',
    keyword: found,
    pipelineId: result?.pipelineId,
    stageId: result?.stageId,
  });

  return {
    keyword: found,
    reminder: `[SEVO Process Improvement] A process improvement suggestion was detected (keyword: "${found}"). Please apply the dual-write rule: write to both local md (AGENTS.md/SOUL.md, L6 layer) AND SEVO product layer (spec → arc42 → code).`,
  };
}

function getProgressPath() {
  const config = sevoGlobal.runtimeConfig || {};
  const workspaceRoot = config.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
  return path.join(workspaceRoot, 'logs', 'sevo-progress.json');
}

function loadProgress() {
  return readJson(getProgressPath(), { pipelines: {} });
}

function saveProgress(data) {
  writeJson(getProgressPath(), data);
}

function getProjectProgress(pipelineId) {
  const progress = loadProgress();
  return progress.pipelines?.[pipelineId] || null;
}

function updateStageProgress(pipelineId, stageId, status, startedAt = null, completedAt = null) {
  const progress = loadProgress();
  progress.pipelines = progress.pipelines || {};

  if (!progress.pipelines[pipelineId]) {
    const active = loadActivePipelines();
    progress.pipelines[pipelineId] = {
      projectSlug: active.pipelines?.[pipelineId]?.projectSlug || 'unknown',
      stages: [],
      completionPercent: 0,
      lastUpdated: nowIso(),
    };
  }

  const pipeline = progress.pipelines[pipelineId];
  const existing = pipeline.stages.find(s => s.name === stageId);

  if (existing) {
    existing.status = status;
    if (startedAt) existing.startedAt = startedAt;
    if (completedAt) existing.completedAt = completedAt;
  } else {
    pipeline.stages.push({
      name: stageId,
      status: status,
      startedAt: startedAt,
      completedAt: completedAt,
    });
  }

  pipeline.lastUpdated = nowIso();
  saveProgress(progress);

  const pct = computeCompletionPercent(pipelineId);
  if (pipeline.completionPercent !== pct) {
    pipeline.completionPercent = pct;
    saveProgress(progress);
  }

  appendEvent({
    type: 'sevo_progress_updated',
    pipelineId,
    stageId,
    stageStatus: status,
  });
}

function computeCompletionPercent(pipelineId) {
  const progress = loadProgress();
  const pipeline = progress.pipelines?.[pipelineId];
  if (!pipeline || !Array.isArray(pipeline.stages)) return 0;

  const active = loadActivePipelines();
  const state = active.pipelines?.[pipelineId];
  if (!state) return 0;

  const required = state.requiredStages || [];
  if (required.length === 0) return 0;

  const passed = pipeline.stages.filter(s => s.status === 'passed').length;
  return Math.round((passed / required.length) * 100);
}

/**
 * Build a retry advance entry after applying failure handling:
 *   - No prior failure at this tier → record and allow same-tier retry
 *   - Tier already failed → upgrade tier (if possible), inject upgrade agentId
 *   - Tier exhausted → do not queue retry; caller will emit rework notice only
 *
 * Returns an entry object to push into pendingAdvances, or null when exhausted.
 */
function buildRetryAdvanceEntry(pipelineId, stageId, currentTier, currentAgentId, taskDescription, timeout) {
  const alreadyFailed = hasTierFailed(pipelineId, stageId, currentTier);
  const history = recordFailure(pipelineId, stageId, currentAgentId, currentTier, 'subagent failed');

  if (alreadyFailed) {
    // Second failure at same tier → must upgrade
    const upgradeTier = getUpgradeTier(currentTier);
    if (!upgradeTier) {
      // Exhausted: T1 also failed, ceiling reached
      appendEvent({
        type: 'sevo_retry_exhausted',
        pipelineId,
        stageId,
        currentTier,
        currentAgentId,
      });
      return null;
    }
    const upgradeAgentId = getAgentForTier(upgradeTier);
    appendEvent({
      type: 'sevo_tier_upgrade',
      pipelineId,
      stageId,
      fromTier: currentTier,
      toTier: upgradeTier,
      upgradeAgentId,
    });
    return {
      stageId: stageId,
      label: encode(getProjectSlug(pipelineId), stageId),
      taskDescription,
      agentId: upgradeAgentId,
      tier: upgradeTier,
      timeout: timeout || 1200,
    };
  }

  // First failure at this tier: allow one retry at same tier
  return {
    stageId: stageId,
    label: encode(getProjectSlug(pipelineId), stageId),
    taskDescription,
    agentId: currentAgentId,
    tier: currentTier,
    timeout: timeout || 1200,
  };
}

// ─── Supplement Injection (FR-O09) ───────────────────────────────────────

function addSupplement(pipelineId, stageId, content) {
  const key = `${pipelineId}:${stageId}`;
  sevoGlobal.pendingSupplements.set(key, {
    pipelineId,
    stageId,
    content,
    createdAt: nowIso(),
  });
  appendEvent({
    type: 'sevo_supplement_added',
    pipelineId,
    stageId,
    contentLength: content?.length ?? 0,
  });
}

function consumeSupplements(pipelineId) {
  const items = [];
  for (const [key, entry] of sevoGlobal.pendingSupplements.entries()) {
    if (entry.pipelineId === pipelineId) {
      items.push(entry);
      sevoGlobal.pendingSupplements.delete(key);
    }
  }
  return items;
}

function injectSupplementsIntoPrompt(taskDescription, supplements) {
  if (!supplements || supplements.length === 0) return taskDescription;
  const injected = [...supplements].reverse().map(s => s.content).join('\n\n---\n\n');
  return `${taskDescription}\n\n[SEVO SUPPLEMENT INJECTED]\n${injected}\n[/SEVO SUPPLEMENT INJECTED]`;
}

// ─── Pipeline Creation Detection ───

const SEVO_CREATE_RE = /sevo[:\xff1a]create\s+([a-z0-9](?:[a-z0-9-]*[a-z0-9])?)(?:\s+"([^"]+)")?(?:\s+--tier\s+([123]))?/i;
const SEVO_QUICKSTART_RE = /sevo:quickstart\b/i;
const SEVO_STATUS_RE = /sevo:status(?:\s+(\S+))?/i;
const SEVO_LIST_RE = /sevo:list\b/i;
const SEVO_DOCTOR_RE = /sevo:doctor\b/i;
const SEVO_VERSION_RE = /sevo:version\b/i;
const SEVO_INIT_RE = /sevo(?::|\s+)init\b/i;
const SEVO_DIAGNOSE_RE = /sevo:diagnose\s+(sevo-[a-z0-9]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)/i;
const SEVO_RETRY_RE = /sevo:retry\s+(sevo-[a-z0-9]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)(?:\s+(\S+))?/i;
const SEVO_PAUSE_RE = /sevo:pause\s+(sevo-[a-z0-9]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)/i;
const SEVO_SKIP_RE = /sevo:skip\s+(sevo-[a-z0-9]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\s+(\S+)/i;
const SEVO_RESUME_RE = /sevo:resume\s+(sevo-[a-z0-9]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)/i;

// ─── FR-27: Flexible Stage Entry ─────────────────────────────────────────────
const SEVO_FROM_RE = /sevo:from\s+([a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\s+(specify|plan|implement|review|deploy|verify|publish)/i;

// FR-27: Map user-facing stage names to internal stage IDs
const FROM_STAGE_MAP = {
  'specify': 'spec',
  'plan': 'contract',
  'implement': 'implement',
  'review': 'review',
  'deploy': 'deploy',
  'verify': 'verify',
  'publish': 'publish-generalization-gate',
};

// FR-27: Regex for detecting from:<stage> in labels
const FROM_LABEL_RE = /^from:(specify|plan|implement|review|deploy|verify|publish)$/i;

function extractUserMessage(evt) {
  if (!evt) return null;
  if (typeof evt.userMessage === 'string') return evt.userMessage;
  if (typeof evt.message === 'string') return evt.message;
  if (typeof evt.prompt === 'string') return evt.prompt;
  const msgs = evt.messages;
  if (Array.isArray(msgs)) {
    for (let i = msgs.length - 1; i >= 0; i--) {
      const m = msgs[i];
      if (m?.role === 'user') {
        const text = typeof m.content === 'string' ? m.content : m.content?.[0]?.text;
        if (text) return text;
      }
    }
  }
  return null;
}

function detectPipelineCreationIntent(message) {
  const match = message.match(SEVO_CREATE_RE);
  if (!match) return null;

  // Guard: skip false-positive matches inside code blocks, quotes, or markdown examples
  const idx = message.indexOf(match[0]);
  const before = message.slice(0, idx);
  const after = message.slice(idx + match[0].length);
  const inCodeBlock = (before.split('```').length - 1) % 2 === 1;
  const inInlineCode = before.lastIndexOf('`') > before.lastIndexOf('\n') && after.indexOf('`') < (after.indexOf('\n') === -1 ? after.length : after.indexOf('\n'));
  const lineStart = before.lastIndexOf('\n') + 1;
  const linePrefix = before.slice(lineStart);
  const inBlockquote = /^>\s/.test(linePrefix);
  const inQuotes = (linePrefix.endsWith('"') || linePrefix.endsWith("'")) && (after.startsWith('"') || after.startsWith("'"));
  if (inCodeBlock || inInlineCode || inBlockquote || inQuotes) {
    appendEvent({ type: 'sevo_create_skipped', reason: 'quoted_or_code_context', matchText: match[0], message: '[sevo-pipeline] skipped false-positive sevo:create in quoted/code context' });
    return null;
  }

  const projectSlug = match[1];
  const title = match[2] || projectSlug;
  const forcedTier = match[3] ? parseInt(match[3], 10) : null;
  const taskId = `task-${projectSlug}-${Date.now().toString(36)}`;

  return {
    projectSlug,
    forcedTier,
    task: {
      taskId,
      title,
      description: message,
      scope: { isNewModule: true },
    },
  };
}

function detectDiagnoseIntent(message) {
  const match = message.match(SEVO_DIAGNOSE_RE);
  if (!match) return null;
  return { pipelineId: match[1] };
}

function detectRetryIntent(message) {
  const match = message.match(SEVO_RETRY_RE);
  if (!match) return null;
  return { pipelineId: match[1], stageId: match[2] || null };
}

function detectPauseIntent(message) {
  const match = message.match(SEVO_PAUSE_RE);
  if (!match) return null;
  return { pipelineId: match[1] };
}

function detectSkipIntent(message) {
  const match = message.match(SEVO_SKIP_RE);
  if (!match) return null;
  return { pipelineId: match[1], stageId: match[2] };
}

function detectResumeIntent(message) {
  const match = message.match(SEVO_RESUME_RE);
  if (!match) return null;
  return { pipelineId: match[1] };
}

// ─── FR-27: Flexible Stage Entry — detect sevo:from intent ───────────────────

function detectFromIntent(message) {
  const match = message.match(SEVO_FROM_RE);
  if (!match) return null;

  // P2: Prevent false triggers when sevo:from appears inside code blocks or quotes
  const matchIndex = message.indexOf(match[0]);
  const before = message.slice(0, matchIndex);
  // Inside a fenced code block (``` ... ```)
  const fenceCount = (before.match(/```/g) || []).length;
  if (fenceCount % 2 === 1) return null;
  // Inside an inline code span (` ... `)
  const lineStart = before.lastIndexOf('\n') + 1;
  const linePrefix = message.slice(lineStart, matchIndex);
  const backtickCount = (linePrefix.match(/`/g) || []).length;
  if (backtickCount % 2 === 1) return null;
  // Starts with blockquote marker
  if (/^\s*>/.test(linePrefix)) return null;

  return { projectSlug: match[1], targetStage: match[2].toLowerCase() };
}

/**
 * FR-27: Handle sevo:from command — create pipeline starting from a specific stage.
 * Stages before the target are marked as 'skipped'.
 */
async function handleFromCommand(projectSlug, targetStageName) {
  const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
  const projectRoot = `projects/${projectSlug}`;
  const absProjectRoot = path.resolve(wsRoot, projectRoot);

  // Validate project directory exists
  if (!fs.existsSync(absProjectRoot)) {
    return `[SEVO FR-27] Error: Project directory not found: ${projectRoot}. ` +
      `sevo:from requires an existing project. Use sevo:create ${projectSlug} for new projects.`;
  }

  // Check for existing active pipeline
  const active = loadActivePipelines();
  for (const [pid, info] of Object.entries(active.pipelines || {})) {
    if (info.projectSlug === projectSlug) {
      return `[SEVO FR-27] Pipeline for "${projectSlug}" already exists (${pid}). ` +
        `Use sevo:diagnose ${pid} to check status, or sevo:retry ${pid} to restart.`;
    }
  }

  const targetStageId = FROM_STAGE_MAP[targetStageName];
  if (!targetStageId) {
    return `[SEVO FR-27] Error: Unknown stage "${targetStageName}". ` +
      `Valid stages: ${Object.keys(FROM_STAGE_MAP).join(', ')}`;
  }

  // Get pipeline engine and create state
  const routeFn = await getRoute();
  if (!routeFn) {
    appendEvent({ type: 'sevo_from_failed', reason: 'router_unavailable', projectSlug, targetStage: targetStageName });
    return '[SEVO FR-27] Error: Pipeline router unavailable. Run sevo:doctor to diagnose.';
  }

  const taskId = `task-${projectSlug}-${Date.now().toString(36)}`;
  const routingResult = routeFn({
    taskId,
    title: projectSlug,
    description: `sevo:from ${projectSlug} ${targetStageName}`,
    scope: { isNewModule: false },
  });
  if (!routingResult.ok) {
    appendEvent({ type: 'sevo_from_failed', reason: 'routing_failed', projectSlug, error: routingResult.error?.message });
    return `[SEVO FR-27] Error: Routing failed — ${routingResult.error?.message || 'unknown error'}`;
  }

  const engine = await getPipelineEngine();
  if (!engine) {
    appendEvent({ type: 'sevo_from_failed', reason: 'engine_unavailable', projectSlug });
    return '[SEVO FR-27] Error: Pipeline engine unavailable. Run sevo:doctor to diagnose.';
  }

  let state;
  try {
    state = engine.create(routingResult.value);
  } catch (createErr) {
    appendEvent({ type: 'sevo_from_failed', reason: 'engine_create_error', projectSlug, error: String(createErr?.message || createErr) });
    return `[SEVO FR-27] Error: Failed to create pipeline — ${createErr?.message || createErr}`;
  }

  // Validate targetStageId exists in this pipeline's stage list
  if (!state.requiredStages.includes(targetStageId)) {
    appendEvent({ type: 'sevo_from_failed', reason: 'target_stage_not_in_pipeline', projectSlug, targetStageId, requiredStages: state.requiredStages });
    return `[SEVO FR-27] Error: Stage "${targetStageName}" (${targetStageId}) is not in this pipeline's stage list: ${state.requiredStages.join(', ')}. Check Tier routing.`;
  }

  // Mark stages before target as skipped
  const skipReason = `用户指定从 ${targetStageName} 开始`;
  const skippedStages = [];
  for (const sid of state.requiredStages) {
    if (sid === targetStageId) break;
    updateStageProgress(state.pipelineId, sid, 'skipped', null, nowIso());
    skippedStages.push(sid);
  }

  // Store skipReasons in active pipelines
  const skipReasons = {};
  for (const sid of skippedStages) {
    skipReasons[sid] = skipReason;
  }

  active.pipelines = active.pipelines || {};
  active.pipelines[state.pipelineId] = {
    projectSlug,
    projectRoot,
    createdAt: nowIso(),
    lastAdvancedAt: nowIso(),
    tier: 3,
    skipReasons,
    entryStage: targetStageId,
  };
  saveActivePipelines(active);

  // Activate the target stage and queue it
  updateStageProgress(state.pipelineId, targetStageId, 'active', nowIso());

  const mapping = getStageMapping(targetStageId);
  if (mapping) {
    const taskPrompt = buildTaskPrompt(targetStageId, state, projectSlug, projectRoot);
    const entries = sevoGlobal.pendingAdvances.get(state.pipelineId) || [];
    entries.push({
      stageId: targetStageId,
      label: encode(getProjectSlug(state.pipelineId), targetStageId),
      taskDescription: taskPrompt,
      agentId: mapping.agentId,
      timeout: mapping.timeout,
    });
    sevoGlobal.pendingAdvances.set(state.pipelineId, entries);
  }

  appendEvent({
    type: 'sevo_from_created',
    pipelineId: state.pipelineId,
    projectSlug,
    targetStage: targetStageId,
    skippedStages,
    requiredStages: state.requiredStages,
  });

  const stagesDisplay = state.requiredStages.map(s =>
    skippedStages.includes(s) ? `~~${s}~~` : s === targetStageId ? `**${s}**` : s
  ).join(' → ');

  return `[SEVO FR-27] Pipeline ${state.pipelineId} for "${projectSlug}" — entering from "${targetStageName}".\n` +
    `Skipped: ${skippedStages.length > 0 ? skippedStages.join(', ') : 'none'}\n` +
    `Active: ${targetStageId}\n` +
    `Stages: ${stagesDisplay}`;
}

// ─── sevo:quickstart Command Handler (FR-D02 AC2+AC3) ──────────────────────

async function handleQuickstartCommand() {
  const projectSlug = 'hello-sevo';
  const requirement = 'Build a simple Node.js CLI tool that converts a markdown file to HTML. Single file, no external dependencies, reads from stdin and writes to stdout.';
  const taskId = `task-${projectSlug}-${Date.now().toString(36)}`;

  const active = loadActivePipelines();
  for (const [pid, info] of Object.entries(active.pipelines || {})) {
    if (info.projectSlug === projectSlug) {
      return {
        content: `Pipeline for "${projectSlug}" already exists (${pid}). Use sevo:diagnose ${pid} to check status.`
      };
    }
  }

  const routeFn = await getRoute();
  if (!routeFn) {
    appendEvent({ type: 'sevo_quickstart_failed', reason: 'router_unavailable' });
    return null;
  }

  const routingResult = routeFn({
    taskId,
    title: projectSlug,
    description: requirement,
    scope: { isNewModule: true },
  });

  if (!routingResult.ok) {
    appendEvent({ type: 'sevo_quickstart_failed', reason: 'routing_failed', error: routingResult.error?.message });
    return null;
  }

  const engine = await getPipelineEngine();
  if (!engine) {
    appendEvent({ type: 'sevo_quickstart_failed', reason: 'engine_unavailable' });
    return null;
  }

  let state;
  try {
    state = engine.create(routingResult.value);
  } catch (createErr) {
    appendEvent({ type: 'sevo_quickstart_failed', reason: 'engine_create_error', error: String(createErr?.message || createErr) });
    return null;
  }

  state.requiredStages = QUICKSTART_STAGES;
  state.isQuickstart = true;

  const wsRoot = sevoGlobal.runtimeConfig.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
  const projectRoot = `projects/${projectSlug}`;
  const absProjectRoot = path.resolve(wsRoot, projectRoot);
  for (const sub of ['docs/design', 'docs/architecture/decisions', 'src', 'tests', 'reports', 'scripts']) {
    try { fs.mkdirSync(path.join(absProjectRoot, sub), { recursive: true }); } catch {}
  }

  active.pipelines = active.pipelines || {};
  active.pipelines[state.pipelineId] = {
    projectSlug,
    projectRoot,
    createdAt: nowIso(),
    lastAdvancedAt: nowIso(),
    isQuickstart: true,
  };
  saveActivePipelines(active);

  appendEvent({
    type: 'sevo_quickstart_created',
    pipelineId: state.pipelineId,
    projectSlug,
    requiredStages: QUICKSTART_STAGES,
  });

  for (const sid of state.requiredStages) {
    if (state.stages[sid]?.status === 'active') {
      const mapping = getStageMapping(sid);
      if (!mapping) continue;
      const taskPrompt = buildTaskPrompt(sid, state, projectSlug, projectRoot);
      const entries = sevoGlobal.pendingAdvances.get(state.pipelineId) || [];
      entries.push({
        stageId: sid,
        label: encode(getProjectSlug(state.pipelineId), sid),
        taskDescription: taskPrompt,
        agentId: mapping.agentId,
        timeout: mapping.timeout,
      });
      sevoGlobal.pendingAdvances.set(state.pipelineId, entries);
      break;
    }
  }

  return {
    content: `[SEVO Quickstart] Pipeline ${state.pipelineId} for "${projectSlug}" — 7-stage demo pipeline started!\n` +
      `Stages: ${QUICKSTART_STAGES.join(' → ')}\n` +
      `Built-in requirement: ${requirement}`
  };
}

// ─── sevo:diagnose Command Handler ───────────────────────────────────────────────────

function handleDiagnoseCommand(pipelineId) {
  const active = loadActivePipelines();
  const info = active.pipelines?.[pipelineId];

  if (!info) {
    return formatError('SEVO-E005', { pipelineId, error: 'Pipeline not found in active-pipelines.json' });
  }

  const projectSlug = info.projectSlug;
  const currentStage = info.currentStage;
  const lastAdvancedAt = info.lastAdvancedAt;
  const timedOutStage = info.timedOutStage;
  const lastTimeoutAt = info.lastTimeoutAt;
  const lastError = info.lastError;

  let output = `═══ SEVO Pipeline Diagnostic ═══\n`;
  output += `Pipeline ID: ${pipelineId}\n`;
  output += `Project: ${projectSlug}\n`;
  output += `Last Advanced: ${lastAdvancedAt || 'N/A'}\n\n`;

  if (lastTimeoutAt && timedOutStage) {
    output += `⚠️ ${formatError('SEVO-E004', { stage: timedOutStage, pipelineId })}\n`;
  }

  if (lastError) {
    output += `\n${formatError(lastError.code || 'SEVO-E006', { stage: lastError.stage, pipelineId, error: lastError.message })}\n`;
  }

  if (currentStage) {
    output += `\nCurrent Stage: ${currentStage}\n`;
  }

  const failures = info.failures || [];
  if (failures.length > 0) {
    output += `\n═══ Failure History (${failures.length}) ═══\n`;
    for (const f of failures) {
      output += `- ${f.stage}: ${f.error || 'SEVO-E006'} at ${f.timestamp || f.at || 'unknown'}\n`;
      if (f.agentId) output += `  Agent: ${f.agentId}\n`;
    }
  }

  if (!currentStage && !timedOutStage && failures.length === 0) {
    output += `\n✓ Pipeline appears complete or idle.\n`;
  }

  return output;
}

function handleRetryCommand(pipelineId, stageId) {
  const active = loadActivePipelines();
  const info = active.pipelines?.[pipelineId];

  if (!info) {
    return formatError('SEVO-E005', { pipelineId, error: 'Pipeline not found in active-pipelines.json' });
  }

  let resolvedStageId = stageId;
  if (!resolvedStageId) {
    const progress = getProjectProgress(pipelineId);
    const activeStage = progress?.stages?.find(s => s.status === 'active' || s.status === 'running' || s.status === 'failed');
    if (activeStage) {
      resolvedStageId = activeStage.name;
    } else {
      return formatError('SEVO-E003', { pipelineId, error: 'No active or failed stage found to retry' });
    }
  }

  const entries = sevoGlobal.pendingAdvances.get(pipelineId) || [];
  const mapping = getStageMapping(resolvedStageId);
  if (!mapping) {
    return formatError('SEVO-E003', { stage: resolvedStageId, pipelineId, error: 'Stage not found in stage mapping' });
  }

  updateStageProgress(pipelineId, resolvedStageId, 'pending');

  const label = encode(getProjectSlug(pipelineId), resolvedStageId);
  const taskPrompt = `[SEVO Retry] Pipeline ${pipelineId} stage "${resolvedStageId}" re-queued by user.\n` +
    `Project: ${info.projectSlug}\n` +
    `Please retry the execution of stage "${resolvedStageId}".`;

  entries.push({
    stageId: resolvedStageId,
    label,
    taskDescription: taskPrompt,
    agentId: mapping.agentId,
    timeout: mapping.timeout,
  });

  sevoGlobal.pendingAdvances.set(pipelineId, entries);

  appendEvent({ type: 'manual_intervention', action: 'retry', pipelineId, stageId: resolvedStageId });

  return `Retry queued for pipeline ${pipelineId} stage "${resolvedStageId}".\n` +
    `Agent: ${mapping.agentId} | Timeout: ${mapping.timeout}s`;
}

// ─── sevo:pause Command Handler (FR-D03) ──────────────────────────────────────

function handlePauseCommand(pipelineId) {
  const active = loadActivePipelines();
  const info = active.pipelines?.[pipelineId];

  if (!info) {
    return formatError('SEVO-E005', { pipelineId, error: 'Pipeline not found in active-pipelines.json' });
  }

  if (info.status === 'paused') {
    return `Pipeline ${pipelineId} is already paused. Use sevo:resume ${pipelineId} to continue.`;
  }

  info.status = 'paused';
  info.pausedAt = nowIso();
  saveActivePipelines(active);

  appendEvent({ type: 'manual_intervention', action: 'pause', pipelineId });

  const progress = getProjectProgress(pipelineId);
  const currentStage = progress?.stages?.find(s => s.status === 'active' || s.status === 'running')?.name || '—';
  const pct = progress?.completionPercent ?? 0;

  return `⏸ Pipeline ${pipelineId} paused.\n` +
    `  Project: ${info.projectSlug}\n` +
    `  Current stage: ${currentStage} (${pct}%)\n` +
    `  Use sevo:resume ${pipelineId} to continue.`;
}

// ─── sevo:skip Command Handler (FR-D03) ───────────────────────────────────────

function handleSkipCommand(pipelineId, stageId) {
  const active = loadActivePipelines();
  const info = active.pipelines?.[pipelineId];

  if (!info) {
    return formatError('SEVO-E005', { pipelineId, error: 'Pipeline not found in active-pipelines.json' });
  }

  const mapping = getStageMapping(stageId);
  if (!mapping) {
    return formatError('SEVO-E003', { stage: stageId, pipelineId, error: 'Stage not found in stage mapping' });
  }

  updateStageProgress(pipelineId, stageId, 'skipped', null, nowIso());

  appendEvent({ type: 'manual_intervention', action: 'skip', pipelineId, stageId, skipReason: '用户主动跳过通用化门禁' });

  const isAuditStage = /review|audit/i.test(stageId);
  let msg = `⏭️ Stage "${stageId}" skipped for pipeline ${pipelineId}.\n`;

  if (isAuditStage) {
    msg += `  ⚠️ WARNING: "${stageId}" is a review/audit stage — skipping may reduce quality assurance.\n`;
  }

  const stageNames = info.requiredStages || [];
  const idx = stageNames.indexOf(stageId);
  if (idx >= 0 && idx < stageNames.length - 1) {
    const nextStageId = stageNames[idx + 1];
    const nextMapping = getStageMapping(nextStageId);
    if (nextMapping) {
      updateStageProgress(pipelineId, nextStageId, 'active', nowIso());
      const entries = sevoGlobal.pendingAdvances.get(pipelineId) || [];
      const label = encode(getProjectSlug(pipelineId), nextStageId);
      const taskPrompt = `[SEVO Skip-Advance] Pipeline ${pipelineId} advancing to "${nextStageId}" after user skipped "${stageId}".\n` +
        `Project: ${info.projectSlug}`;
      entries.push({
        stageId: nextStageId,
        label,
        taskDescription: taskPrompt,
        agentId: nextMapping.agentId,
        timeout: nextMapping.timeout,
      });
      sevoGlobal.pendingAdvances.set(pipelineId, entries);
      msg += `  Next stage: ${nextStageId}`;
    }
  }

  return msg;
}

// ─── sevo:resume Command Handler (FR-D03) ─────────────────────────────────────

function handleResumeCommand(pipelineId) {
  const active = loadActivePipelines();
  const info = active.pipelines?.[pipelineId];

  if (!info) {
    return formatError('SEVO-E005', { pipelineId, error: 'Pipeline not found in active-pipelines.json' });
  }

  if (info.status !== 'paused') {
    return `Pipeline ${pipelineId} is not paused (current status: ${info.status || 'active'}).`;
  }

  info.status = 'active';
  delete info.pausedAt;
  saveActivePipelines(active);

  appendEvent({ type: 'manual_intervention', action: 'resume', pipelineId });

  const progress = getProjectProgress(pipelineId);
  const currentStage = progress?.stages?.find(s => s.status === 'active' || s.status === 'running')?.name || '—';
  const pct = progress?.completionPercent ?? 0;

  return `▶️ Pipeline ${pipelineId} resumed.\n` +
    `  Project: ${info.projectSlug}\n` +
    `  Current stage: ${currentStage} (${pct}%)\n` +
    `  Pipeline will continue from where it was paused.`;
}

// ─── sevo:status Command Handler ───────────────────────────────────────────────────

function handleStatusCommand(pipelineIdArg) {
  const active = loadActivePipelines();
  const pipelines = active.pipelines || {};

  // No argument: list all active pipelines
  if (!pipelineIdArg) {
    const ids = Object.keys(pipelines);
    if (ids.length === 0) {
      return '═══ SEVO Status ═══\nNo active pipelines.';
    }
    let output = `═══ SEVO Status — ${ids.length} active pipeline(s) ═══\n`;
    for (const pid of ids) {
      const info = pipelines[pid];
      const progress = getProjectProgress(pid);
      const currentStage = progress?.stages?.find(s => s.status === 'active' || s.status === 'running')?.name
        || progress?.stages?.filter(s => s.status === 'passed').pop()?.name
        || info.currentStage || '—';
      const pct = progress?.completionPercent ?? 0;
      output += `\n  ${pid}\n`;
      output += `    Project:  ${info.projectSlug}\n`;
      output += `    Tier:     ${info.tier || 3}\n`;
      output += `    Stage:    ${currentStage}  (${pct}%)\n`;
      output += `    Created:  ${info.createdAt || '—'}\n`;
    }
    return output;
  }

  // With pipelineId: detailed view
  const info = pipelines[pipelineIdArg];
  if (!info) {
    return formatError('SEVO-E005', { pipelineId: pipelineIdArg, error: 'Pipeline not found in active-pipelines.json' });
  }

  let output = `═══ SEVO Pipeline Detail ═══\n`;
  output += `Pipeline ID:  ${pipelineIdArg}\n`;
  output += `Project:      ${info.projectSlug}\n`;
  output += `Tier:         ${info.tier || 3}\n`;
  output += `Created:      ${info.createdAt || '—'}\n`;
  output += `Last Advanced: ${info.lastAdvancedAt || '—'}\n`;

  // Stage details from progress
  const progress = getProjectProgress(pipelineIdArg);
  if (progress && Array.isArray(progress.stages) && progress.stages.length > 0) {
    output += `\n── Stages ──\n`;
    for (const s of progress.stages) {
      const icon = s.status === 'passed' ? '✅'
        : s.status === 'active' || s.status === 'running' ? '🔄'
        : s.status === 'failed' ? '❌'
        : s.status === 'skipped' ? '⏭️'
        : '⏳';
      let duration = '';
      if (s.startedAt && s.completedAt) {
        const ms = new Date(s.completedAt).getTime() - new Date(s.startedAt).getTime();
        if (ms > 0) {
          const sec = Math.round(ms / 1000);
          duration = sec >= 60 ? ` (${Math.floor(sec / 60)}m${sec % 60}s)` : ` (${sec}s)`;
        }
      }
      output += `  ${icon} ${s.name}: ${s.status}${duration}\n`;
    }
    output += `\n  Completion: ${progress.completionPercent ?? 0}%\n`;
  } else {
    output += `\n  No stage progress recorded yet.\n`;
  }

  // FR tracking
  const frTracking = loadFRTracking(pipelineIdArg);
  if (frTracking) {
    const total = frTracking.total?.length || 0;
    const completed = frTracking.completed?.length || 0;
    const remaining = frTracking.remaining?.length || 0;
    output += `\n── FR Tracking ──\n`;
    output += `  Total: ${total} | Completed: ${completed} | Remaining: ${remaining}\n`;
    if (remaining > 0 && Array.isArray(frTracking.remaining)) {
      output += `  Remaining: ${frTracking.remaining.join(', ')}\n`;
    }
  }

  // Artifact paths from progress or active info
  if (info.projectRoot) {
    output += `\n── Artifacts ──\n`;
    output += `  Project root: ${info.projectRoot}\n`;
  }

  return output;
}

// ─── sevo:list Command Handler ───────────────────────────────────────────────────

function handleListCommand() {
  const active = loadActivePipelines();
  const activePipelines = active.pipelines || {};
  const progress = loadProgress();
  const progressPipelines = progress.pipelines || {};

  // Merge: active pipelines are "active", progress-only are "completed"
  const all = new Map();
  for (const [pid, info] of Object.entries(activePipelines)) {
    all.set(pid, {
      projectSlug: info.projectSlug,
      status: 'active',
      createdAt: info.createdAt || '',
      completedAt: null,
      completionPercent: progressPipelines[pid]?.completionPercent ?? 0,
    });
  }
  for (const [pid, pInfo] of Object.entries(progressPipelines)) {
    if (!all.has(pid)) {
      const pct = pInfo.completionPercent ?? 0;
      all.set(pid, {
        projectSlug: pInfo.projectSlug || 'unknown',
        status: pct >= 100 ? 'completed' : 'stale',
        createdAt: pInfo.createdAt || '',
        completedAt: pInfo.lastUpdated || '',
        completionPercent: pct,
      });
    }
  }

  if (all.size === 0) {
    return '═══ SEVO Pipelines ═══\nNo pipelines found.';
  }

  // Sort by createdAt descending
  const sorted = [...all.entries()].sort((a, b) => {
    const ta = a[1].createdAt || '';
    const tb = b[1].createdAt || '';
    return tb.localeCompare(ta);
  });

  let output = `═══ SEVO Pipelines — ${sorted.length} total ═══\n`;
  for (const [pid, info] of sorted) {
    const statusIcon = info.status === 'active' ? '🔄'
      : info.status === 'completed' ? '✅'
      : '💤';
    output += `\n  ${statusIcon} ${pid}\n`;
    output += `    Project:    ${info.projectSlug}\n`;
    output += `    Status:     ${info.status} (${info.completionPercent}%)\n`;
    output += `    Created:    ${info.createdAt || '—'}\n`;
    if (info.completedAt) {
      output += `    Completed:  ${info.completedAt}\n`;
    }
  }
  return output;
}

// ─── sevo:doctor Command Handler ───────────────────────────────────────────────────

function handleDoctorCommand() {
  const checks = [];
  let errors = 0;
  let warnings = 0;

  // 1. Plugin registered in openclaw.json
  try {
    const configPath = path.resolve(PLUGIN_DIR, '../../openclaw.json');
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const pluginEntry = config?.plugins?.entries?.[PLUGIN_ID];
    if (pluginEntry && pluginEntry.enabled !== false) {
      checks.push('✅ Plugin registered in openclaw.json');
    } else if (pluginEntry) {
      checks.push('⚠️ Plugin found but disabled in openclaw.json');
      warnings++;
    } else {
      checks.push('❌ Plugin NOT registered in openclaw.json');
      errors++;
    }
  } catch {
    checks.push('❌ Cannot read openclaw.json');
    errors++;
  }

  // 2. Hook registration (verify by checking sevoGlobal state — hooks are registered if plugin loaded)
  const hookNames = ['before_prompt_build', 'subagent_ended'];
  if (!sevoGlobal.degraded) {
    checks.push(`✅ Hooks registered (${hookNames.join(', ')})`);
  } else {
    checks.push(`⚠️ Plugin degraded — hooks registered but inactive (SEVO dist/ missing)`);
    warnings++;
  }

  // 3. Agent pool
  const pool = sevoGlobal.agentPool || {};
  const codingAgents = pool.coding || [];
  const reviewAgents = pool.review || [];
  if (codingAgents.length > 0) {
    const names = codingAgents.map(a => typeof a === 'string' ? a : a.id).join(', ');
    checks.push(`✅ Agent pool: ${codingAgents.length} coding agent(s) available (${names})`);
  } else {
    checks.push('❌ No coding agents found');
    errors++;
  }
  if (reviewAgents.length > 0) {
    const names = reviewAgents.map(a => typeof a === 'string' ? a : a.id).join(', ');
    checks.push(`✅ Audit agents: ${reviewAgents.length} available (${names})`);
  } else {
    checks.push('⚠️ Warning: No audit agent found');
    warnings++;
  }

  // 4. State file writable
  try {
    const testPath = path.join(STATE_DIR, '.doctor-probe');
    fs.writeFileSync(testPath, 'ok');
    fs.unlinkSync(testPath);
    checks.push('✅ State file writable');
  } catch {
    checks.push('❌ State directory not writable: ' + STATE_DIR);
    errors++;
  }

  // 5. Paths configured
  const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
  const extRoot = PLUGIN_DIR;
  const wsExists = fs.existsSync(wsRoot);
  const extExists = fs.existsSync(extRoot);
  if (wsExists && extExists) {
    checks.push('✅ Paths configured');
  } else {
    if (!wsExists) { checks.push('❌ workspaceRoot not found: ' + wsRoot); errors++; }
    if (!extExists) { checks.push('❌ extensionRoot not found: ' + extRoot); errors++; }
  }

  let output = 'SEVO Doctor\n';
  output += checks.join('\n') + '\n';
  output += `\nErrors: ${errors} | Warnings: ${warnings}`;
  return output;
}

// ─── Plugin ───

const plugin = {
  id: PLUGIN_ID,
  name: 'SEVO Pipeline Auto-Advance',
  version: SEVO_VERSION,

  register(api) {
    sevoGlobal.runtimeConfig = resolvePluginConfig(api);
    setBridgeConfig(sevoGlobal.runtimeConfig);
    setTaskMapperConfig(sevoGlobal.runtimeConfig);

    // AC3: ensure configured output paths exist
    const wsRoot = sevoGlobal.runtimeConfig.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
    for (const p of Object.values(sevoGlobal.runtimeConfig.paths || {})) {
      try { fs.mkdirSync(path.resolve(wsRoot, p), { recursive: true }); } catch {}
    }

    // ── Agent Discovery ──
    const agentPool = discoverAgents();
    sevoGlobal.agentPool = agentPool;
    const totalAgents = agentPool._all ? agentPool._all.size : 0;
    const categories = ['coding', 'review', 'architecture', 'pm', 'ux', 'general']
      .filter(c => agentPool[c]?.length > 0)
      .map(c => `${c}:${agentPool[c].length}`);
    api.logger.info(`[${PLUGIN_ID}] Agent discovery: ${totalAgents} agents [${categories.join(', ')}]`);
    if (agentPool._isSingleAgent) {
      api.logger.warn(`[${PLUGIN_ID}] SEVO running in single-agent (minimal) mode — all stages will use main`);
    }

    // ── Startup check ──
    const bridgeStatus = isAvailable();
    if (!bridgeStatus.available) {
      sevoGlobal.degraded = true;
      appendEvent({ type: 'sevo_degraded', reason: bridgeStatus.reason });
      api.logger.warn(`[${PLUGIN_ID}] ${bridgeStatus.reason} — degraded to no-op`);
      if (!sevoGlobal.registeredLogged) {
        api.logger.info(`[${PLUGIN_ID}] registered (degraded)`);
        sevoGlobal.registeredLogged = true;
      }
      return;
    }

    // Ensure state dir
    fs.mkdirSync(STATE_DIR, { recursive: true });

    // FR-D05 AC3: migrate state on startup
    loadActivePipelinesWithMigration();

// ── Hook 1: subagent_ended (priority 200) ──
    // Fires after run-watchdog (100) updates the board.
    api.on('subagent_ended', safeSevoHook('subagent_ended', async (evt) => {
      const label = evt?.label || '';
      if (!isSevoLabel(label)) return; // not a SEVO task

      const parsed = decode(label);
      if (!parsed) return;

      const { projectSlug: parsedSlug, stageId, attempt } = parsed;
      const pipelineId = resolvePipelineId(parsedSlug);
      if (!pipelineId) return; // no active pipeline for this slug

      // Clear timeout timer — stage completed (success or failure)
      clearStageTimer(pipelineId, stageId);

      appendEvent({
        type: 'sevo_completion_received',
        pipelineId,
        stageId,
        attempt,
        label,
        status: evt?.status || 'unknown',
      });

      // FR-O08: Detect process improvement suggestions in audit/review reports
      if (isReviewStage(stageId) || stageId === 'spec-review-gate') {
        const improvement = detectProcessImprovement(evt?.result || evt);
        if (improvement) {
          sevoGlobal.pendingNotices.push(improvement.reminder);
        }
      }

      // ── Clarification detection ──
      // If the subagent output contains a clarification request marker,
      // block pipeline advancement and queue the questions for the main session.
      const clarReq = detectClarificationRequest(evt);
      if (clarReq) {
        const clarId = `clar-${pipelineId}-${stageId}-${Date.now().toString(36)}`;
        sevoGlobal.pendingClarifications.set(clarId, {
          pipelineId,
          stageId,
          questions: clarReq.questions,
          rawBody: clarReq.rawBody,
          blockingLevel: clarReq.blockingLevel,
          blockedLabel: label,
          createdAt: nowIso(),
        });

        appendEvent({
          type: 'sevo_clarification_requested',
          pipelineId,
          stageId,
          clarificationId: clarId,
          questionCount: clarReq.questions.length,
          blockingLevel: clarReq.blockingLevel,
        });

        const projectSlug = getProjectSlug(pipelineId);
        sevoGlobal.pendingNotices.push(
          `[SEVO Clarification Needed] Pipeline ${pipelineId} (${projectSlug}) stage "${stageId}" needs clarification before advancing.\n` +
          `ID: ${clarId}\n` +
          `Questions:\n${clarReq.questions.map((q, i) => `  ${i + 1}. ${q}`).join('\n')}\n` +
          `Reply with [SEVO_CLARIFICATION_RESPONSE] #${clarId} followed by your answers to resume.`
        );

        // Don't advance — wait for clarification response
        if (clarReq.blockingLevel === 'blocking') return;
      }

      // Check if we should use Orchestrator+Adapter path (if available)
      const useCorePath = sevoGlobal.runtimeConfig?.useOrchestratorAdapter === true;

      // Determine outcome — three-way verdict for gate stages, binary for others
      const gateVerdict = parseGateVerdict(evt);
      let outcome;
      let verdictBlockers = [];

      if (gateVerdict) {
        outcome = gateVerdict.conclusion;
        verdictBlockers = gateVerdict.blockers;
        appendEvent({
          type: 'sevo_gate_verdict',
          pipelineId,
          stageId,
          conclusion: gateVerdict.conclusion,
          blockerCount: verdictBlockers.length,
        });
      } else {
        const succeeded = evt?.status === 'succeeded' || evt?.exitCode === 0;
        outcome = succeeded ? 'passed' : 'failed';
      }

      // FR-E04: Substantial failure override — output too short with no files = real failure
      if (outcome === 'passed' && detectSubstantialFailure(evt?.result || evt)) {
        outcome = 'failed';
        appendEvent({ type: 'sevo_substantial_failure_override', pipelineId, stageId });
      }

      // FR-E02: Artifact verification — expected output files must exist
      if (outcome === 'passed') {
        try {
          const verifyEngine = await getPipelineEngine();
          const verifyState = verifyEngine ? verifyEngine.load(pipelineId) : null;
          if (verifyState) {
            const artifactCheck = verifyStageArtifacts(stageId, verifyState);
            if (!artifactCheck.verified) {
              outcome = 'failed';
              appendEvent({
                type: 'sevo_artifact_verification_failed',
                pipelineId, stageId,
                missingFiles: artifactCheck.missing,
              });
            }
          }
        } catch { /* fail-open: verification error is non-fatal */ }
      }

      // ── FR-V09: Stranger Dry-Run Hard Gate for ux-acceptance ──
      // If ux-acceptance output contains P0 issues, force outcome to 'failed'.
      if (stageId === 'ux-acceptance' && outcome === 'passed') {
        try {
          const agentOutput = typeof (evt?.result || evt?.output) === 'string'
            ? (evt?.result || evt?.output)
            : JSON.stringify(evt?.result || evt?.output || '');
          const p0Pattern = /P0|p0|blocker|阻断|stranger.*cannot|stranger.*stuck|无法完成/i;
          if (p0Pattern.test(agentOutput)) {
            outcome = 'failed';
            appendEvent({
              type: 'sevo_stranger_dryrun_gate_fail',
              pipelineId,
              stageId,
              reason: 'Stranger dry-run walkthrough found P0 issues',
            });
          }
        } catch { /* fail-open */ }
      }

      // ── A-6: wow-harness guard findings → gate blockers ──
      // Map P0 findings to MUST blockers, P1 to SHOULD issues.
      // Only applies to gate stages; fail-open on any error.
      if (gateVerdict) {
        try {
          const whFindings = getWowHarnessFindings();
          if (whFindings && whFindings.findings.length > 0) {
            let injectedMust = false;
            for (const f of whFindings.findings) {
              const sev = f.severity || 'P2';
              if (sev === 'P0') {
                verdictBlockers.push({
                  item: `[wow-harness P0] ${f.category || 'general'}: ${f.message || '(no message)'}`,
                  owner: 'wow-harness-guard',
                });
                injectedMust = true;
              } else if (sev === 'P1') {
                verdictBlockers.push({
                  item: `[wow-harness P1] ${f.category || 'general'}: ${f.message || '(no message)'}`,
                  owner: 'wow-harness-guard',
                });
              }
            }
            // P0 from wow-harness escalates gate to rejected
            if (injectedMust && outcome === 'passed') {
              outcome = 'rejected';
            } else if (!injectedMust && verdictBlockers.some(b => b.owner === 'wow-harness-guard') && outcome === 'passed') {
              outcome = 'conditional';
            }
            appendEvent({
              type: 'sevo_wow_harness_gate_inject',
              pipelineId,
              stageId,
              injectedCount: whFindings.findings.filter(f => (f.severity === 'P0' || f.severity === 'P1')).length,
              outcomeAfterInject: outcome,
            });
          }
        } catch { /* fail-open: wow-harness bridge error is non-fatal */ }
      }

      // ── AC Coverage Check for implement stage ──
      if (stageId === 'implement' && outcome === 'passed') {
        const agentOutput = evt?.output || evt?.result?.output || evt?.result?.message || '';
        const acCoverage = parseACCoverageChecklist(agentOutput);

        appendEvent({
          type: 'sevo_ac_coverage_parsed',
          pipelineId,
          stageId,
          found: acCoverage.found,
          totalItems: acCoverage.items.length,
          uncoveredCount: acCoverage.uncovered.length,
          partialCount: acCoverage.partial.length,
        });

        if (acCoverage.found && (acCoverage.uncovered.length > 0 || acCoverage.partial.length > 0)) {
          const acEngine = await getPipelineEngine();
          const acProjectSlug = getProjectSlug(pipelineId);
          // Load artifact paths for supplement prompt
          let implArtifactPaths = {};
          try {
            const currentState = acEngine ? acEngine.load(pipelineId) : null;
            if (currentState) {
              implArtifactPaths = collectArtifactPathsFromMapper(currentState);
            }
          } catch { /* best-effort */ }

          const supplementStageId = `${stageId}-ac-supplement`;
          const supplementPrompt = buildACSupplementPrompt(
            pipelineId, acProjectSlug,
            acCoverage.uncovered, acCoverage.partial,
            implArtifactPaths,
          );
          const implMapping = getStageMapping('implement');

          const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
          if (!existing.some(e => e.stageId === supplementStageId)) {
            existing.push({
              stageId: supplementStageId,
              label: encode(getProjectSlug(pipelineId), supplementStageId),
              taskDescription: supplementPrompt,
              agentId: implMapping?.agentId || null,
              timeout: implMapping?.timeout || 1200,
            });
            sevoGlobal.pendingAdvances.set(pipelineId, existing);
          }

          sevoGlobal.pendingNotices.push(
            `[SEVO AC Coverage Gap] Pipeline ${pipelineId} (${acProjectSlug}) implement stage has ` +
            `${acCoverage.uncovered.length} uncovered + ${acCoverage.partial.length} partial ACs.\n` +
            `A supplement task has been queued to complete coverage.`
          );

          // Don't advance to review yet — wait for supplement to complete
          appendEvent({
            type: 'sevo_ac_supplement_queued',
            pipelineId,
            supplementStageId,
            uncoveredACs: acCoverage.uncovered.map(a => a.id),
            partialACs: acCoverage.partial.map(a => a.id),
          });
          return;
        }

        // FR-S05: Inject AC coverage summary into review stage for auditor verification
        if (acCoverage.found && acCoverage.items.length > 0) {
          const covLines = acCoverage.items.map(i => `  ${i.id} | ${i.status} | ${i.detail}`).join('\n');
          addSupplement(pipelineId, 'review',
            `[AC Coverage Report — implement stage]\n` +
            `Total: ${acCoverage.items.length} | Covered: ${acCoverage.items.filter(i => i.status === 'covered').length}\n` +
            `Verify each claim during review:\n${covLines}`
          );
        }
      }

      // ── FR-O15: Refresh FR tracking on any SEVO task completion ──
      if (outcome === 'passed' && FR_TRACKING_STAGES.has(stageId)) {
        try {
          const frEngine = await getPipelineEngine();
          const frState = frEngine ? frEngine.load(pipelineId) : null;
          if (frState) {
            const frResult = refreshFRTracking(pipelineId, frState);
            if (frResult) {
              appendEvent({
                type: 'sevo_fr_tracking_refreshed',
                pipelineId,
                stageId,
                totalFRs: frResult.total.length,
                completedFRs: frResult.completed.length,
                remainingFRs: frResult.remaining.length,
                remaining: frResult.remaining,
              });
            }
          }
        } catch { /* fail-open */ }
      }

      // FR-E05: Long document continuation — if output file is too short, queue continuation
      if (LONG_DOC_STAGES.has(stageId) && outcome === 'passed') {
        try {
          const ldEngine = await getPipelineEngine();
          const ldState = ldEngine ? ldEngine.load(pipelineId) : null;
          if (ldState) {
            const continuation = checkLongDocContinuation(stageId, pipelineId, ldState);
            if (continuation) {
              const contStageId = `${stageId}-continuation`;
              const mapping = getStageMapping(stageId);
              const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
              if (!existing.some(e => e.stageId === contStageId)) {
                existing.push({
                  stageId: contStageId,
                  label: encode(getProjectSlug(pipelineId), contStageId),
                  taskDescription: continuation.prompt,
                  agentId: mapping?.agentId || null,
                  timeout: mapping?.timeout || 1200,
                });
                sevoGlobal.pendingAdvances.set(pipelineId, existing);
              }
              appendEvent({
                type: 'sevo_long_doc_continuation_queued',
                pipelineId, stageId,
                filePath: continuation.filePath,
                lineCount: continuation.lineCount,
              });
              return; // don't advance yet — wait for continuation
            }
          }
        } catch { /* fail-open */ }
      }

      // Build artifacts from event (if any output files mentioned)
      const artifacts = [];
      if (evt?.outputFiles && Array.isArray(evt.outputFiles)) {
        for (const f of evt.outputFiles) {
          artifacts.push({
            id: `${stageId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            type: 'file',
            path: f,
            createdAt: nowIso(),
          });
        }
      }

      // ─── Review-Fix Loop (RFL) Interception ───
      const rfl = parseRflStage(stageId);
      const succeeded = outcome === 'passed';

      if (rfl?.type === 'fix') {
        const loopState = sevoGlobal.reviewFixLoops.get(pipelineId);
        if (!loopState) return;
        if (succeeded) {
          queueRflReval(pipelineId, rfl.origin, rfl.round);
          appendEvent({ type: 'sevo_rfl_fix_done', pipelineId, origin: rfl.origin, round: rfl.round });
        } else {
          const ps = getProjectSlug(pipelineId);
          sevoGlobal.pendingNotices.push(`[SEVO RFL] Pipeline ${pipelineId} (${ps}) fix failed (round ${rfl.round}). Stage: ${rfl.origin} | Error: ${evt?.error || 'unknown'}. Action: investigate manually.`);
          appendEvent({ type: 'sevo_rfl_fix_failed', pipelineId, origin: rfl.origin, round: rfl.round });
        }
        return;
      }

      if (rfl?.type === 'reval') {
        const loopState = sevoGlobal.reviewFixLoops.get(pipelineId);
        if (!loopState) return;
        const revalVerdict = parseGateVerdict(evt);
        const p0p1 = await extractP0P1FromVerdict(revalVerdict);
        const revalPassed = !revalVerdict || revalVerdict.conclusion === 'passed' || p0p1.length === 0;
        if (revalPassed) {
          sevoGlobal.reviewFixLoops.delete(pipelineId);
          updateRflStatus(pipelineId, 'resolved', loopState, { origin: rfl.origin, resolvedIssues: loopState.issues?.length || 0, round: rfl.round });
          appendEvent({ type: 'sevo_rfl_passed', pipelineId, origin: rfl.origin, rounds: rfl.round });
          const engine = await getPipelineEngine();
          if (engine) {
            try {
              const tr = engine.advance(pipelineId, { stageId: rfl.origin, outcome: 'passed', artifacts });
              appendEvent({ type: 'sevo_advanced', pipelineId, fromStage: tr.fromStage, toStage: tr.toStage, toStatus: tr.status });
              const ps = getProjectSlug(pipelineId);
              const pr = getProjectRoot(pipelineId);
              const state = engine.load(pipelineId);
              for (const sid of state.requiredStages) {
                if (state.stages[sid]?.status !== 'active') continue;
                const mapping = getStageMapping(sid);
                if (!mapping) continue;
                const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
                if (!existing.some(e => e.stageId === sid)) {
                  existing.push({ stageId: sid, label: encode(getProjectSlug(pipelineId), sid), taskDescription: buildTaskPrompt(sid, state, ps, pr), agentId: mapping.agentId, timeout: mapping.timeout });
                  sevoGlobal.pendingAdvances.set(pipelineId, existing);
                }
              }
            } catch (err) {
              appendEvent({ type: 'sevo_rfl_advance_error', pipelineId, origin: rfl.origin, error: String(err?.message || err) });
            }
          }
          return;
        }
        const nextRound = rfl.round + 1;
        if (nextRound > (loopState.maxRounds || MAX_RFL_ROUNDS)) {
          sevoGlobal.reviewFixLoops.delete(pipelineId);
          updateRflStatus(pipelineId, 'escalated', loopState, { origin: rfl.origin, round: rfl.round });
          const ps = getProjectSlug(pipelineId);
          sevoGlobal.pendingNotices.push(`[SEVO RFL Escalation] Pipeline ${pipelineId} (${ps}) — loop exhausted after ${rfl.round} rounds. Stage: ${rfl.origin} | Remaining: ${p0p1.map(i => '[' + i.severity + '] ' + i.item).join('; ')}. Action: manual intervention required.`);
          appendEvent({ type: 'sevo_rfl_escalated', pipelineId, origin: rfl.origin, rounds: rfl.round, remaining: p0p1.length });
          return;
        }
        loopState.round = nextRound;
        loopState.issues = p0p1;
        queueRflFix(pipelineId, rfl.origin, p0p1, nextRound);
        updateRflStatus(pipelineId, 'active', loopState, { origin: rfl.origin });
        appendEvent({ type: 'sevo_rfl_retry', pipelineId, origin: rfl.origin, round: nextRound, issueCount: p0p1.length });
        const ps = getProjectSlug(pipelineId);
        sevoGlobal.pendingNotices.push(`[SEVO RFL] Pipeline ${pipelineId} (${ps}) — round ${nextRound}/${loopState.maxRounds || MAX_RFL_ROUNDS} for "${rfl.origin}" (${p0p1.length} issues remain).`);
        return;
      }

      if (isReviewStage(stageId) && succeeded) {
        const p0p1 = await extractP0P1FromVerdict(gateVerdict);
        if (p0p1.length > 0 && !sevoGlobal.reviewFixLoops.has(pipelineId)) {
          sevoGlobal.reviewFixLoops.set(pipelineId, { stageId, issues: p0p1, round: 1, maxRounds: MAX_RFL_ROUNDS, startedAt: nowIso() });
          queueRflFix(pipelineId, stageId, p0p1, 1);
          updateRflStatus(pipelineId, 'active', { stageId, issues: p0p1, round: 1, maxRounds: MAX_RFL_ROUNDS }, { origin: stageId });
          const ps = getProjectSlug(pipelineId);
          appendEvent({ type: 'sevo_rfl_entered', pipelineId, reviewStageId: stageId, round: 1, issueCount: p0p1.length });
          sevoGlobal.pendingNotices.push(`[SEVO Review-Fix Loop] Pipeline ${pipelineId} (${ps}) — "${stageId}" found ${p0p1.length} P0/P1 issues. Auto-dispatching fix (round 1/${MAX_RFL_ROUNDS}).`);
          return;
        }
      }

      // Try core orchestrator+adapter path if enabled and available
      if (useCorePath) {
        const orchestrator = await getOrchestrator();
        const adapter = await getAdapter();

        if (orchestrator && adapter) {
          try {
            // Submit artifacts to orchestrator
            orchestrator.submitArtifacts(pipelineId, artifacts);

            // Evaluate gate and advance (this uses GateEngine internally)
            const result = orchestrator.evaluateAndAdvance(pipelineId);

            // Notify gate result via adapter
            adapter.notifyGateResult(stageId, result.verdict);

            appendEvent({
              type: 'sevo_orchestrator_advanced',
              pipelineId,
              stage: stageId,
              verdict: result.verdict.conclusion,
              nextStage: result.nextStage,
            });

            // Handle completion/next stages via core events or fallback
            if (result.nextStage) {
              // Queue next stage advances (same logic as before, but triggered from orchestrator)
              const projectSlug = getProjectSlug(pipelineId);
              const projectRootVal = getProjectRoot(pipelineId);
              const mapping = getStageMapping(result.nextStage);
              if (mapping) {
                const taskPrompt = buildTaskPrompt(result.nextStage, { requiredStages: [result.nextStage], stages: { [result.nextStage]: { status: 'active' } }, taskId: pipelineId }, projectSlug, projectRootVal);
                const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
                existing.push({
                  stageId: result.nextStage,
                  label: encode(getProjectSlug(pipelineId), result.nextStage),
                  taskDescription: taskPrompt,
                  agentId: mapping.agentId,
                  timeout: mapping.timeout,
                });
                sevoGlobal.pendingAdvances.set(pipelineId, existing);
              }
            }

            // Check if completed
            if (!result.nextStage && result.verdict.conclusion === 'passed') {
              appendEvent({ type: 'sevo_pipeline_completed', pipelineId });
              const projectSlug = getProjectSlug(pipelineId);
              sevoGlobal.pendingNotices.push(buildCompletionMessage(pipelineId, projectSlug));
              // Remove from active pipelines
              const active = loadActivePipelines();
              delete active.pipelines[pipelineId];
              saveActivePipelines(active);
              return;
            }

            // If failed, queue rework notice
            if (result.verdict.conclusion === 'rejected') {
              const projectSlug = getProjectSlug(pipelineId);
              sevoGlobal.pendingNotices.push(
                `[SEVO Rework Needed] Pipeline ${pipelineId} (${projectSlug}) stage "${stageId}" rejected.\n` +
                `Blockers: ${result.verdict.blockers.map(b => b.item).join(', ')}\n` +
                `Action: retry stage "${stageId}" or investigate.`
              );
              return;
            }

            // Successfully advanced via orchestrator
            return;
          } catch (orchErr) {
            appendEvent({
              type: 'sevo_orchestrator_error',
              pipelineId,
              stageId,
              error: String(orchErr?.message || orchErr),
            });
            // Fall through to fallback
          }
        }
      }

      // Fallback: use PipelineEngine (original path)
      const engine = await getPipelineEngine();
      if (!engine) {
        appendEvent({ type: 'sevo_engine_unavailable', pipelineId, stageId });
        return;
      }

      // Advance the pipeline
      let transition;
      try {
        transition = engine.advance(pipelineId, {
          stageId,
          outcome,
          artifacts,
          failureReason: outcome === 'passed' ? undefined
            : outcome === 'conditional' ? 'Gate conditional — SHOULD issues require rework'
            : outcome === 'rejected' ? (evt?.error || 'Gate rejected — MUST dimension failed')
            : (evt?.error || 'Task failed'),
        });
      } catch (advanceErr) {
        appendEvent({
          type: 'sevo_advance_error',
          pipelineId,
          stageId,
          error: String(advanceErr?.message || advanceErr),
        });
        return;
      }

      appendEvent({
        type: 'sevo_advanced',
        pipelineId,
        fromStage: transition.fromStage,
        toStage: transition.toStage,
        toStatus: transition.status,
      });

      // FR-O07: Update progress on stage advance
      const stageStatus = transition.status === 'passed' ? 'passed'
        : transition.status === 'active' ? 'active'
        : transition.status;
      updateStageProgress(pipelineId, stageId, stageStatus, null, nowIso());

      const projectSlug = getProjectSlug(pipelineId);
      const projectRootVal = getProjectRoot(pipelineId);

      // If pipeline completed
      if (transition.status === 'passed' || transition.status === 'skipped') {
        try {
          const complete = engine.isComplete(pipelineId);
          if (complete) {
            appendEvent({ type: 'sevo_pipeline_completed', pipelineId, singleAgentMode: !!sevoGlobal.agentPool?._isSingleAgent });
            try {
              const ledger = await getLedgerEngine();
              if (ledger && typeof ledger.record === 'function') {
                const ledgerMeta = {};
                if (sevoGlobal.agentPool?._isSingleAgent) {
                  ledgerMeta.singleAgentMode = true;
                  ledgerMeta.unverifiedDimensions = ['security', 'boundary-compliance', 'spec-consistency'];
                }
                ledger.record(pipelineId, ledgerMeta);
              }
            } catch { /* ledger is best-effort */ }

            sevoGlobal.pendingNotices.push(buildCompletionMessage(pipelineId, projectSlug));

            // Remove from active pipelines
            const active = loadActivePipelines();
            delete active.pipelines[pipelineId];
            saveActivePipelines(active);
            return;
          }
        } catch { /* isComplete check is best-effort */ }
      }

      // If gate rejected — MUST dimension failed, block pipeline
      if (outcome === 'rejected') {
        // ── AC Coverage Rate Check in Review Gate ──
        // When review stage rejects, check if AC coverage was part of the issue
        if (isReviewStage(stageId)) {
          const reviewOutput = evt?.output || evt?.result?.output || evt?.result?.message || '';
          const acCoverage = parseACCoverageChecklist(reviewOutput);
          if (acCoverage.found) {
            const totalACs = acCoverage.items.length;
            const coveredCount = acCoverage.items.filter(i => i.status === 'covered').length;
            const coverageRate = totalACs > 0 ? coveredCount / totalACs : 1;

            appendEvent({
              type: 'sevo_review_ac_coverage_check',
              pipelineId,
              stageId,
              totalACs,
              coveredCount,
              coverageRate: Math.round(coverageRate * 100),
              uncoveredIds: acCoverage.uncovered.map(a => a.id),
            });

            if (coverageRate < 1 && acCoverage.uncovered.length > 0) {
              verdictBlockers.push(
                ...acCoverage.uncovered.map(ac => ({
                  item: `[AC-UNCOVERED] ${ac.id}: ${ac.detail || 'not implemented'}`,
                  owner: 'ac-coverage-gate',
                }))
              );
            }
          }
        }

        sevoGlobal.pendingNotices.push(
          `[SEVO Gate Rejected] Pipeline ${pipelineId} (${projectSlug}) stage "${stageId}" — MUST dimension failed.\n` +
          `Blockers:\n${verdictBlockers.map(b => `  - [${b.owner}] ${b.item}`).join('\n')}\n` +
          `Action: pipeline blocked. Fix all blockers before retrying stage "${stageId}".`
        );
        return;
      }

      // If gate conditional — SHOULD issues need rework, generate fix tasks with retry strategy
      if (outcome === 'conditional') {
        const fixItems = verdictBlockers.map(b => `- [${b.owner}] ${b.item}`).join('\n');
const reworkStageId = `${stageId}:rework`;
        const fixTaskDescription =
          `[SEVO Conditional Rework] Stage "${stageId}" passed MUST checks but has SHOULD issues.\n` +
          `Issues to resolve:\n${fixItems}\n` +
          `Fix these issues, then re-submit stage "${stageId}" for gate review.`;

        const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
        let queuedTier = null;
        if (!existing.some(e => e.stageId === reworkStageId)) {
          const reworkMapping = getStageMapping(stageId);
          const reworkTier = reworkMapping?.tier ?? getTierFromAgentId(reworkMapping?.agentId ?? null);

          const retryEntry = buildRetryAdvanceEntry(
            pipelineId,
            reworkStageId,
            reworkTier,
            reworkMapping?.agentId ?? null,
            fixTaskDescription,
            reworkMapping?.timeout || 600,
          );

          if (retryEntry) {
            existing.push(retryEntry);
            sevoGlobal.pendingAdvances.set(pipelineId, existing);
            queuedTier = retryEntry.tier;
          }
        }

        sevoGlobal.pendingNotices.push(
          `[SEVO Gate Conditional] Pipeline ${pipelineId} (${projectSlug}) stage "${stageId}" — conditional pass.\n` +
          `SHOULD issues (${verdictBlockers.length}):\n${fixItems}\n` +
          (queuedTier
            ? `A rework task${queuedTier !== 'T4' ? ` (tier upgraded to ${queuedTier})` : ''} has been queued.`
            : `A rework task has been queued.`)
        );
        return;
      }

      // If non-gate stage failed — apply failure retry strategy
      if (outcome === 'failed') {
        // FR-O06: Detect substantial failure
        const substantialFailure = detectSubstantialFailure(evt?.result || evt);
        if (substantialFailure) {
          appendEvent({
            type: 'sevo_substantial_failure_action',
            pipelineId,
            stageId,
            outcome,
          });
        }

        const currentMapping = getStageMapping(stageId);
        const currentTier = currentMapping?.tier ?? getTierFromAgentId(currentMapping?.agentId ?? null);
        const currentAgentId = currentMapping?.agentId ?? null;
        const taskDescription = currentMapping
          ? buildTaskPrompt(stageId, engine.load(pipelineId), projectSlug, projectRootVal)
          : `Retry stage "${stageId}" for pipeline ${pipelineId}`;

        // FR-O06: Check if task description suggests split
        const splitCheck = checkTaskDescriptionSplitNeeded(taskDescription);
        const retryEntry = buildRetryAdvanceEntry(
          pipelineId,
          stageId,
          currentTier,
          currentAgentId,
          taskDescription,
          currentMapping?.timeout || 600,
        );

        if (retryEntry) {
          const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
          if (!existing.some(e => e.stageId === retryEntry.stageId && e.tier === retryEntry.tier)) {
            existing.push(retryEntry);
            sevoGlobal.pendingAdvances.set(pipelineId, existing);
          }
          sevoGlobal.pendingNotices.push(
            `[SEVO Rework] Pipeline ${pipelineId} (${projectSlug}) stage "${stageId}" failed.\n` +
            (retryEntry.tier !== currentTier
              ? `Tier upgraded ${currentTier}→${retryEntry.tier}. Retrying with ${retryEntry.agentId || 'auto-assigned'}.`
              : `Retrying stage "${stageId}" (same tier, attempt ${(sevoGlobal.failureHistory.get(`${pipelineId}:${stageId}`)?.attempts.length ?? 1)}).`) +
            (splitCheck ? `\nNote: ${splitCheck.suggestion}` : '')
          );
        } else {
          sevoGlobal.pendingNotices.push(
            `[SEVO Rework Needed] Pipeline ${pipelineId} (${projectSlug}) stage "${stageId}" failed.\n` +
            `Failure: ${evt?.error || 'unknown'}\n` +
            `Action: all tiers exhausted — manual intervention required for stage "${stageId}".`
          );
        }
        return;
      }

      // If advanced to new stage(s), queue advance notices
      // Load fresh state to find all active stages
      try {
        const state = engine.load(pipelineId);

        // ── FR-O15: Block stage advance if FRs remain incomplete ──
        if (FR_TRACKING_STAGES.has(stageId)) {
          const frTracking = loadFRTracking(pipelineId) || initFRTracking(pipelineId, state);
          if (frTracking && !isFRTrackingComplete(frTracking)) {
            appendEvent({
              type: 'sevo_fr_advance_blocked',
              pipelineId,
              stageId,
              remainingFRs: frTracking.remaining,
            });
            sevoGlobal.pendingNotices.push(
              `[SEVO FR Gate] Pipeline ${pipelineId} (${projectSlug}) — 阶段 "${stageId}" 有 ${frTracking.remaining.length} 个 FR 未完成：${frTracking.remaining.join(', ')}。\n` +
              `阻断推进到下一阶段。请先完成所有 FR。`
            );
            // Don't advance — remaining FRs block progression
            return;
          }
        }

        // ── Terminal Gap Scan — after verify, check all spec FRs covered ──
        if (stageId === 'verify') {
          try {
            const scanResult = await runTerminalGapScan(pipelineId);
            if (scanResult && !scanResult.allCovered) {
              if (scanResult.round < scanResult.maxRounds) {
                const implMapping = getStageMapping('implement');
                if (implMapping) {
                  const fixPrompt = buildTerminalGapFixPrompt(pipelineId, projectSlug, scanResult);
                  const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
                  existing.push({
                    stageId: 'implement',
                    label: encode(getProjectSlug(pipelineId), 'implement'),
                    taskDescription: fixPrompt,
                    agentId: implMapping.agentId,
                    timeout: implMapping.timeout,
                  });
                  sevoGlobal.pendingAdvances.set(pipelineId, existing);
                  sevoGlobal.pendingNotices.push(
                    `[SEVO 终局收敛] Pipeline ${pipelineId} (${projectSlug}) — 第 ${scanResult.round}/${scanResult.maxRounds} 轮扫描发现 ${scanResult.uncoveredFRs.length} 个未覆盖 FR：${scanResult.uncoveredFRs.join(', ')}。\n自动回到 implement 阶段修复。`
                  );
                  return;
                }
              } else {
                sevoGlobal.pendingNotices.push(
                  `[SEVO 终局收敛] Pipeline ${pipelineId} (${projectSlug}) — 收敛已达上限（${scanResult.maxRounds} 轮），仍有 ${scanResult.uncoveredFRs.length} 个未覆盖 FR：${scanResult.uncoveredFRs.join(', ')}。\n流水线暂停，需要人工介入。`
                );
                appendEvent({ type: 'sevo_terminal_gap_scan_exhausted', pipelineId, round: scanResult.round, uncoveredFRs: scanResult.uncoveredFRs });
                return;
              }
            } else {
              // allCovered === true — record terminal gap scan passed
              const active = loadActivePipelines();
              const pl = active.pipelines?.[pipelineId];
              if (pl) {
                pl.terminalGapScanPassed = true;
                pl.terminalGapScanPassedAt = nowIso();
                saveActivePipelines(active);
              }
              appendEvent({ type: 'sevo_terminal_gap_scan_passed', pipelineId });
            }
          } catch { /* fail-open: terminal gap scan error is non-fatal */ }
        }

        // ── Terminal Gap Scan Gate — block ledger advance without scan ──
        if (stageId === 'verify') {
          const active2 = loadActivePipelines();
          const pl2 = active2.pipelines?.[pipelineId];
          if (!pl2?.terminalGapScanPassed) {
            sevoGlobal.pendingNotices.push(
              `[SEVO 闭环门禁] Pipeline ${pipelineId} (${projectSlug}) — 终局差距扫描未通过，阻断推进到 ledger 阶段。请先完成 gap scan。`
            );
            appendEvent({ type: 'sevo_terminal_gate_blocked', pipelineId, reason: 'terminalGapScanPassed not set' });
            return;
          }
        }

        // ── FR-D09: Convergence Loop — re-trigger after fix implement ──
        if (stageId === 'implement') {
          const loop = getConvergenceLoop(pipelineId);
          if (loop && loop.currentIteration > 0 && loop.currentIteration < loop.maxIterations) {
            const mapping = getStageMapping(CONVERGENCE_STAGE_ID);
            if (mapping) {
              const taskPrompt = buildTaskPrompt(CONVERGENCE_STAGE_ID, { ...state, convergenceLoop: loop }, projectSlug, projectRootVal);
              const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
              existing.push({
                stageId: CONVERGENCE_STAGE_ID,
                label: encode(getProjectSlug(pipelineId), CONVERGENCE_STAGE_ID),
                taskDescription: taskPrompt,
                agentId: mapping.agentId,
                timeout: mapping.timeout,
              });
              sevoGlobal.pendingAdvances.set(pipelineId, existing);
              appendEvent({ type: 'sevo_convergence_retrigger', pipelineId, iteration: loop.currentIteration + 1 });
              sevoGlobal.pendingNotices.push(
                `[SEVO Convergence] 修复完成，重新触发差距分析（第 ${loop.currentIteration + 1}/${loop.maxIterations} 轮）。`
              );
              return; // Re-trigger convergence instead of normal advance
            }
          }
        }

        // ── FR-D09: Convergence Loop — trigger gap analysis ──
        if (shouldTriggerConvergence(stageId, pipelineId)) {
          const loop = getConvergenceLoop(pipelineId);
          if (loop && loop.currentIteration < loop.maxIterations) {
            const mapping = getStageMapping(CONVERGENCE_STAGE_ID);
            if (mapping) {
              const taskPrompt = buildTaskPrompt(CONVERGENCE_STAGE_ID, { ...state, convergenceLoop: loop }, projectSlug, projectRootVal);
              const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
              existing.push({
                stageId: CONVERGENCE_STAGE_ID,
                label: encode(getProjectSlug(pipelineId), CONVERGENCE_STAGE_ID),
                taskDescription: taskPrompt,
                agentId: mapping.agentId,
                timeout: mapping.timeout,
              });
              sevoGlobal.pendingAdvances.set(pipelineId, existing);
              appendEvent({ type: 'sevo_convergence_triggered', pipelineId, iteration: loop.currentIteration + 1, triggerStage: stageId });
              sevoGlobal.pendingNotices.push(
                `[SEVO Convergence] Pipeline ${pipelineId} (${projectSlug}) — 触发终局差距分析（第 ${loop.currentIteration + 1}/${loop.maxIterations} 轮）。`
              );
              return; // Don't advance to normal next stage — convergence takes over
            }
          }
        }

        // ── FR-D09: Convergence Loop — handle gap analysis result ──
        if (stageId === CONVERGENCE_STAGE_ID) {
          const loop = getConvergenceLoop(pipelineId);
          if (loop) {
            const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
            const iteration = loop.currentIteration + 1;
            const reportRelPath = `${projectRootVal || '.'}/${DEFAULT_PATHS?.reports || 'reports'}/${projectSlug}-convergence-gap-${iteration}.md`;
            const reportAbsPath = path.resolve(wsRoot, reportRelPath);
            const gapResult = parseConvergenceGapReport(reportAbsPath);

            updateConvergenceLoop(pipelineId, {
              currentIteration: iteration,
              lastGapReport: reportRelPath,
            });

            appendEvent({
              type: 'sevo_convergence_result',
              pipelineId,
              iteration,
              hasP0P1: gapResult.hasP0P1,
              p0p1Count: gapResult.p0p1Count,
              reportPath: reportRelPath,
            });

            if (gapResult.hasP0P1 && iteration < loop.maxIterations) {
              // Loop back: queue implement stage with fix instructions
              const fixPrompt = `[SEVO Convergence Fix] Pipeline ${pipelineId} (${projectSlug})\n` +
                `Convergence gap analysis (iteration ${iteration}) found ${gapResult.p0p1Count} P0/P1 gaps.\n` +
                `Gap report: ${reportRelPath}\n` +
                `Read the gap report and fix all P0/P1 issues. Then re-run convergence analysis.`;
              const implMapping = getStageMapping('implement');
              if (implMapping) {
                const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
                existing.push({
                  stageId: 'implement',
                  label: encode(getProjectSlug(pipelineId), 'implement'),
                  taskDescription: fixPrompt,
                  agentId: implMapping.agentId,
                  timeout: implMapping.timeout,
                });
                sevoGlobal.pendingAdvances.set(pipelineId, existing);
                sevoGlobal.pendingNotices.push(
                  `[SEVO Convergence] 第 ${iteration} 轮差距分析发现 ${gapResult.p0p1Count} 个 P0/P1 问题，自动派发修复任务。`
                );
                return; // Loop back — don't advance normally
              }
            } else if (gapResult.hasP0P1 && iteration >= loop.maxIterations) {
              // Max iterations reached with P0 still present — pause pipeline
              sevoGlobal.pendingNotices.push(
                `[SEVO Convergence] Pipeline ${pipelineId} (${projectSlug}) — 收敛循环已达上限（${loop.maxIterations} 轮），仍有 ${gapResult.p0p1Count} 个 P0/P1 问题。\n` +
                `流水线暂停，等待用户决策。请查看报告：${reportRelPath}`
              );
              appendEvent({ type: 'sevo_convergence_max_reached', pipelineId, iteration, p0p1Count: gapResult.p0p1Count });
              return; // Pause — don't advance
            } else {
              // Converged — record to ledger and continue
              sevoGlobal.pendingNotices.push(
                `[SEVO Convergence] Pipeline ${pipelineId} (${projectSlug}) — 收敛完成（第 ${iteration} 轮），无 P0/P1 问题，流水线继续推进。`
              );
              appendEvent({ type: 'sevo_convergence_passed', pipelineId, iteration });
              // Fall through to normal advance logic below
            }
          }
        }

        // ── FR-08a: Commercialization Gate — evaluate when publish-generalization-gate completes ──
        let commercializationGateResult = null;
        if (stageId === 'publish-generalization-gate' && (outcome === 'passed' || outcome === 'conditional')) {
          try {
            const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
            const projDir = projectRootVal
              ? path.resolve(wsRoot, projectRootVal)
              : path.resolve(wsRoot, 'projects', projectSlug);
            commercializationGateResult = evaluateCommercializationGate(projDir);
            appendEvent({
              type: 'sevo_commercialization_gate',
              pipelineId,
              projectSlug,
              projectDir: projDir,
              result: commercializationGateResult,
            });
            if (commercializationGateResult.status === 'rejected') {
              sevoGlobal.pendingNotices.push(
                `[SEVO Commercialization Gate] Pipeline ${pipelineId} (${projectSlug}) — 商用化门禁未通过 (${commercializationGateResult.summary})。\n` +
                `检查项：\n${commercializationGateResult.checks.map(c => `  - ${c.status === 'passed' ? '✅' : c.status === 'conditional' ? '⚠️' : '❌'} ${c.id}: ${c.detail}`).join('\n')}\n` +
                `Action: 修复未通过项后重试 publish-generalization-gate 阶段。`
              );
            }
          } catch (cgErr) {
            appendEvent({ type: 'sevo_commercialization_gate_error', pipelineId, error: String(cgErr?.message || cgErr) });
          }
        }

        const activeStages = [];
        for (const sid of state.requiredStages) {
          if (state.stages[sid]?.status === 'active') {
            activeStages.push(sid);
          }
        }

        for (const nextStageId of activeStages) {
          const mapping = getStageMapping(nextStageId);
          if (!mapping) continue;

          let taskPrompt = buildTaskPrompt(nextStageId, state, projectSlug, projectRootVal);
          // FR-E01: Safety-net AC injection for implement stage
          if (nextStageId === 'implement') {
            taskPrompt = ensureACInjection(taskPrompt, state);
          }
          // FR-O15: Initialize FR tracking when entering a tracked stage
          if (FR_TRACKING_STAGES.has(nextStageId) && !loadFRTracking(pipelineId)) {
            initFRTracking(pipelineId, state);
          }

          // FR-04: Tripartite parallel review — advisory injection
          if (nextStageId === 'review') {
            const pool = sevoGlobal.agentPool || discoverAgents();
            const allAgentIds = pool._all ? [...pool._all].filter(id => id !== 'main') : [];

            // Discover agents for each review role
            const pmAgents = allAgentIds.filter(id => classifyAgentById(id) === 'pm');
            const auditAgents = allAgentIds.filter(id => classifyAgentById(id) === 'review');
            const uxAgents = allAgentIds.filter(id => classifyAgentById(id) === 'ux');

            // Determine if project has Web deliverables (LLM semantic check on spec content)
            let hasWebOutput = false;
            try {
              const specPath = path.resolve(
                sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT,
                projectRootVal || '.', 'specs', `${projectSlug}-product-requirements.md`
              );
              if (fs.existsSync(specPath)) {
                const specContent = fs.readFileSync(specPath, 'utf8').slice(0, 3000);
                const webCheckResult = await callLlmClassification(
                  'You determine whether a software project has Web UI deliverables (web pages, dashboards, browser-based interfaces, frontend components).\nRespond with ONLY "yes" or "no".',
                  `Project spec excerpt:\n${specContent}`,
                  `webOutput:${projectSlug}`,
                  'no',
                  10000,
                );
                hasWebOutput = webCheckResult.trim().toLowerCase().startsWith('yes');
              }
            } catch { /* best-effort */ }

            // Build tripartite advisory text
            const tripartiteLines = [
              '\n---\n[FR-04 Tripartite Parallel Review — Advisory]',
              'Spec requires three parallel review tracks for comprehensive quality assurance:',
              '',
              '1. **产品审查 (Product Review)** — PM 角色',
              '   - 检查需求覆盖度：每个 FR/AC 是否都有对应实现',
              '   - 检查产品逻辑完整性',
              `   - 建议 agent: ${pmAgents.length > 0 ? pmAgents[0] : '(无可用 PM agent，可跳过或用 general agent)'}`,
              '',
              '2. **代码审查 (Code Review)** — Auditor 角色',
              '   - 检查代码质量、安全性、测试覆盖',
              '   - 这是主审查任务（当前 task prompt 已包含）',
              `   - 建议 agent: ${auditAgents.length > 0 ? auditAgents[0] : '(auto-assign audit agent)'}`,
              '',
            ];

            if (hasWebOutput) {
              tripartiteLines.push(
                '3. **UX 审查 (UX Review)** — UX 角色',
                '   - 检查用户体验、视觉质量、交互流程',
                `   - 建议 agent: ${uxAgents.length > 0 ? uxAgents[0] : '(无可用 UX agent，可跳过)'}`,
                '',
              );
            } else {
              tripartiteLines.push(
                '3. **UX 审查** — 跳过（项目无 Web 产出）',
                '',
              );
            }

            tripartiteLines.push(
              '⚠️ 这是建议性的（advisory）：主会话可选择只派一路或全部三路并行。',
              '如果只派了代码审查，角色导航会提醒还有其他角色未覆盖。',
              '建议三路并行以获得最全面的质量保证。',
            );

            taskPrompt += tripartiteLines.join('\n');

            appendEvent({
              type: 'sevo_tripartite_review_advisory',
              pipelineId,
              pmAgents: pmAgents.slice(0, 3),
              auditAgents: auditAgents.slice(0, 3),
              uxAgents: uxAgents.slice(0, 3),
              hasWebOutput,
            });
          }

          const existing = sevoGlobal.pendingAdvances.get(pipelineId) || [];
          // Avoid duplicate queuing for same stage
          if (!existing.some(e => e.stageId === nextStageId)) {
            existing.push({
              stageId: nextStageId,
              label: encode(getProjectSlug(pipelineId), nextStageId),
              taskDescription: taskPrompt,
              agentId: mapping.agentId,
              timeout: mapping.timeout,
            });
            sevoGlobal.pendingAdvances.set(pipelineId, existing);
          }
        }

        // Update active pipelines tracking
        const active = loadActivePipelines();
        if (active.pipelines[pipelineId]) {
          active.pipelines[pipelineId].lastAdvancedAt = nowIso();
          active.pipelines[pipelineId].currentStage = stageId;
          saveActivePipelines(active);
        }
      } catch (loadErr) {
        appendEvent({
          type: 'sevo_load_state_error',
          pipelineId,
          error: String(loadErr?.message || loadErr),
        });
      }
    }), { priority: 200 });

    // ── Hook 2: before_prompt_build (priority 850) ──
    // Inject pending advance instructions into main session prompt.
    // Priority 850: runs after other plugins have done their injections.
    api.on('before_prompt_build', safeSevoHook('before_prompt_build', (evt, ctx) => {
      if (sevoGlobal.degraded) return null;

      // Only inject into main session
      const sessionKey = ctx?.sessionKey || '';
      if (!sessionKey.startsWith('agent:main:')) return null;

      // Check for timed-out stages — best-effort, fires each prompt cycle
      const expired = checkExpiredTimers();
      for (const timer of expired) {
        const projectSlug = getProjectSlug(timer.pipelineId);
        const mapping = getStageMapping(timer.stageId);
        const elapsedSec = Math.round((Date.now() - timer.startTime) / 1000);

        appendEvent({
          type: 'sevo_stage_timeout',
          pipelineId: timer.pipelineId,
          stageId: timer.stageId,
          agentId: timer.agentId,
          timeoutMs: timer.timeoutMs,
          elapsedMs: Date.now() - timer.startTime,
        });

        // Mark stage as timed_out in active pipelines
        const active = loadActivePipelines();
        if (active.pipelines?.[timer.pipelineId]) {
          active.pipelines[timer.pipelineId].lastTimeoutAt = nowIso();
          active.pipelines[timer.pipelineId].timedOutStage = timer.stageId;
          saveActivePipelines(active);
        }

        // Suggest upgrade tier for redispatch
        const currentTier = mapping?.tier || 'T1';
        const upgradeSuggestion = currentTier === 'T1' ? 'T2 (codex)'
          : currentTier === 'T2' ? 'T3 (human escalation)'
          : 'retry with same tier';

        sevoGlobal.pendingNotices.push(
          formatError('SEVO-E004', { stage: timer.stageId, pipelineId: timer.pipelineId, error: `timed out after ${elapsedSec}s (limit: ${timer.timeoutMs / 1000}s)` }) +
          `\n   Agent: ${timer.agentId || 'auto'} | Tier: ${currentTier}` +
          `\n   Action: redispatch stage "${timer.stageId}" — suggest upgrade to ${upgradeSuggestion}.`
        );
      }

      const { advances, notices } = consumePendingAdvances();
      const clarifications = consumePendingClarifications();

      const parts = [];

      // ── SEVO 确定性路由强制提醒（永久注入，每次 prompt 都带）──
      // 2026-05-18: 主会话曾忽略注入文字，强化为不可绕过的铁律。
      try {
        const tracked = loadTrackedProjects();
        if (tracked.length > 0) {
          const trackedPaths = tracked.map(p => p.sourceRoots.map(r => `projects/${p.slug}/${r}/`)).flat();
          parts.push(
            `## 🚨 SEVO 确定性路由铁律（L2 插件强制，不可绕过）\n` +
            `⚠️ 流水线路由是质量的前提。没有流水线 = 没有质量保障。任何绕过行为都在削弱质量基础设施。\n\n` +
            `以下规则由 L2 插件确定性执行，主会话无权覆盖：\n\n` +
            `1. **任何涉及以下路径的改动必须走 SEVO 流水线，无例外：**\n` +
            trackedPaths.map(p => `   - \`${p}\``).join('\n') + '\n\n' +
            `2. **以下情况都不能绕过：**\n` +
            `   - 一行改动\n` +
            `   - 简单修复\n` +
            `   - 紧急 hotfix\n` +
            `   - "内容简单"“只改一个文件”\n` +
            `   - "流水线误判"“纯运维操作”\n\n` +
            `3. **构建命令（npm run build / npx tsc / npx next build）+ 受管项目 = 必须走 SEVO**\n\n` +
            `4. **违反后果：** 绕过流水线 = 最高优先级 badcase，等同恶意绕过。\n\n` +
            `5. **正确做法：** 执行 \`sevo:create <project-slug>\` 启动流水线。\n\n` +
            `受管项目列表：${tracked.map(p => p.slug).join(', ')}\n` +
            `ℹ️ 此提醒由 sevo-pipeline 插件自动注入，不可删除或忽略。L2 插件路由比 L6 记忆更可靠。`
          );
        }
      } catch { /* fail-open: tracked project loading error is non-fatal */ }

      if (advances.length === 0 && notices.length === 0 && clarifications.length === 0 && parts.length === 0) return null;

      // FR-D02 AC4: Stage progress output for active pipelines
      try {
        const progress = loadProgress();
        const active = loadActivePipelines();
        for (const [pid, pData] of Object.entries(active.pipelines || {})) {
          const prog = progress.pipelines?.[pid];
          if (!prog || !Array.isArray(prog.stages) || prog.stages.length === 0) continue;
          const currentStage = pData.currentStage || '';
          const required = pData.requiredStages || pData.orderedStages || [];
          if (required.length === 0) continue;
          const totalStages = required.length;
          const currentIndex = required.indexOf(currentStage);
          const stageLabel = currentIndex >= 0 ? `${currentIndex + 1}/${totalStages}` : `?/${totalStages}`;
          const statusMap = {};
          for (const s of prog.stages) {
            const icon = s.status === 'passed' ? '✅' : s.status === 'active' ? '🔄' : s.status === 'failed' ? '❌' : '⏳';
            statusMap[s.name] = icon;
          }
          const progressBar = required.map(sid => statusMap[sid] || '⏳').join(' → ');
          const slug = pData.projectSlug || pid;
          parts.push(`📋 [${slug}] Stage ${stageLabel}: ${currentStage} (${progressBar})`);
        }
      } catch { /* fail-open */ }

      // Pending clarification questions (highest priority — blocking)
      for (const clar of clarifications) {
        parts.push(
          `[SEVO Clarification Needed] Pipeline ${clar.pipelineId} stage "${clar.stageId}" is blocked pending clarification.\n` +
          `Clarification ID: ${clar.clarificationId}\n` +
          `Questions:\n${clar.questions.map((q, i) => `  ${i + 1}. ${q}`).join('\n')}\n` +
          `To resume, reply with:\n[SEVO_CLARIFICATION_RESPONSE] #${clar.clarificationId}\n<your answers here>\n[/SEVO_CLARIFICATION_RESPONSE]`
        );
      }

      // Free-form notices
      for (const notice of notices) {
        parts.push(notice);
      }

      // ── FR-O15: Auto-dispatch remaining FRs ──
      try {
        const active = loadActivePipelines();
        for (const [pid, pData] of Object.entries(active.pipelines || {})) {
          const frT = pData?.frTracking;
          if (!frT || frT.remaining.length === 0) continue;
          const currentStage = pData.currentStage || pData.timedOutStage || '';
          if (!FR_TRACKING_STAGES.has(currentStage)) continue;
          parts.push(
            `[SEVO Auto-Advance] ${currentStage} 阶段还有 ${frT.remaining.length} 个 FR 未完成：${frT.remaining.join(', ')}。\n` +
            `已完成 ${frT.completed.length}/${frT.total.length}。请立即派发剩余 FR 的开发任务。`
          );
        }
      } catch { /* fail-open */ }

      // Stage advance instructions
      for (const adv of advances) {
        // FR-O09: Inject any pending supplements for this pipeline
        const supplements = consumeSupplements(adv.pipelineId);
        let finalTaskDescription = adv.taskDescription;
        if (supplements.length > 0) {
          finalTaskDescription = injectSupplementsIntoPrompt(adv.taskDescription, supplements);
        }

        const agentLine = adv.agentId
          ? `Recommended agentId: ${adv.agentId}`
          : 'agentId: auto-assign (use best available coding agent)';

        // FR-22: Role navigation — check if recommended agent matches stage's expected role
        let roleNavHint = '';
        if (adv.agentId && adv.stageId) {
          const nav = checkRoleNavigation(adv.stageId, adv.agentId);
          if (nav) {
            roleNavHint = `\n⚠️ Role mismatch: agent "${nav.targetAgentId}" (${nav.actualRole}) vs expected role "${nav.expectedRole}". ${nav.suggestion}`;
            appendEvent({
              type: 'sevo_role_navigation_advance',
              pipelineId: adv.pipelineId,
              stageId: nav.stageId,
              recommendedAgentId: nav.targetAgentId,
              expectedRole: nav.expectedRole,
              actualRole: nav.actualRole,
              suggestedAgents: nav.suggestedAgents,
            });
          }
        }

        // FR-22: Sort suggested agents by role relevance for this stage
        let roleRelevantAgents = '';
        if (adv.stageId) {
          const pool = sevoGlobal.agentPool || discoverAgents();
          const allAgentIds = pool._all ? [...pool._all].filter(id => id !== 'main') : [];
          const sorted = sortAgentsByStageRelevance(adv.stageId, allAgentIds);
          if (sorted.length > 0) {
            const expectedRole = getExpectedRole(adv.stageId);
            const topMatches = sorted.filter(id => classifyAgentById(id) === expectedRole).slice(0, 3);
            if (topMatches.length > 0) {
              roleRelevantAgents = `\nRole-matched agents for this stage: ${topMatches.join(', ')}`;
            }
          }
        }

        let commercializationGateBlock = '';
        if (isPublishStage(adv.stageId)) {
          const projectDir = getProjectDir(adv.pipelineId);
          const commercializationGateResult = evaluateCommercializationGate(projectDir);
          commercializationGateBlock = `${formatCommercializationGateResult(commercializationGateResult, projectDir)}\n\n`;
          appendEvent({
            type: 'sevo_commercialization_gate_injected',
            pipelineId: adv.pipelineId,
            stageId: adv.stageId,
            status: commercializationGateResult.status,
            projectDir,
          });
        }

        parts.push(
          `[SEVO Auto-Advance] Pipeline ${adv.pipelineId} → stage "${adv.stageId}".\n` +
          `${agentLine} | timeout: ${adv.timeout}s${roleNavHint}${roleRelevantAgents}\n` +
          `Label (required): ${adv.label || encode(getProjectSlug(adv.pipelineId), adv.stageId)}\n` +
          `Please spawn this task immediately:\n\n${commercializationGateBlock}${finalTaskDescription}`
        );
      }

      // ── A-5: wow-harness governance context (dual-track) ──
      // Merge wow-harness guard findings into SEVO prompt injection.
      // Fail-open: if wow-harness is unavailable, skip silently.
      try {
        const whFindings = getWowHarnessFindings();
        if (whFindings && whFindings.findings.length > 0) {
          const findingLines = whFindings.findings.map(f => {
            const blk = f.blocking ? ' [blocking]' : '';
            return `  - ${f.severity || 'P2'}${blk} ${f.category || 'general'}: ${f.message || '(no message)'}`;
          });
          parts.push(
            `[wow-harness Governance Signal] ${whFindings.findings.length} finding(s), max severity: ${whFindings.severity || 'P2'}${whFindings.blocking ? ' (blocking)' : ''}\n` +
            findingLines.join('\n')
          );
        }
        const whFragments = getWowHarnessInjectedFragments();
        if (whFragments.length > 0) {
          parts.push(
            `[wow-harness Active Context] Governance fragments in session: ${whFragments.join(', ')}`
          );
        }
      } catch { /* fail-open: wow-harness bridge error is non-fatal */ }

      if (parts.length === 0) return null;

      appendEvent({
        type: 'sevo_prompt_injected',
        advanceCount: advances.length,
        noticeCount: notices.length,
        clarificationCount: clarifications.length,
      });

      return { prependContext: parts.join('\n\n---\n\n') };
    }), { priority: 850 });

    // ── Hook 4: before_prompt_build (priority 100) — Pipeline Creation & Commands ──
    // Detect sevo:create, sevo:diagnose, sevo:retry, sevo:status, sevo:list, sevo:doctor markers in user message.
    // Runs before Hook 2 (850) so pendingAdvances are ready for injection.
    api.on('before_prompt_build', safeSevoHook('before_prompt_build_create', async (evt, ctx) => {
      const sessionKey = ctx?.sessionKey || '';
      if (!sessionKey.startsWith('agent:main:')) return null;

      const userMessage = extractUserMessage(evt);
      if (!userMessage) return null;

      // sevo:doctor — works even when degraded
      if (SEVO_DOCTOR_RE.test(userMessage)) {
        const result = handleDoctorCommand();
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_doctor_command' });
        return null;
      }

      // sevo:version — works even when degraded
      if (SEVO_VERSION_RE.test(userMessage)) {
        sevoGlobal.pendingNotices.push(`[SEVO] sevo-pipeline v${SEVO_VERSION}`);
        appendEvent({ type: 'sevo_version_command', version: SEVO_VERSION });
        return null;
      }

      // FR-24: sevo init — interactive setup wizard
      if (SEVO_INIT_RE.test(userMessage)) {
        try {
          const initResult = handleSevoInit();
          sevoGlobal.pendingNotices.push(initResult.content);
          appendEvent({ type: 'sevo_init_command', success: initResult.success, agentCount: initResult.agentCount });
        } catch (err) {
          sevoGlobal.pendingNotices.push(`[SEVO Init] Error: ${err.message}`);
          appendEvent({ type: 'sevo_init_command_failed', error: String(err.message) });
        }
        return null;
      }

      // FR-D02 AC2+AC3: sevo:quickstart — lightweight demo pipeline
      if (SEVO_QUICKSTART_RE.test(userMessage)) {
        const result = await handleQuickstartCommand();
        if (result) {
          sevoGlobal.pendingNotices.push(result.content);
          appendEvent({ type: 'sevo_quickstart_command' });
        } else {
          sevoGlobal.pendingNotices.push('[SEVO Quickstart] Failed to start quickstart pipeline. Check system status.');
          appendEvent({ type: 'sevo_quickstart_command_failed' });
        }
        return null;
      }

      // sevo:status — works even when degraded (reads state files only)
      const statusMatch = userMessage.match(SEVO_STATUS_RE);
      if (statusMatch) {
        const result = handleStatusCommand(statusMatch[1] || null);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_status_command', pipelineId: statusMatch[1] || null });
        return null;
      }

      // sevo:list — works even when degraded (reads state files only)
      if (SEVO_LIST_RE.test(userMessage)) {
        const result = handleListCommand();
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_list_command' });
        return null;
      }

      if (sevoGlobal.degraded) return null;

      // Handle sevo:diagnose command
      const diagnoseIntent = detectDiagnoseIntent(userMessage);
      if (diagnoseIntent) {
        const result = handleDiagnoseCommand(diagnoseIntent.pipelineId);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_diagnose_command', pipelineId: diagnoseIntent.pipelineId });
        return null;
      }

      // Handle sevo:retry command
      const retryIntent = detectRetryIntent(userMessage);
      if (retryIntent) {
        const result = handleRetryCommand(retryIntent.pipelineId, retryIntent.stageId);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_retry_command', pipelineId: retryIntent.pipelineId, stageId: retryIntent.stageId });
        return null;
      }

      // Handle sevo:pause command (FR-D03)
      const pauseIntent = detectPauseIntent(userMessage);
      if (pauseIntent) {
        const result = handlePauseCommand(pauseIntent.pipelineId);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_pause_command', pipelineId: pauseIntent.pipelineId });
        return null;
      }

      // Handle sevo:skip command (FR-D03)
      const skipIntent = detectSkipIntent(userMessage);
      if (skipIntent) {
        const result = handleSkipCommand(skipIntent.pipelineId, skipIntent.stageId);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_skip_command', pipelineId: skipIntent.pipelineId, stageId: skipIntent.stageId });
        return null;
      }

      // Handle sevo:resume command (FR-D03)
      const resumeIntent = detectResumeIntent(userMessage);
      if (resumeIntent) {
        const result = handleResumeCommand(resumeIntent.pipelineId);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_resume_command', pipelineId: resumeIntent.pipelineId });
        return null;
      }

      // FR-27: Handle sevo:from command (flexible stage entry)
      const fromIntent = detectFromIntent(userMessage);
      if (fromIntent) {
        const result = await handleFromCommand(fromIntent.projectSlug, fromIntent.targetStage);
        sevoGlobal.pendingNotices.push(result);
        appendEvent({ type: 'sevo_from_command', projectSlug: fromIntent.projectSlug, targetStage: fromIntent.targetStage });
        return null;
      }

      // Handle sevo:create command (FR-D08: three-tier routing)
      const intent = detectPipelineCreationIntent(userMessage);
      if (!intent) return null;

      const active = loadActivePipelines();
      for (const [pid, info] of Object.entries(active.pipelines || {})) {
        if (info.projectSlug === intent.projectSlug) {
          appendEvent({ type: 'sevo_create_skipped', reason: 'active_exists', projectSlug: intent.projectSlug, existingPipelineId: pid });
          sevoGlobal.pendingNotices.push(`[SEVO] Pipeline "${intent.projectSlug}" 已存在（id: ${pid.slice(0,8)}）。如需重建，先执行 sevo:delete ${intent.projectSlug}。`);
          return null;
        }
      }

      // FR-D08 AC1: evaluate tier (auto or forced)
      const tierResult = intent.forcedTier
        ? { tier: intent.forcedTier, reason: `user forced --tier ${intent.forcedTier}` }
        : await evaluateTier(userMessage, intent.task.scope);

      appendEvent({
        type: 'sevo_tier_evaluated',
        projectSlug: intent.projectSlug,
        tier: tierResult.tier,
        reason: tierResult.reason,
        forced: !!intent.forcedTier,
      });

      // FR-D08 AC2: Tier 1 — direct execution, no pipeline
      if (tierResult.tier === 1) {
        sevoGlobal.pendingNotices.push(
          `[SEVO Tier-1] "${intent.projectSlug}" — direct execution (no pipeline).\n` +
          `Reason: ${tierResult.reason}\n` +
          `Agent will execute the task directly without creating a pipeline or project folder.`
        );
        return null;
      }

      const routeFn = await getRoute();
      if (!routeFn) {
        appendEvent({ type: 'sevo_create_failed', reason: 'router_unavailable' });
        return null;
      }

      const routingResult = routeFn(intent.task);
      if (!routingResult.ok) {
        appendEvent({ type: 'sevo_create_failed', reason: 'routing_failed', error: routingResult.error?.message });
        return null;
      }

      const engine = await getPipelineEngine();
      if (!engine) {
        appendEvent({ type: 'sevo_create_failed', reason: 'engine_unavailable' });
        return null;
      }

      let state;
      try {
        state = engine.create(routingResult.value);
      } catch (createErr) {
        appendEvent({ type: 'sevo_create_failed', reason: 'engine_create_error', error: String(createErr?.message || createErr) });
        return null;
      }

      const wsRoot = sevoGlobal.runtimeConfig.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
      active.pipelines = active.pipelines || {};

      // FR-D09: Store project goal for convergence loop
      const projectGoal = intent.task.description || intent.task.title || '';

      // FR-D08 AC3: Tier 2 — lightweight pipeline, no project folder
      if (tierResult.tier === 2) {
        state.requiredStages = TIER2_STAGES;
        state.isTier2 = true;
        const projectRoot = '.';
        active.pipelines[state.pipelineId] = {
          projectSlug: intent.projectSlug,
          projectRoot,
          createdAt: nowIso(),
          lastAdvancedAt: nowIso(),
          tier: 2,
          skipReasons: {
            'spec-review-gate': 'Tier-2 轻量流水线跳过独立评审',
            'test-case-authoring': 'Tier-2 轻量流水线跳过独立测试用例编写',
            'contract': 'Tier-2 轻量流水线跳过架构设计',
            'contract-review-gate': 'Tier-2 轻量流水线跳过架构评审',
            'smoke-test': 'Tier-2 轻量流水线跳过独立冒烟测试',
          },
        };
        saveActivePipelines(active);
        initConvergenceLoop(state.pipelineId, projectGoal);

        appendEvent({
          type: 'sevo_pipeline_created_by_hook',
          pipelineId: state.pipelineId,
          projectSlug: intent.projectSlug,
          tier: 2,
          requiredStages: TIER2_STAGES,
        });

        for (const sid of TIER2_STAGES) {
          if (state.stages[sid]?.status === 'active') {
            const mapping = getStageMapping(sid);
            if (!mapping) continue;
            const taskPrompt = buildTaskPrompt(sid, state, intent.projectSlug, projectRoot);
            const entries = sevoGlobal.pendingAdvances.get(state.pipelineId) || [];
            entries.push({
              stageId: sid,
              label: encode(getProjectSlug(state.pipelineId), sid),
              taskDescription: taskPrompt,
              agentId: mapping.agentId,
              timeout: mapping.timeout,
            });
            sevoGlobal.pendingAdvances.set(state.pipelineId, entries);
            break;
          }
        }

        sevoGlobal.pendingNotices.push(
          `[SEVO Tier-2] Lightweight pipeline ${state.pipelineId} for "${intent.projectSlug}".\n` +
          `Reason: ${tierResult.reason}\n` +
          `Stages: ${TIER2_STAGES.join(' → ')}\n` +
          `Working in current directory (no project folder created).`
        );
        return null;
      }

      // FR-D08 AC4: Tier 3 — full pipeline (existing behavior)
      const projectRoot = `projects/${intent.projectSlug}`;
      const absProjectRoot = path.resolve(wsRoot, projectRoot);
      for (const sub of ['docs/design', 'docs/architecture/decisions', 'src', 'tests', 'reports', 'scripts']) {
        try { fs.mkdirSync(path.join(absProjectRoot, sub), { recursive: true }); } catch {}
      }
      active.pipelines[state.pipelineId] = {
        projectSlug: intent.projectSlug,
        projectRoot,
        createdAt: nowIso(),
        lastAdvancedAt: nowIso(),
        tier: 3,
      };
      saveActivePipelines(active);
      initConvergenceLoop(state.pipelineId, projectGoal);

      // FR-22: Inject SEVO Role templates for agents in the pool
      try {
        const pool = discoverAgents();
        injectAllRoleTemplates(pool);
      } catch { /* role injection is best-effort */ }

      appendEvent({
        type: 'sevo_pipeline_created_by_hook',
        pipelineId: state.pipelineId,
        projectSlug: intent.projectSlug,
        tier: 3,
        level: state.level,
        requiredStages: state.requiredStages,
      });

      for (const sid of state.requiredStages) {
        if (state.stages[sid]?.status === 'active') {
          const mapping = getStageMapping(sid);
          if (!mapping) continue;
          const taskPrompt = buildTaskPrompt(sid, state, intent.projectSlug, projectRoot);
          const entries = sevoGlobal.pendingAdvances.get(state.pipelineId) || [];
          entries.push({
            stageId: sid,
            label: encode(getProjectSlug(state.pipelineId), sid),
            taskDescription: taskPrompt,
            agentId: mapping.agentId,
            timeout: mapping.timeout,
          });
          sevoGlobal.pendingAdvances.set(state.pipelineId, entries);
          break;
        }
      }

      sevoGlobal.pendingNotices.push(
        `[SEVO Tier-3] Full pipeline ${state.pipelineId} for "${intent.projectSlug}" (level: ${state.level}).\n` +
        `Reason: ${tierResult.reason}\n` +
        `Stages: ${state.requiredStages.join(' → ')}`
      );

      return null;
    }), { priority: 100 });

    // ── Hook 3: before_tool_call (priority 800) ──
    // Inject sevo label into sessions_spawn when the task prompt contains SEVO pipeline markers.
    // Also optionally dispatch via Adapter.dispatchTask() if enabled.
    api.on('before_tool_call', safeSevoHook('before_tool_call', async (evt) => {
      if (sevoGlobal.degraded) return null;

      const toolName = String(evt?.toolName || '');
      if (toolName !== 'sessions_spawn') return null;

      const params = evt?.params || {};
      const existingLabel = String(params.label || '');

      // If already has a sevo label, don't touch it — but check role navigation (FR-22)
      if (isSevoLabel(existingLabel)) {
        const parsedLabel = decode(existingLabel);
        const spawnAgentId = params.agentId || '';
        if (parsedLabel && spawnAgentId) {
          const nav = checkRoleNavigation(parsedLabel.stageId, spawnAgentId);
          if (nav) {
            // Role mismatch detected — inject advisory notice (non-blocking)
            const resolvedPid = resolvePipelineId(parsedLabel.projectSlug);
            sevoGlobal.pendingNotices.push(
              `[SEVO Role Navigation] Pipeline ${parsedLabel.projectSlug} stage "${nav.stageId}": ` +
              `agent "${nav.targetAgentId}" has role "${nav.actualRole}" but stage expects "${nav.expectedRole}". ` +
              nav.suggestion
            );
            appendEvent({
              type: 'sevo_role_mismatch',
              pipelineId: resolvedPid || parsedLabel.projectSlug,
              stageId: nav.stageId,
              targetAgentId: nav.targetAgentId,
              expectedRole: nav.expectedRole,
              actualRole: nav.actualRole,
              suggestedAgents: nav.suggestedAgents,
            });
          }
        }
        appendInterceptEvent({ type: 'sevo_intercept', decision: 'allow', reason: 'has sevo label', agentId: params.agentId || null });
        return null;
      }

      // ── FR-S01-L2: SEVO Intercept Mode check ──
      if (SEVO_INTERCEPT_MODE === 'off') return null;

      // ── DETERMINISTIC PATH-MATCH INTERCEPTION (2026-05-18) ──
      // Runs BEFORE exemptions and LLM. Source path or build command → hard block.
      // Not subject to hotfix/infra/doc exemptions.
      {
        const taskTextForPath = String(params.prompt || params.taskDescription || params.task || params.message || '');
        const deterministicResult = deterministicPathIntercept(taskTextForPath);
        if (deterministicResult && deterministicResult.shouldBlock) {
          const detSlug = deterministicResult.slug;
          const detReason = deterministicResult.reason;
          const detBlockReason =
            `[SEVO 流水线] 此任务直接引用了受管项目源码路径或构建命令（${detReason}），` +
            `已由确定性规则强制走流水线（不经过 LLM 判断）。\n` +
            `必须走 SEVO 流水线：sevo:create ${detSlug}\n` +
            `⚠️ 此规则无例外：一行改动、简单修复、紧急 hotfix、"内容简单" 都不能绕过。` +
            `\n违反后果：绕过流水线 = 最高优先级 badcase，等同恶意绕过。`;

          appendInterceptEvent({
            type: 'sevo_intercept',
            decision: 'block',
            reason: detReason,
            source: 'deterministic-path-match',
            matchType: deterministicResult.matchType,
            slug: detSlug,
            agentId: params.agentId || null,
            taskTextPreview: taskTextForPath.slice(0, 200),
          });

          appendEvent({
            type: 'sevo_deterministic_intercept',
            shouldTrigger: true,
            reason: detReason,
            matchType: deterministicResult.matchType,
            slug: detSlug,
            agentId: params.agentId || null,
          });

          // Auto-create pipeline if not exists
          let autoCreated = false;
          try {
            const active = loadActivePipelines();
            const alreadyExists = Object.values(active.pipelines || {}).some(p => p.projectSlug === detSlug);
            if (!alreadyExists) {
              const routeFn = await getRoute();
              const engine = await getPipelineEngine();
              if (engine && routeFn) {
                try {
                  const taskId = `task-${detSlug}-${Date.now().toString(36)}`;
                  const routingResult = routeFn({
                    taskId,
                    title: detSlug,
                    description: taskTextForPath.slice(0, 500),
                    scope: { isNewModule: false },
                  });
                  if (!routingResult.ok) {
                    throw new Error(routingResult.error?.message || 'routing failed');
                  }
                  const state = engine.create(routingResult.value);
                  const wsRoot = sevoGlobal.runtimeConfig.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
                  const projectRoot = `projects/${detSlug}`;
                  const absProjectRoot = path.resolve(wsRoot, projectRoot);
                  for (const sub of ['docs/design', 'docs/architecture/decisions', 'src', 'tests', 'reports', 'scripts']) {
                    try { fs.mkdirSync(path.join(absProjectRoot, sub), { recursive: true }); } catch {}
                  }
                  active.pipelines = active.pipelines || {};
                  active.pipelines[state.pipelineId] = {
                    projectSlug: detSlug,
                    projectRoot,
                    createdAt: nowIso(),
                    lastAdvancedAt: nowIso(),
                    tier: 3,
                    routeSource: 'deterministic-auto-create',
                  };
                  saveActivePipelines(active);
                  for (const sid of state.requiredStages) {
                    if (state.stages[sid]?.status === 'active') {
                      const mapping = getStageMapping(sid);
                      if (!mapping) continue;
                      const taskPrompt = buildTaskPrompt(sid, state, detSlug, projectRoot);
                      const entries = sevoGlobal.pendingAdvances.get(state.pipelineId) || [];
                      entries.push({
                        stageId: sid,
                        label: encode(getProjectSlug(state.pipelineId), sid),
                        taskDescription: taskPrompt,
                        agentId: mapping.agentId,
                        timeout: mapping.timeout,
                      });
                      sevoGlobal.pendingAdvances.set(state.pipelineId, entries);
                      break;
                    }
                  }
                  autoCreated = true;
                  appendEvent({
                    type: 'sevo_auto_pipeline_created',
                    slug: detSlug,
                    pipelineId: state.pipelineId,
                    reason: 'deterministic_intercept_auto_create',
                    requiredStages: state.requiredStages,
                  });
                } catch (e) {
                  appendEvent({ type: 'sevo_auto_pipeline_failed', slug: detSlug, error: String(e?.message || e) });
                }
              }
            } else {
              // Pipeline already exists — still block (deterministic is unconditional)
              // But note it in the message
              sevoGlobal.pendingNotices.push(
                `[SEVO 流水线] 任务引用 ${detSlug} 源码路径/构建命令，已强制走流水线。流水线 "${detSlug}" 已存在，请通过 SEVO 流水线推进。`
              );
              return { block: true, blockReason: detBlockReason };
            }
          } catch (e) {
            appendEvent({ type: 'sevo_deterministic_auto_error', slug: detSlug, error: String(e?.message || e) });
          }

          const notice = autoCreated
            ? `[SEVO 流水线+自动创建] 任务引用 ${detSlug} 源码路径（${deterministicResult.matchType}），已自动创建流水线 "${detSlug}"，SEVO 将自动推进。原始 spawn 已阻止。`
            : `[SEVO 流水线] 任务引用 ${detSlug} 源码路径/构建命令（${detReason}），已强制走流水线。请执行 sevo:create ${detSlug}。`;
          sevoGlobal.pendingNotices.push(notice);

          return { block: true, blockReason: detBlockReason };
        }
      }

      // ── FR-27: from:<stage> label auto-creates pipeline from specified stage ──
      if (existingLabel && FROM_LABEL_RE.test(existingLabel)) {
        const fromMatch = existingLabel.match(FROM_LABEL_RE);
        const targetStageName = fromMatch[1].toLowerCase();
        const targetStageId = FROM_STAGE_MAP[targetStageName];
        const taskText27 = String(params.prompt || params.taskDescription || params.task || params.message || '');
        const slug = inferProjectSlug(taskText27) || `auto-${Date.now().toString(36)}`;

        if (targetStageId) {
          const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
          const projectRoot = `projects/${slug}`;
          const absProjectRoot = path.resolve(wsRoot, projectRoot);

          // Only auto-create if project dir exists (otherwise just allow through)
          if (fs.existsSync(absProjectRoot)) {
            try {
              const fromResult = await handleFromCommand(slug, targetStageName);
              sevoGlobal.pendingNotices.push(fromResult);
              appendEvent({ type: 'sevo_from_label_auto', label: existingLabel, projectSlug: slug, targetStage: targetStageName });
            } catch (err) {
              appendEvent({ type: 'sevo_from_label_failed', label: existingLabel, error: String(err?.message || err) });
            }
          }
        }

        appendInterceptEvent({ type: 'sevo_intercept', decision: 'allow', reason: 'from:<stage> label — flexible entry', agentId: params.agentId || null, label: existingLabel });
        return null; // allow the spawn through
      }

      // ── FR-S01-L2: Auto-evaluate SEVO trigger for unlabeled spawns ──
      const taskText = String(params.prompt || params.taskDescription || params.task || params.message || '');
      const agentId = String(params.agentId || '');

      // Step 1: Exemption whitelist check (before trigger evaluation)
      const exemption = checkSevoExemption(taskText, agentId, existingLabel);
      if (exemption) {
        appendInterceptEvent({
          type: 'sevo_intercept',
          decision: 'exempt',
          ruleId: exemption.ruleId,
          reason: exemption.description,
          agentId,
          taskTextPreview: taskText.slice(0, 200),
          ...(exemption.exemptedBy ? { exemptedBy: exemption.exemptedBy } : {}),
          ...(exemption.exemptReason ? { exemptReason: exemption.exemptReason } : {}),
        });
        return null; // allow
      }

      // Step 2: LLM semantic trigger evaluation (with keyword fallback)
      let triggerResult = await llmTriggerCheck(taskText, existingLabel);

      // If LLM was unavailable/timed out, try keyword fallback instead of pass-through
      if (triggerResult.source === 'fallback') {
        triggerResult = keywordFallbackCheck(taskText, existingLabel);
        appendInterceptEvent({
          type: 'sevo_intercept',
          decision: triggerResult.shouldTrigger ? 'trigger' : 'allow',
          reason: triggerResult.reasoning,
          level: triggerResult.level,
          source: triggerResult.source,
          matchedPatterns: triggerResult.matchedPatterns,
          agentId,
          taskTextPreview: taskText.slice(0, 200),
        });
      }

      if (!triggerResult.shouldTrigger) {
        appendInterceptEvent({
          type: 'sevo_intercept',
          decision: 'allow',
          reason: triggerResult.reasoning,
          level: triggerResult.level,
          source: triggerResult.source,
          agentId,
        });
        appendEvent({
          type: 'sevo_sdd_trigger_evaluated',
          shouldTrigger: false,
          reason: triggerResult.reasoning,
          source: triggerResult.source,
        });
        return null; // allow
      }

      // Step 3: Trigger hit — intercept based on mode
      const slug = inferProjectSlug(taskText) || `auto-${Date.now()}`;
      const triggerReason = triggerResult.matchedConditions.length > 0
        ? triggerResult.matchedConditions.join('; ')
        : triggerResult.reasoning;
      const blockReason =
        `[SEVO Pipeline Guard] 此任务命中 SEVO 路由条件（Level ${triggerResult.level}: ${triggerReason}），` +
        `已强制走流水线，原始 spawn 已阻止。请先执行 sevo:create ${slug} 启动 SEVO 流水线。` +
        `\n⚠️ 绝对禁止绕过：不得通过改 label、加 exempt、换措辞等方式规避流水线。除非 SEVO 进入死循环（同一任务被反复路由→创建→路由），否则必须无条件服从。` +
        `走流水线花时间烧 token 不是问题。你的记忆和判断可能已被上下文压缩稀释，L2 插件路由是比 L6 记忆更可靠的约束。`;

      appendInterceptEvent({
        type: 'sevo_intercept',
        decision: SEVO_INTERCEPT_MODE === 'block' ? 'block' : 'warn',
        reason: triggerReason,
        level: triggerResult.level,
        matchedConditions: triggerResult.matchedConditions,
        reasoning: triggerResult.reasoning,
        source: triggerResult.source,
        agentId,
        taskTextPreview: taskText.slice(0, 200),
        suggestedCommand: `sevo:create ${slug}`,
      });

      appendEvent({
        type: 'sevo_sdd_trigger_evaluated',
        shouldTrigger: true,
        reason: triggerReason,
        level: triggerResult.level,
        source: triggerResult.source,
        agentId: agentId || null,
        interceptMode: SEVO_INTERCEPT_MODE,
      });

      if (SEVO_INTERCEPT_MODE === 'block') {
        // Auto-create pipeline on intercept (fix bootstrap deadlock)
        let autoCreated = false;
        let existingAdvanced = false;
        try {
          const active = loadActivePipelines();
          const alreadyExists = Object.values(active.pipelines || {}).some(p => p.projectSlug === slug);
          if (!alreadyExists) {
            const engine = await getPipelineEngine();
            if (engine) {
              const taskText = String(params.task || params.message || params.taskDescription || '');
              const minimalRoute = { projectSlug: slug, projectRoot: `projects/${slug}`, scope: taskText.slice(0, 500), entryStage: 'specify' };
              try {
                engine.create(minimalRoute);
                autoCreated = true;
                appendEvent({ type: 'sevo_auto_pipeline_created', slug, reason: 'intercept_auto_create' });
              } catch (e) {
                appendEvent({ type: 'sevo_auto_pipeline_failed', slug, error: String(e?.message || e) });
              }
            }
          } else {
            // Pipeline already exists — allow through (don't block tasks for existing pipelines)
            appendInterceptEvent({ type: 'sevo_intercept', decision: 'allow', reason: `Pipeline for ${slug} already exists — allowing spawn through`, agentId: agentId || null });
            appendEvent({ type: 'sevo_existing_pipeline_passthrough', slug, reason: 'pipeline_exists_allow' });
            return null; // allow the spawn
          }
        } catch (e) {
          appendEvent({ type: 'sevo_auto_pipeline_error', slug, error: String(e?.message || e) });
        }

        const notice = autoCreated
          ? (existingAdvanced
            ? `[SEVO 流水线+推进] 流水线 "${slug}" 已存在，已将任务加入推进队列。原始 spawn 已阻止。`
            : `[SEVO 流水线+自动创建] 已自动创建流水线 "${slug}"，SEVO 将自动推进。原始 spawn 已阻止。`)
          : `[SEVO 流水线] 任务被 SEVO 流水线路由（Level ${triggerResult.level}: ${triggerReason}）。` +
            `请执行 sevo:create ${slug} 启动完整流水线。绝对禁止绕过。`;
        sevoGlobal.pendingNotices.push(notice);
        return {
          block: true,
          blockReason: autoCreated
            ? (existingAdvanced
              ? `[SEVO Pipeline Guard] 流水线 "${slug}" 已存在，已将任务加入推进队列。原始 spawn 已阻止。`
              : `[SEVO Pipeline Guard] 已自动创建流水线 "${slug}"。原始 spawn 已阻止，SEVO 将自动推进。`)
            : blockReason,
        };
      }

      // warn mode: don't block, but inject strong warning into prompt
      const warning = `\n\n⚠️ [SEVO 强警告] 此任务命中 SEVO 路由条件（Level ${triggerResult.level}: ${triggerReason}）。` +
        `必须先执行 sevo:create ${slug} 启动完整 SEVO 流水线。` +
        `绝对禁止绕过流水线。走流水线花时间烧 token 不是问题，L2 路由比 L6 记忆更可靠。`;
      const promptKey = params.prompt != null ? 'prompt'
        : params.taskDescription != null ? 'taskDescription'
        : params.task != null ? 'task'
        : params.message != null ? 'message'
        : null;
      if (promptKey && typeof params[promptKey] === 'string') {
        params[promptKey] = params[promptKey] + warning;
      }
      sevoGlobal.pendingNotices.push(
        `[SEVO FR-S01] Task auto-evaluated as SEVO-required (Level ${triggerResult.level}): ${triggerReason}. Consider creating a full SEVO pipeline (spec → review → plan → implement → verify).`
      );

      // ── FR-E05: Long document segmentation ──
      const longDocResult = await detectLongDocument(taskText);
      if (longDocResult.isLong) {
        const segmentNote = [
          '',
          '[SEVO Segmentation] This task is expected to produce a long document (>300 lines).',
          'Split your output into segments:',
          '  1. First segment: output directory structure + first half of chapters',
          '  2. Second segment: remaining chapters (append/edit, do NOT overwrite)',
          'Reference prior segment output paths in subsequent segments.',
        ].join('\n');
        if (params.prompt) params.prompt += segmentNote;
        if (params.taskDescription) params.taskDescription += segmentNote;
        appendEvent({
          type: 'sevo_long_doc_detected',
          estimatedLines: longDocResult.estimatedLines,
          agentId: params.agentId || null,
        });
      }

      // ── FR-E06: Parallel filename isolation injection ──
      const spawnAgentId = params.agentId || 'unknown';
      const isolationNote = `\n[SEVO Isolation] Your output files must include agent identifier "${spawnAgentId}" in filenames to prevent parallel write conflicts.`;
      if (params.prompt) params.prompt += isolationNote;
      if (params.taskDescription) params.taskDescription += isolationNote;

      const sevoLabel = findSevoLabelFromSpawnParams(params);
      if (!sevoLabel) return null;

      const pendingAdvance = getPendingAdvanceByLabel(sevoLabel);
      if (!pendingAdvance && !decode(sevoLabel)) return null;

      // Try using Adapter.dispatchTask() if enabled
      const useCorePath = sevoGlobal.runtimeConfig?.useOrchestratorAdapter === true;
      if (useCorePath) {
        const adapter = await getAdapter();
        if (adapter && adapter.dispatchTask) {
          try {
            const parsed = decode(sevoLabel);
            if (parsed) {
              const resolvedPid = resolvePipelineId(parsed.projectSlug);
              // Build TaskPayload for adapter
              const payload = {
                taskId: resolvedPid || parsed.projectSlug,
                title: `SEVO ${parsed.stageId} stage`,
                initialStage: parsed.stageId,
                stages: [parsed.stageId],
              };
              await adapter.dispatchTask(parsed.stageId, payload);
              appendEvent({
                type: 'sevo_adapter_dispatched',
                pipelineId: resolvedPid || parsed.projectSlug,
                stage: parsed.stageId,
              });
            }
          } catch (dispatchErr) {
            appendEvent({
              type: 'sevo_adapter_dispatch_error',
              error: String(dispatchErr?.message || dispatchErr),
            });
          }
        }
      }

      appendEvent({
        type: 'sevo_label_injected',
        label: sevoLabel,
        agentId: params.agentId || null,
      });

      // Start timeout timer for this stage
      const parsedLabel = decode(sevoLabel);
      if (parsedLabel) {
        const mapping = getStageMapping(parsedLabel.stageId);
        const timeoutMs = (mapping?.timeout || 600) * 1000;
        const resolvedPid = resolvePipelineId(parsedLabel.projectSlug);
        if (resolvedPid) {
          startStageTimer(
            resolvedPid,
            parsedLabel.stageId,
            timeoutMs,
            params.agentId || mapping?.agentId || null,
            sevoLabel,
          );
        }
      }

      return { nextParams: { ...params, label: sevoLabel } };
    }), { priority: 800 });

    // ── Hook 5: message_received (priority 200) — Clarification Response Handler ──
    // Detects [SEVO_CLARIFICATION_RESPONSE] markers in user/main-session messages,
    // resolves the pending clarification, and resumes the blocked stage.
    api.on('message_received', safeSevoHook('message_received_clarification', async (evt) => {
      if (sevoGlobal.degraded) return null;
      if (sevoGlobal.pendingClarifications.size === 0) return null;

      const message = evt?.message?.content || evt?.content || '';
      if (typeof message !== 'string') return null;

      const response = detectClarificationResponse(message);
      if (!response) return null;

      const { clarificationId, content } = response;
      const pending = sevoGlobal.pendingClarifications.get(clarificationId);
      if (!pending) {
        appendEvent({
          type: 'sevo_clarification_response_orphan',
          clarificationId,
          reason: 'no matching pending clarification',
        });
        return null;
      }

      // Remove from pending
      sevoGlobal.pendingClarifications.delete(clarificationId);

      appendEvent({
        type: 'sevo_clarification_resolved',
        clarificationId,
        pipelineId: pending.pipelineId,
        stageId: pending.stageId,
        responseLength: content.length,
      });

      // Forward to ClarificationCoordinator if available
      try {
        const coordinator = await ensureClarificationCoordinator();
        if (coordinator && typeof coordinator.resolveQuestions === 'function') {
          coordinator.resolveQuestions(clarificationId, {
            answers: content,
            resolvedAt: nowIso(),
            resolvedBy: 'user',
          });
        }
      } catch { /* coordinator is best-effort enhancement */ }

      // Resume the blocked stage by re-queuing it as a pending advance
      // with the clarification answers injected into the task description
      const stageMapping = getStageMapping(pending.stageId) || getStageMapping('implement');
      const resumeDescription =
        `[SEVO Stage Resume — Clarification Resolved]\n` +
        `Pipeline: ${pending.pipelineId}\n` +
        `Stage: ${pending.stageId}\n` +
        `Original questions:\n${pending.questions.map((q, i) => `  ${i + 1}. ${q}`).join('\n')}\n\n` +
        `User answers:\n${content}\n\n` +
        `Please continue executing stage "${pending.stageId}" with the above clarifications incorporated.`;

      const entries = sevoGlobal.pendingAdvances.get(pending.pipelineId) || [];
      entries.push({
        stageId: pending.stageId,
        label: pending.blockedLabel || encode(getProjectSlug(pending.pipelineId), pending.stageId),
        taskDescription: resumeDescription,
        agentId: stageMapping?.agentId || null,
        timeout: stageMapping?.timeout || 1200,
      });
      sevoGlobal.pendingAdvances.set(pending.pipelineId, entries);

      sevoGlobal.pendingNotices.push(
        `[SEVO Clarification Resolved] ${clarificationId} for pipeline ${pending.pipelineId} stage "${pending.stageId}" — resuming stage execution.`
      );

      return null;
    }), { priority: 200 });

    // ── Hook: before_prompt_build (priority 50) — Terminal Gap Check (终局差距检查) ──
    // L2-level enforcement: detect idle agents + pending work, inject auto-advance prompt.
    // Lightweight (<100ms): synchronous file reads only, no network.
    api.on('before_prompt_build', safeSevoHook('before_prompt_build_terminal_gap', (evt, ctx) => {
      // Only inject into main session
      const sessionKey = ctx?.sessionKey || '';
      if (!sessionKey.startsWith('agent:main:')) return null;

      // Read task board
      const boardPath = path.join(
        sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT,
        'logs', 'subagent-task-board.json'
      );
      let board;
      try {
        board = JSON.parse(fs.readFileSync(boardPath, 'utf8'));
      } catch {
        return null; // file missing or corrupt — silent skip
      }

      const tasks = board?.tasks || [];
      const runningTasks = tasks.filter(t => t.status === 'running');
      const queuedTasks = tasks.filter(t => t.status === 'queued');
      const runningAgentIds = new Set(runningTasks.map(t => t.agentId).filter(Boolean));

      // Read agent pool from openclaw.json
      let allAgentIds = [];
      try {
        const cfgPath = path.resolve(PLUGIN_DIR, '../../openclaw.json');
        const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
        allAgentIds = (cfg?.agents?.list || [])
          .map(a => a.id)
          .filter(id => id && id !== 'main');
      } catch {
        return null; // config unreadable — silent skip
      }

      const idleAgentIds = allAgentIds.filter(id => !runningAgentIds.has(id));
      const idleCount = idleAgentIds.length;

      // Count pending work: queued tasks + uncovered FRs from active pipelines
      let pendingWorkCount = queuedTasks.length;

      // Check active pipelines for uncovered FRs
      try {
        const active = loadActivePipelines();
        for (const pData of Object.values(active.pipelines || {})) {
          const frT = pData?.frTracking;
          if (frT && frT.remaining && frT.remaining.length > 0) {
            pendingWorkCount += frT.remaining.length;
          }
        }
      } catch { /* fail-open */ }

      // Also scan spec files for uncovered FRs (lightweight: count [ ] checkboxes)
      if (pendingWorkCount === 0) {
        try {
          const wsRoot = sevoGlobal.runtimeConfig?.workspaceRoot || DEFAULT_WORKSPACE_ROOT;
          const projectsDir = path.join(wsRoot, 'projects');
          if (fs.existsSync(projectsDir)) {
            const projects = fs.readdirSync(projectsDir, { withFileTypes: true });
            for (const proj of projects) {
              if (!proj.isDirectory()) continue;
              const specPath = path.join(projectsDir, proj.name, 'docs', 'product-requirements.md');
              try {
                const specContent = fs.readFileSync(specPath, 'utf8');
                // Count unchecked items: "- [ ]" pattern (common in spec FR tracking)
                const unchecked = (specContent.match(/^\s*-\s*\[ \]/gm) || []).length;
                pendingWorkCount += unchecked;
              } catch { /* spec file doesn't exist — skip */ }
            }
          }
        } catch { /* fail-open */ }
      }

      // Only inject if there are idle agents AND pending work
      if (idleCount === 0 || pendingWorkCount === 0) return null;

      appendEvent({
        type: 'sevo_terminal_gap_check_triggered',
        idleAgents: idleCount,
        pendingWork: pendingWorkCount,
        queuedTasks: queuedTasks.length,
        runningTasks: runningTasks.length,
      });

      return {
        prependContext: (
          `[SEVO Auto-Advance] 终局差距检查发现：${idleCount} 个空闲 agent，${pendingWorkCount} 个待办任务。\n` +
          `请在回复用户的同时派发下一批任务，不要只回复不行动。`
        ),
      };
    }), { priority: 50 });

    if (!sevoGlobal.registeredLogged) {
      api.logger.info(`[${PLUGIN_ID}] registered (active)`);
      sevoGlobal.registeredLogged = true;
    }
  },
};

export { llmTriggerCheck, keywordFallbackCheck, checkSevoExemption };
export default plugin;
