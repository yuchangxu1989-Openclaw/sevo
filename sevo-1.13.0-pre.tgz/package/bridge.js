/**
 * Bridge — lazy-load SEVO TypeScript compiled modules.
 * Graceful degrade: if dist/ doesn't exist, all exports return null.
 */

import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';
import { createRequire } from 'module';
import { normalizePlainObject, readStateConfig, resolveConfiguredPath } from './utils.js';

const PLUGIN_DIR = path.dirname(new URL(import.meta.url).pathname);
const DEFAULT_WORKSPACE_ROOT = path.resolve(PLUGIN_DIR, '../../workspace');
const DEFAULT_CACHE_TTL_MS = 30_000;

let _runtimeConfig = {};
let _distCheckCache = { value: null, checkedAt: 0, target: '' };

// Per-module availability — one module failing does NOT degrade others
let _pipelineFailed = null;
let _ledgerFailed = null;
let _routerFailed = null;
let _orchestratorFailed = null;
let _adapterFailed = null;
let _clarificationFailed = null;

let _PipelineEngine = null;
let _LedgerEngine = null;
let _route = null;
let _TaskOrchestrator = null;
let _OpenClawAdapter = null;
let _ClarificationModule = null;

let _pipelineCacheMeta = null;
let _ledgerCacheMeta = null;
let _routerCacheMeta = null;
let _orchestratorCacheMeta = null;
let _adapterCacheMeta = null;
let _clarificationCacheMeta = null;

function getConfig() {
  const stateConfig = readStateConfig();
  return { ...stateConfig, ...normalizePlainObject(_runtimeConfig) };
}

function getCacheTtlMs() {
  const config = getConfig();
  const rawTtl = config.cacheTtlMs ?? process.env.OPENCLAW_SEVO_CACHE_TTL_MS;
  const ttl = Number(rawTtl);
  return Number.isFinite(ttl) && ttl > 0 ? ttl : DEFAULT_CACHE_TTL_MS;
}

/**
 * Build a prioritized list of candidate dist/ paths for npm-installed sevo-pipeline.
 * Each entry: { distPath, dataPath, source }
 */
function getNpmFallbackCandidates() {
  const candidates = [];
  const seen = new Set();

  function addCandidate(pkgRoot, source) {
    const resolved = path.resolve(pkgRoot);
    if (seen.has(resolved)) return;
    seen.add(resolved);
    candidates.push({
      distPath: path.join(resolved, 'dist'),
      dataPath: path.join(resolved, 'data'),
      source,
    });
  }

  // 1. require.resolve — most reliable for finding the actual installed location
  try {
    const localRequire = createRequire(import.meta.url);
    const pkgJsonPath = localRequire.resolve('sevo-pipeline/package.json');
    addCandidate(path.dirname(pkgJsonPath), 'npm-require-resolve');
  } catch { /* not resolvable — skip */ }

  // 2. Well-known npm global prefix paths
  const globalPrefixes = [
    process.env.npm_config_prefix,
    '/usr/lib',
    '/usr/local/lib',
  ].filter(Boolean);
  for (const prefix of globalPrefixes) {
    addCandidate(path.join(prefix, 'node_modules', 'sevo-pipeline'), 'npm-global');
  }

  // 3. Local node_modules (relative to PLUGIN_DIR and cwd)
  addCandidate(path.join(PLUGIN_DIR, 'node_modules', 'sevo-pipeline'), 'npm-local');
  addCandidate(path.join(process.cwd(), 'node_modules', 'sevo-pipeline'), 'npm-local');

  return candidates;
}

function resolvePaths() {
  const config = getConfig();
  const workspaceRoot = resolveConfiguredPath(
    PLUGIN_DIR,
    config.workspaceRoot ?? process.env.OPENCLAW_WORKSPACE_ROOT,
    DEFAULT_WORKSPACE_ROOT,
  );
  const sevoRootCandidate =
    config.projectRoot ??
    process.env.SEVO_PROJECT_ROOT ??
    config.sevoRoot ??
    process.env.OPENCLAW_SEVO_ROOT ??
    null;
  const sevoRoot = resolveConfiguredPath(
    workspaceRoot,
    sevoRootCandidate,
    path.join(workspaceRoot, 'projects', 'sevo'),
  );
  const distPath = resolveConfiguredPath(
    sevoRoot,
    config.sevoDistPath ?? process.env.OPENCLAW_SEVO_DIST,
    path.join(sevoRoot, 'dist'),
  );
  const dataPath = resolveConfiguredPath(
    sevoRoot,
    config.sevoDataPath ?? process.env.OPENCLAW_SEVO_DATA,
    path.join(sevoRoot, 'data'),
  );

  // Primary path: local dev directory (existing behavior)
  if (fs.existsSync(distPath)) {
    return { workspaceRoot, sevoRoot, distPath, dataPath, source: 'local-dev' };
  }

  // Fallback: try npm-installed locations
  const candidates = getNpmFallbackCandidates();
  for (const candidate of candidates) {
    if (fs.existsSync(candidate.distPath)) {
      console.log(`[sevo-bridge] dist/ resolved via ${candidate.source}: ${candidate.distPath}`);
      return {
        workspaceRoot,
        sevoRoot: path.dirname(candidate.distPath),
        distPath: candidate.distPath,
        dataPath: candidate.dataPath,
        source: candidate.source,
      };
    }
  }

  // No dist/ found anywhere — return original paths (graceful degrade to null)
  console.log(`[sevo-bridge] dist/ not found in any location (local-dev: ${distPath}). Plugin will be no-op.`);
  return { workspaceRoot, sevoRoot, distPath, dataPath, source: 'none' };
}

function resetBridgeCaches() {
  _distCheckCache = { value: null, checkedAt: 0, target: '' };
  _pipelineFailed = null;
  _ledgerFailed = null;
  _routerFailed = null;
  _orchestratorFailed = null;
  _adapterFailed = null;
  _clarificationFailed = null;
  _PipelineEngine = null;
  _LedgerEngine = null;
  _route = null;
  _TaskOrchestrator = null;
  _OpenClawAdapter = null;
  _ClarificationModule = null;
  _pipelineCacheMeta = null;
  _ledgerCacheMeta = null;
  _routerCacheMeta = null;
  _orchestratorCacheMeta = null;
  _adapterCacheMeta = null;
  _clarificationCacheMeta = null;
}

export function setBridgeConfig(config) {
  _runtimeConfig = normalizePlainObject(config);
  resetBridgeCaches();
}

function getFileMtime(filePath) {
  try {
    return fs.statSync(filePath).mtimeMs;
  } catch {
    return null;
  }
}

function shouldUseCachedModule(cacheMeta, filePath, sourceMtime) {
  if (!cacheMeta || cacheMeta.filePath !== filePath) return false;
  if (cacheMeta.sourceMtime !== sourceMtime) return false;
  return (Date.now() - cacheMeta.loadedAt) < getCacheTtlMs();
}

function shouldBackoffFailure(failureMeta, filePath, sourceMtime) {
  if (!failureMeta || failureMeta.filePath !== filePath) return false;
  if (failureMeta.sourceMtime !== sourceMtime) return false;
  return (Date.now() - failureMeta.failedAt) < getCacheTtlMs();
}

async function importFreshModule(filePath, sourceMtime) {
  const moduleUrl = pathToFileURL(filePath).href;
  const cacheBust = sourceMtime ?? Date.now();
  return import(`${moduleUrl}?v=${encodeURIComponent(String(cacheBust))}`);
}

function checkDistExists() {
  const target = path.join(resolvePaths().distPath, 'pipeline', 'pipeline-engine.js');
  const now = Date.now();
  if (
    _distCheckCache.value !== null &&
    _distCheckCache.target === target &&
    (now - _distCheckCache.checkedAt) < getCacheTtlMs()
  ) {
    return _distCheckCache.value;
  }

  try {
    _distCheckCache = {
      value: fs.existsSync(target),
      checkedAt: now,
      target,
    };
  } catch {
    _distCheckCache = { value: false, checkedAt: now, target };
  }

  return _distCheckCache.value;
}

export function isAvailable() {
  const { sevoRoot, distPath, source } = resolvePaths();
  if (source === 'none') {
    return { available: false, reason: `dist/ not found in any location (last tried: ${distPath})` };
  }
  if (!fs.existsSync(distPath)) {
    return { available: false, reason: `dist/ not found: ${distPath}` };
  }
  const target = path.join(distPath, 'pipeline', 'pipeline-engine.js');
  if (!fs.existsSync(target)) {
    return { available: false, reason: `pipeline-engine.js not found: ${target}` };
  }
  return { available: true, reason: null, source };
}

export async function getPipelineEngine() {
  const { distPath, dataPath } = resolvePaths();
  const filePath = path.join(distPath, 'pipeline', 'pipeline-engine.js');
  const sourceMtime = getFileMtime(filePath);
  if (!checkDistExists() || !sourceMtime) return null;
  if (shouldBackoffFailure(_pipelineFailed, filePath, sourceMtime)) return null;
  if (_PipelineEngine && shouldUseCachedModule(_pipelineCacheMeta, filePath, sourceMtime)) {
    return _PipelineEngine;
  }

  try {
    const mod = await importFreshModule(filePath, sourceMtime);
    _PipelineEngine = new mod.PipelineEngine(dataPath);
    _pipelineCacheMeta = { filePath, sourceMtime, loadedAt: Date.now() };
    _pipelineFailed = null;
    return _PipelineEngine;
  } catch {
    _pipelineFailed = { filePath, sourceMtime, failedAt: Date.now() };
    _PipelineEngine = null;
    _pipelineCacheMeta = null;
    return null;
  }
}

export async function getLedgerEngine() {
  const { distPath, dataPath } = resolvePaths();
  const filePath = path.join(distPath, 'ledger', 'ledger-engine.js');
  const sourceMtime = getFileMtime(filePath);
  if (!checkDistExists() || !sourceMtime) return null;
  if (shouldBackoffFailure(_ledgerFailed, filePath, sourceMtime)) return null;
  if (_LedgerEngine && shouldUseCachedModule(_ledgerCacheMeta, filePath, sourceMtime)) {
    return _LedgerEngine;
  }

  try {
    const mod = await importFreshModule(filePath, sourceMtime);
    _LedgerEngine = new mod.LedgerEngine(dataPath);
    _ledgerCacheMeta = { filePath, sourceMtime, loadedAt: Date.now() };
    _ledgerFailed = null;
    return _LedgerEngine;
  } catch {
    _ledgerFailed = { filePath, sourceMtime, failedAt: Date.now() };
    _LedgerEngine = null;
    _ledgerCacheMeta = null;
    return null;
  }
}

export async function getRoute() {
  const { distPath } = resolvePaths();
  const filePath = path.join(distPath, 'router', 'router.js');
  const sourceMtime = getFileMtime(filePath);
  if (!checkDistExists() || !sourceMtime) return null;
  if (shouldBackoffFailure(_routerFailed, filePath, sourceMtime)) return null;
  if (_route && shouldUseCachedModule(_routerCacheMeta, filePath, sourceMtime)) {
    return _route;
  }

  try {
    const mod = await importFreshModule(filePath, sourceMtime);
    _route = mod.route;
    _routerCacheMeta = { filePath, sourceMtime, loadedAt: Date.now() };
    _routerFailed = null;
    return _route;
  } catch {
    _routerFailed = { filePath, sourceMtime, failedAt: Date.now() };
    _route = null;
    _routerCacheMeta = null;
    return null;
  }
}

export function getDataPath() {
  return resolvePaths().dataPath;
}

export async function getOrchestrator() {
  const { distPath, dataPath } = resolvePaths();
  const orchestratorPath = path.join(distPath, 'orchestrator', 'task-orchestrator.js');
  const sourceMtime = getFileMtime(orchestratorPath);
  if (!checkDistExists() || !sourceMtime) return null;
  if (shouldBackoffFailure(_orchestratorFailed, orchestratorPath, sourceMtime)) return null;
  if (_TaskOrchestrator && shouldUseCachedModule(_orchestratorCacheMeta, orchestratorPath, sourceMtime)) {
    return _TaskOrchestrator;
  }

  try {
    const mod = await importFreshModule(orchestratorPath, sourceMtime);
    const { default: createOrchestrator } = mod;
    if (typeof createOrchestrator === 'function') {
      _TaskOrchestrator = createOrchestrator({ dataPath });
    } else if (mod.TaskOrchestrator) {
      _TaskOrchestrator = new mod.TaskOrchestrator();
    } else {
      _orchestratorFailed = { filePath: orchestratorPath, sourceMtime, failedAt: Date.now() };
      return null;
    }
    _orchestratorCacheMeta = { filePath: orchestratorPath, sourceMtime, loadedAt: Date.now() };
    _orchestratorFailed = null;
    return _TaskOrchestrator;
  } catch {
    _orchestratorFailed = { filePath: orchestratorPath, sourceMtime, failedAt: Date.now() };
    _TaskOrchestrator = null;
    _orchestratorCacheMeta = null;
    return null;
  }
}

export async function getAdapter() {
  const { distPath, dataPath, workspaceRoot } = resolvePaths();
  const adapterPath = path.join(distPath, 'adapter', 'openclaw-adapter.js');
  const sourceMtime = getFileMtime(adapterPath);
  if (!checkDistExists() || !sourceMtime) return null;
  if (shouldBackoffFailure(_adapterFailed, adapterPath, sourceMtime)) return null;
  if (_OpenClawAdapter && shouldUseCachedModule(_adapterCacheMeta, adapterPath, sourceMtime)) {
    return _OpenClawAdapter;
  }

  try {
    const mod = await importFreshModule(adapterPath, sourceMtime);
    const { OpenClawAdapter: AdapterClass } = mod;
    if (!AdapterClass) {
      _adapterFailed = { filePath: adapterPath, sourceMtime, failedAt: Date.now() };
      return null;
    }
    const config = getConfig();
    _OpenClawAdapter = new AdapterClass({
      projectRoot: dataPath,
      workspaceRoot: workspaceRoot || config.workspaceRoot || DEFAULT_WORKSPACE_ROOT,
    });
    _adapterCacheMeta = { filePath: adapterPath, sourceMtime, loadedAt: Date.now() };
    _adapterFailed = null;
    return _OpenClawAdapter;
  } catch {
    _adapterFailed = { filePath: adapterPath, sourceMtime, failedAt: Date.now() };
    _OpenClawAdapter = null;
    _adapterCacheMeta = null;
    return null;
  }
}

export async function getClarificationCoordinator() {
  const { distPath, dataPath } = resolvePaths();
  const filePath = path.join(distPath, 'clarification', 'clarification-coordinator.js');
  const sourceMtime = getFileMtime(filePath);
  if (!checkDistExists() || !sourceMtime) return null;
  if (shouldBackoffFailure(_clarificationFailed, filePath, sourceMtime)) return null;
  if (_ClarificationModule && shouldUseCachedModule(_clarificationCacheMeta, filePath, sourceMtime)) {
    return _ClarificationModule;
  }

  try {
    const mod = await importFreshModule(filePath, sourceMtime);
    const { ClarificationCoordinator } = mod;
    if (!ClarificationCoordinator) {
      _clarificationFailed = { filePath, sourceMtime, failedAt: Date.now() };
      return null;
    }
    _ClarificationModule = { ClarificationCoordinator };

    // Also try to load AmbiguityDetector and ClarificationManager from sibling files
    try {
      const detectorPath = path.join(distPath, 'clarification', 'ambiguity-detector.js');
      const detectorMod = await importFreshModule(detectorPath, getFileMtime(detectorPath));
      if (detectorMod?.AmbiguityDetector) {
        _ClarificationModule.AmbiguityDetector = detectorMod.AmbiguityDetector;
      }
    } catch { /* optional — detector not critical */ }

    try {
      const managerPath = path.join(distPath, 'clarification', 'clarification-manager.js');
      const managerMod = await importFreshModule(managerPath, getFileMtime(managerPath));
      if (managerMod?.ClarificationManager) {
        _ClarificationModule.ClarificationManager = managerMod.ClarificationManager;
      }
    } catch { /* optional — manager not critical */ }

    _clarificationCacheMeta = { filePath, sourceMtime, loadedAt: Date.now() };
    _clarificationFailed = null;
    return _ClarificationModule;
  } catch {
    _clarificationFailed = { filePath, sourceMtime, failedAt: Date.now() };
    _ClarificationModule = null;
    _clarificationCacheMeta = null;
    return null;
  }
}

// ─── wow-harness Bridge (A-5 / A-6) ───────────────────────────────────────
// Read-only access to wow-harness guard signals and context fragments.
// Fail-open: returns empty/null when wow-harness runtime dirs are absent.

const _WOW_GUARD_SESSION_TTL_MS = 3_600_000; // 1 hour, matches guard_router.py

/**
 * Read wow-harness guard findings from .towow/guard/session-*.json.
 * Returns { severity, blocking, findings[] } or null if unavailable.
 */
export function getWowHarnessFindings() {
  const { workspaceRoot } = resolvePaths();
  const guardDir = path.join(workspaceRoot, '.towow', 'guard');
  try {
    if (!fs.existsSync(guardDir)) return null;
  } catch { return null; }

  const severityOrder = { P0: 0, P1: 1, P2: 2 };
  const now = Date.now();
  let maxSeverity = null;
  let blocking = false;
  const allFindings = [];

  let entries;
  try {
    entries = fs.readdirSync(guardDir).filter(f => f.startsWith('session-') && f.endsWith('.json'));
  } catch { return null; }

  for (const entry of entries) {
    const filePath = path.join(guardDir, entry);
    let data;
    try {
      data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch { continue; }

    const ts = data.timestamp || 0;
    if ((now - ts * 1000) > _WOW_GUARD_SESSION_TTL_MS) continue;

    for (const f of (data.findings || [])) {
      allFindings.push(f);
      const sev = f.severity || 'P2';
      if (maxSeverity === null || (severityOrder[sev] ?? 9) < (severityOrder[maxSeverity] ?? 9)) {
        maxSeverity = sev;
      }
      if (f.blocking) blocking = true;
    }
  }

  if (allFindings.length === 0) return null;
  return { severity: maxSeverity, blocking, findings: allFindings };
}

/**
 * Read wow-harness context fragments that were injected in the current session.
 * Returns string[] of fragment names, or empty array.
 */
export function getWowHarnessInjectedFragments() {
  const { workspaceRoot } = resolvePaths();
  const injectedPath = path.join(workspaceRoot, '.towow', 'guard', 'injected.json');
  try {
    if (!fs.existsSync(injectedPath)) return [];
    const data = JSON.parse(fs.readFileSync(injectedPath, 'utf8'));
    if ((Date.now() - (data.timestamp || 0) * 1000) > _WOW_GUARD_SESSION_TTL_MS) return [];
    return Array.isArray(data.fragments) ? data.fragments : [];
  } catch { return []; }
}
