/**
 * Label Protocol — encode/decode SEVO pipeline info in session labels.
 * Format: "sevo:<projectSlug>:<stageId>[:<attempt>]"
 *
 * Labels use human-readable project slugs (e.g. "kivo", "sevo") instead of UUIDs.
 * Internal pipeline tracking still uses UUIDs; resolution is handled by the caller.
 */

const PREFIX = 'sevo:';

export function encode(projectSlug, stageId, attempt = 1) {
  if (!projectSlug || typeof projectSlug !== 'string') {
    throw new Error(`encode: invalid projectSlug: ${projectSlug}`);
  }
  if (!stageId || typeof stageId !== 'string') {
    throw new Error(`encode: invalid stageId: ${stageId}`);
  }
  return `${PREFIX}${projectSlug}:${stageId}:${attempt}`;
}

export function decode(label) {
  if (label == null || label === '') return null;

  const normalized = typeof label === 'string' ? label : String(label);
  if (!normalized.startsWith(PREFIX)) return null;

  const parts = normalized.slice(PREFIX.length).split(':');
  if (parts.length < 2 || !parts[0] || !parts[1]) return null;
  return {
    projectSlug: parts[0],
    stageId: parts[1],
    attempt: parts[2] ? parseInt(parts[2], 10) || 1 : 1,
  };
}

export function isSevoLabel(label) {
  return typeof label === 'string' && label.startsWith(PREFIX);
}
