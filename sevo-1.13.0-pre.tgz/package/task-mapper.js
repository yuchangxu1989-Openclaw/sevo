/**
 * Task Mapper — StageId → Agent task description mapping.
 * Generates task prompts with pipeline context for each stage.
 */

import fs from 'fs';
import path from 'path';
import { normalizePlainObject, readStateConfig } from './utils.js';
import {
  specMethodology, contractMethodology,
  specReviewGateMethodology, contractReviewGateMethodology,
  reviewMethodology, implementMethodology,
  testCaseAuthoringMethodology, smokeTestMethodology,
  getUserJourneyTemplate,
} from './methodology.js';

const PLUGIN_DIR = path.dirname(new URL(import.meta.url).pathname);
const DEFAULT_WORKSPACE_ROOT = path.resolve(PLUGIN_DIR, '../..');
const OPENCLAW_ROOT = process.env.OPENCLAW_HOME || path.resolve(PLUGIN_DIR, '../../..');

// ─── Agent Discovery & Adaptive Mapping ───

const AGENT_ID_PATTERNS = [
  ['pm', /^pm-/],
  ['architecture', /^sa-/],
  ['review', /^audit-/],
  ['ux', /^ux-/],
  ['coding', /^(?:dev-\d+|cc|codex|opencode|free-code|hermes)$/],
];

const VALID_ROLES = new Set(['pm', 'architecture', 'review', 'coding', 'ux', 'general']);

function classifyAgent(entry) {
  const id = entry?.id;
  if (!id || id === 'main') return 'general';
  if (typeof entry.role === 'string' && VALID_ROLES.has(entry.role)) return entry.role;
  for (const [category, pattern] of AGENT_ID_PATTERNS) {
    if (pattern.test(id)) return category;
  }
  if (entry?.runtime?.type === 'acp') return 'coding';
  return 'general';
}

let _discoveredAgents = null;

function discoverAgents(configSource) {
  const pool = { coding: [], review: [], architecture: [], pm: [], ux: [], general: [] };

  let agentList;
  if (Array.isArray(configSource)) {
    agentList = configSource;
  } else {
    const configPath = typeof configSource === 'string'
      ? configSource
      : path.join(OPENCLAW_ROOT, 'openclaw.json');
    try {
      agentList = JSON.parse(fs.readFileSync(configPath, 'utf8'))?.agents?.list;
    } catch {
      pool._isSingleAgent = true;
      pool._all = new Set();
      return pool;
    }
  }

  if (!Array.isArray(agentList)) {
    pool._isSingleAgent = true;
    pool._all = new Set();
    return pool;
  }

  const allIds = new Set();
  for (const entry of agentList) {
    if (!entry?.id) continue;
    allIds.add(entry.id);
    const cat = classifyAgent(entry);
    pool[cat].push(entry.id);
  }

  const CODING_TIER_ORDER = ['cc', 'free-code', 'opencode', 'codex', 'hermes'];
  pool.coding.sort((a, b) => {
    const ai = CODING_TIER_ORDER.indexOf(a);
    const bi = CODING_TIER_ORDER.indexOf(b);
    return (ai === -1 ? 999 : ai) - (bi === -1 ? 999 : bi);
  });

  pool._all = allIds;
  pool._isSingleAgent = allIds.size === 0 ||
    (allIds.size === 1 && allIds.has('main'));

  if (pool._isSingleAgent && allIds.size > 0) {
    const soloId = [...allIds][0];
    for (const cat of Object.keys(pool)) {
      if (cat.startsWith('_')) continue;
      pool[cat] = [soloId];
    }
  }

  _discoveredAgents = pool;
  return pool;
}

const STAGE_FALLBACK_CHAIN = {
  'spec':                        ['pm', 'general'],
  'spec-review-gate':            ['architecture', 'review', 'general'],
  'test-case-authoring':         ['review', 'general'],
  'contract':                    ['architecture', 'coding', 'general'],
  'contract-review-gate':        ['review', 'architecture', 'general'],
  'implement':                   ['coding', 'general'],
  'review':                      ['review', 'general'],
  'smoke-test':                  ['review', 'general'],
  'ux-acceptance':               ['ux', 'general'],
  'e2e-verification':            ['coding', 'general'],
  'regression':                  ['coding', 'general'],
  'publish-generalization-gate': ['architecture', 'review', 'general'],
  'convergence-gap-analysis':    ['review', 'architecture', 'general'],
  'deploy':                      ['coding', 'general'],
  'verify':                      ['review', 'general'],
  'ledger':                      ['coding', 'general'],
};

function resolveAgent(stageId, pool) {
  if (!pool || pool._isSingleAgent) {
    return { agentId: 'main', resolved: 'single-agent-mode' };
  }

  const stageAgents = normalizePlainObject(getConfig().stageAgents);
  if (stageAgents[stageId] && pool._all?.has(stageAgents[stageId])) {
    return { agentId: stageAgents[stageId], resolved: 'stageAgents-override' };
  }

  const rec = DEFAULT_STAGE_AGENT_MAP[stageId];
  if (rec?.agentId && pool._all?.has(rec.agentId)) {
    return { agentId: rec.agentId, resolved: 'recommended' };
  }

  if (rec && rec.agentId === null && rec.tier) {
    const poolKey = TIER_TO_POOL[rec.tier] || rec.tier;
    const candidates = pool[poolKey] || [];
    if (candidates.length > 0) return { agentId: candidates[0], resolved: `auto-${poolKey}` };
  }

  const chain = STAGE_FALLBACK_CHAIN[stageId] || ['general'];
  for (const cat of chain) {
    const candidates = pool[cat] || [];
    if (candidates.length > 0) return { agentId: candidates[0], resolved: `fallback-${cat}` };
  }

  return { agentId: 'main', resolved: 'final-fallback' };
}

const TIER_TO_POOL = {
  'pm': 'pm', 'arch': 'architecture', 'audit': 'review', 'ux': 'ux',
  'T1': 'coding', 'T4': 'coding',
};

const DEFAULT_STAGE_AGENT_MAP = {
  'spec':                        { tier: 'pm',    agentId: null, timeout: 1800 },
  'spec-review-gate':            { tier: 'arch',  agentId: null, timeout: 1200 },
  'test-case-authoring':         { tier: 'audit', agentId: null, timeout: 1200 },
  'contract':                    { tier: 'arch',  agentId: null, timeout: 3600 },
  'contract-review-gate':        { tier: 'audit', agentId: null, timeout: 1200 },
  'implement':                   { tier: 'T1',    agentId: null, timeout: 1200 },
  'review':                      { tier: 'audit', agentId: null, timeout: 1200 },
  'smoke-test':                  { tier: 'audit', agentId: null, timeout: 1200 },
  'ux-acceptance':               { tier: 'ux',    agentId: null, timeout: 1800 },
  'e2e-verification':            { tier: 'T1',    agentId: null, timeout: 1200 },
  'regression':                  { tier: 'T1',    agentId: null, timeout: 1200 },
  'publish-generalization-gate': { tier: 'arch',  agentId: null, timeout: 1200 },
  'convergence-gap-analysis':    { tier: 'audit', agentId: null, timeout: 1800 },
  'deploy':                      { tier: 'T1',    agentId: null, timeout: 600  },
  'verify':                      { tier: 'audit', agentId: null, timeout: 600  },
  'ledger':                      { tier: 'T4',    agentId: null, timeout: 600  },
};

const DEFAULT_PATHS = {
  spec: 'docs/design',
  architecture: 'docs/architecture',
  architectureDecisions: 'docs/architecture/decisions',
  testCases: 'docs/design',
  reports: 'reports',
  scripts: 'scripts',
};

let _runtimeConfig = {};

function getConfig() {
  return { ...readStateConfig(), ...normalizePlainObject(_runtimeConfig) };
}

function getPath(key) {
  const configured = getConfig().paths;
  return configured?.[key] || DEFAULT_PATHS[key] || key;
}

function normalizeStageMapping(stageId, mapping) {
  if (!mapping || typeof mapping !== 'object' || Array.isArray(mapping)) {
    return DEFAULT_STAGE_AGENT_MAP[stageId] || null;
  }

  const fallback = DEFAULT_STAGE_AGENT_MAP[stageId] || {};
  const timeout = Number(mapping.timeout);

  return {
    tier: typeof mapping.tier === 'string' && mapping.tier.trim() ? mapping.tier : (fallback.tier ?? null),
    agentId: typeof mapping.agentId === 'string' && mapping.agentId.trim()
      ? mapping.agentId.trim()
      : (mapping.agentId === null ? null : (fallback.agentId ?? null)),
    timeout: Number.isFinite(timeout) && timeout > 0 ? timeout : (fallback.timeout ?? 600),
  };
}

function getResolvedStageAgentMap() {
  const configured = normalizePlainObject(getConfig().stageAgentMap);
  const merged = { ...DEFAULT_STAGE_AGENT_MAP, ...configured };
  const resolved = {};
  for (const stageId of Object.keys(merged)) {
    const normalized = normalizeStageMapping(stageId, merged[stageId]);
    if (normalized) {
      resolved[stageId] = normalized;
    }
  }
  return resolved;
}

export function setTaskMapperConfig(config) {
  _runtimeConfig = normalizePlainObject(config);
}

/**
 * Extract AC (Acceptance Criteria) items from spec artifact files.
 * Best-effort: tries multiple regex patterns to handle varied spec formats.
 * Returns array of { id: string, summary: string }.
 */
function extractACsFromSpec(artifactPaths) {
  const specPaths = artifactPaths['spec'] || [];
  if (specPaths.length === 0) return [];

  const acs = [];
  const seen = new Set();

  // Patterns to match AC lines in various formats:
  //   - AC-FR01-01: description
  //   - AC01: description
  //   - AC 1.1: description
  //   - - [ ] AC-FR01-01 description
  //   - **AC-FR01-01**: description
  const AC_PATTERNS = [
    /^\s*[-*]?\s*(?:\[[ x]\]\s*)?\*{0,2}(AC[-_]?[A-Z0-9][-A-Z0-9_.]*?)\*{0,2}\s*[:：]\s*(.+)/gmi,
    /^\s*\|\s*(AC[-_]?[A-Z0-9][-A-Z0-9_.]*?)\s*\|\s*(.+?)\s*\|/gmi,
  ];

  for (const specPath of specPaths) {
    let content;
    try {
      content = fs.readFileSync(specPath, 'utf8');
    } catch {
      continue;
    }

    for (const pattern of AC_PATTERNS) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(content)) !== null) {
        const id = match[1].trim();
        const summary = match[2].trim().replace(/\*{1,2}/g, '').replace(/\|.*$/, '').trim();
        if (!seen.has(id) && summary.length > 3) {
          seen.add(id);
          acs.push({ id, summary });
        }
      }
    }
  }

  return acs;
}

/**
 * Collect artifact paths from completed stages.
 */
function collectArtifactPaths(pipelineState) {
  const paths = {};
  if (!pipelineState?.stages) return paths;
  for (const [stageId, record] of Object.entries(pipelineState.stages)) {
    if (record.status === 'passed' && Array.isArray(record.artifacts)) {
      paths[stageId] = record.artifacts.map(a => a.path).filter(Boolean);
    }
  }
  return paths;
}

const SELF_REVIEW_CHECKLIST = [
  '',
  '## Single-Agent Self-Review Checklist (mandatory)',
  'You are both the implementer and the reviewer. Switch perspective and audit your own work.',
  '',
  '### Self-auditable dimensions (can be verified by the same agent):',
  '1. Format & naming: code style, file naming, consistent conventions',
  '2. File completeness: all expected files exist, no missing exports',
  '3. Test coverage: unit/integration tests exist for core paths',
  '4. Code quality: no dead code, no TODO/FIXME without tracking',
  '',
  '### Requires independent audit (mark as "unverified — single-agent mode"):',
  '5. Security: injection, auth bypass, data exposure risks',
  '6. Boundary compliance: changes stay within spec scope',
  '7. Spec consistency: implementation matches all ACs',
  '',
  'In the review report, clearly label dimensions 5-7 as "⚠ Not independently verified (single-agent mode)".',
  '',
];

function buildSingleAgentReviewChecklist() {
  return SELF_REVIEW_CHECKLIST;
}

/**
 * Build a task prompt for a given stage.
 */
function buildTaskPrompt(stageId, pipelineState, projectSlug, projectRoot) {
  const artifactPaths = collectArtifactPaths(pipelineState);
  const level = pipelineState?.level || 'L2+';
  const pipelineId = pipelineState?.pipelineId || 'unknown';
  // FR-O16: resolve output paths relative to projectRoot when provided
  const rp = (key) => projectRoot ? projectRoot + '/' + getPath(key) : getPath(key);

  const header = [
    `[SEVO Pipeline] ${pipelineId}`,
    `Project: ${projectSlug || 'unknown'} | Level: ${level} | Stage: ${stageId}`,
    '',
  ];

  if (_discoveredAgents?._isSingleAgent) {
    header.push('[SEVO Single-Agent Mode] 单 Agent 模式，请同时关注开发质量和审计视角', '');
  }

  // Reference prior artifacts
  const priorArtifacts = [];
  for (const [sid, paths] of Object.entries(artifactPaths)) {
    if (sid !== stageId && paths.length > 0) {
      priorArtifacts.push(`- ${sid}: ${paths.join(', ')}`);
    }
  }
  if (priorArtifacts.length > 0) {
    header.push('Prior stage artifacts:', ...priorArtifacts, '');
  }

  const stagePrompts = {
    'spec': [
      `Write the product requirements specification for project "${projectSlug}".`,
      `Output: ${rp('spec')}/product-requirements.md`,
      'Follow SEVO Phase 1 (Specify) conventions. Include FR list with acceptance criteria.',
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...specMethodology(),
      '',
      '## User Journey Requirement',
      'The spec MUST include a complete user journey map covering all 6 stages:',
      ...injectUserJourneyQuestions(),
    ],
    'spec-review-gate': [
      `Review the requirements specification for project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      'Evaluate: completeness, FR boundary clarity, testability of ACs, missing edge cases.',
      '',
      '## Stranger Test (外部用户视角)',
      'Evaluate the spec as if you are a developer who has NEVER seen this product:',
      '- Is there at least one external-user persona defined?',
      '- Does the spec have FRs covering the full path: discover → install → configure → first-use → error-recovery?',
      '- Are ALL prerequisites (tools, runtimes, env vars, configs) explicitly listed? Implicit assumptions = P0.',
      '- Do error/failure scenarios have corresponding FRs with actionable user guidance?',
      'Any gap in the above = P0 blocker.',
      '',
      'Conclusion: passed / conditional (list blockers) / rejected (list blocking issues).',
      `Output: ${rp('reports')}/${projectSlug}-spec-review.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...specReviewGateMethodology(),
    ],
    'test-case-authoring': [
      `Write test cases based on the frozen spec for project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      'One test case per AC minimum. Include test method, expected result, priority.',
      'For test cases involving browser/Web UI, each step MUST follow this template:',
      '  1. Navigate to: <URL or page name>',
      '  2. Action: <click/input/scroll target and value>',
      '  3. Expected: <what the user should see after the action>',
      `Output: ${rp('testCases')}/test-cases-${projectSlug}.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...testCaseAuthoringMethodology(),
    ],
    'contract': [
      `Write the architecture design (arc42) for project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      priorRef(artifactPaths, 'spec-review-gate'),
      'Follow arc42 template. Include ADRs for key decisions.',
      `Output: ${rp('architecture')}/arc42-architecture.md + ${rp('architectureDecisions')}/ADR-*.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...contractMethodology(),
    ],
    'contract-review-gate': [
      `Tripartite architecture review for project "${projectSlug}".`,
      priorRef(artifactPaths, 'contract'),
      'This review requires three perspectives:',
      '1. Product perspective (pm-01): spec-architecture alignment, user story coverage',
      '2. Development perspective (coding agent): implementation feasibility, tech debt risk',
      '3. Quality perspective (audit-01): testability, security, deployment feasibility',
      'Synthesize all three perspectives into a single verdict.',
      'Conclusion: passed / conditional / rejected.',
      `Output: ${rp('reports')}/${projectSlug}-contract-review.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...contractReviewGateMethodology(),
    ],
    'implement': buildImplementPrompt(projectSlug, artifactPaths, rp),
    'review': [
      `Quality audit the implementation of project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      priorRef(artifactPaths, 'contract'),
      priorRef(artifactPaths, 'implement'),
      'Check: spec compliance, code quality, security, test coverage.',
      ...(_discoveredAgents?._isSingleAgent ? buildSingleAgentReviewChecklist() : []),
      `Output: ${rp('reports')}/${projectSlug}-review.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...reviewMethodology(),
    ],
    'smoke-test': [
      `End-to-end smoke test for project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      priorRef(artifactPaths, 'implement'),
      'Execute from a real user perspective. For Web projects, operate the browser and attach screenshots.',
      'Smoke test must be executed by an independent verifier, not the original developer.',
      'Failure blocks all subsequent stages — fix and re-run until pass.',
      `Output: ${rp('reports')}/${projectSlug}-smoke-test.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
      ...smokeTestMethodology(),
    ],
    'ux-acceptance': [
      `UX acceptance review for project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      priorRef(artifactPaths, 'implement'),
      priorRef(artifactPaths, 'smoke-test'),
      'Use Playwright to operate real pages. Take screenshots for every key screen.',
      'Review each page for visual quality, interaction flow, and accessibility.',
      'Pass criteria: P0=0 and P1≤3.',
      'Pure backend/CLI products are exempt — mark as "skipped (no UI)" and pass.',
      '',
      '## UX Acceptance: User Journey Walkthrough (mandatory)',
      'Verify the product by walking through all 6 user journey stages:',
      ...injectUserJourneyQuestions(),
      'For each stage: describe what the user sees and does, then judge pass/fail.',
      `Output: ${rp('reports')}/ux-review-${projectSlug}-${new Date().toISOString().slice(0, 10)}.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
    ],
    'e2e-verification': [
      `End-to-end functional verification for project "${projectSlug}".`,
      priorRef(artifactPaths, 'spec'),
      priorRef(artifactPaths, 'implement'),
      priorRef(artifactPaths, 'test-case-authoring'),
      'Call core functions with real inputs and verify outputs match expectations.',
      `Place verification scripts in ${rp('scripts')}/test-${projectSlug}.js.`,
      'Attach actual run results as evidence in the report.',
      `Output: ${rp('reports')}/${projectSlug}-e2e-verification.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
    ],
    'regression': [
      `Run regression tests for project "${projectSlug}".`,
      priorRef(artifactPaths, 'test-case-authoring'),
      'Execute all test cases. Report pass/fail with evidence.',
      `Output: ${rp('reports')}/${projectSlug}-regression.md`,
    ],
    'publish-generalization-gate': [
      `Generalization review for project "${projectSlug}".`,
      'Check: is the implementation generic enough? Any hardcoded assumptions?',
      'Conclusion: passed / conditional / rejected.',
      `Output: ${rp('reports')}/${projectSlug}-generalization-review.md`,
      'Write the file using write/edit tools. Not writing the file = task failure.',
    ],
    'convergence-gap-analysis': buildConvergenceGapPrompt(projectSlug, pipelineState, rp),
    'deploy': [
      `Deploy project "${projectSlug}".`,
      'Follow deployment procedures from the architecture doc.',
    ],
    'verify': [
      `Post-deploy verification for project "${projectSlug}".`,
      'Smoke test the deployed system. Report results.',
      `Output: ${rp('reports')}/${projectSlug}-verify.md`,
    ],
    'ledger': [
      `Record pipeline completion in the SEVO ledger for project "${projectSlug}".`,
      'Collect all artifacts and write the ledger entry.',
      ...(_discoveredAgents?._isSingleAgent ? [
        '',
        'Ledger entry MUST include:',
        '  executionMode: "single-agent"',
        '  unverifiedDimensions: ["security", "boundary-compliance", "spec-consistency"]',
        'These fields are mandatory for quality traceability.',
      ] : [
        '',
        'Ledger entry MUST include:',
        '  executionMode: "multi-agent"',
      ]),
    ],
  };

  const body = stagePrompts[stageId] || [`Execute stage "${stageId}" for project "${projectSlug}".`];
  return [...header, ...body.filter(Boolean)].join('\n');
}

/**
 * Build the convergence gap analysis prompt (FR-D09).
 */
function buildConvergenceGapPrompt(projectSlug, pipelineState, rp) {
  const loop = pipelineState?.convergenceLoop || {};
  const iteration = (loop.currentIteration || 0) + 1;
  const maxIterations = loop.maxIterations || 3;
  const projectGoal = loop.projectGoal || '(no project goal recorded)';

  return [
    `Autonomous Convergence Gap Analysis for project "${projectSlug}".`,
    '',
    `Project Goal: ${projectGoal}`,
    `Iteration: ${iteration} / ${maxIterations}`,
    '',
    'Analyze the project against its stated goal. Check these 5 dimensions:',
    '1. Code robustness (error handling, edge cases)',
    '2. Documentation-code consistency (README examples vs actual behavior)',
    '3. Release packaging (package.json, LICENSE, .gitignore)',
    '4. Stranger UX walkthrough (clone → install → first-use → error-recovery)',
    '5. Configuration completeness (version consistency, dependency declarations)',
    '',
    'Output: gap report with each gap tagged P0/P1/P2.',
    'Format each gap as: `[P0|P1|P2] <dimension>: <description>`',
    `Write to: ${rp('reports')}/${projectSlug}-convergence-gap-${iteration}.md`,
    'Write the file using write/edit tools. Not writing the file = task failure.',
  ];
}

/**
 * Build the implement stage prompt with AC coverage requirements.
 */
function buildImplementPrompt(projectSlug, artifactPaths, rp) {
  const lines = [
    `Implement project "${projectSlug}" according to the spec and architecture.`,
    priorRef(artifactPaths, 'spec'),
    priorRef(artifactPaths, 'contract'),
    priorRef(artifactPaths, 'test-case-authoring'),
    'Follow the architecture design. Write tests. Commit with descriptive messages.',
    ...implementMethodology(),
  ];

  // Extract ACs from spec and inject into prompt
  const acs = extractACsFromSpec(artifactPaths);
  if (acs.length > 0) {
    lines.push('');
    lines.push('## Acceptance Criteria to implement (mandatory, cover every item):');
    for (const ac of acs) {
      lines.push(`- ${ac.id}: ${ac.summary}`);
    }
    lines.push('');
    lines.push('## AC Coverage Checklist (mandatory output)');
    lines.push('After implementation, you MUST output an AC coverage checklist in EXACTLY this format:');
    lines.push('```');
    lines.push('[AC-COVERAGE-START]');
    for (const ac of acs) {
      lines.push(`${ac.id} | covered | <file:line or description>`);
    }
    lines.push('[AC-COVERAGE-END]');
    lines.push('```');
    lines.push('For each AC, status must be one of: covered / partial / uncovered');
    lines.push('If uncovered, explain why (dependency missing / spec ambiguity / out of scope).');
    lines.push('Missing this checklist = task incomplete.');
  } else {
    // Fallback: still require best-effort AC self-check
    lines.push('');
    lines.push('After implementation, read the spec file and self-check every AC.');
    lines.push('Output an AC coverage checklist in this format:');
    lines.push('[AC-COVERAGE-START]');
    lines.push('<AC-ID> | <covered/partial/uncovered> | <location or reason>');
    lines.push('[AC-COVERAGE-END]');
    lines.push('Missing this checklist = task incomplete.');
  }

  return lines;
}

function priorRef(artifactPaths, stageId) {
  const paths = artifactPaths[stageId];
  if (!paths || paths.length === 0) return null;
  return `Reference (${stageId}): ${paths.join(', ')}`;
}

function injectUserJourneyQuestions() {
  const template = getUserJourneyTemplate();
  const lines = [];
  for (const stage of template.stages) {
    lines.push(`**${stage.name} (${stage.id})**:`);
    for (const q of stage.questions) {
      lines.push(`  - ${q}`);
    }
  }
  lines.push('');
  lines.push('Format: each stage answer must cover all its questions. Unanswered = blind spot in the product.');
  return lines;
}

/**
 * Get the agent mapping for a stage.
 * When discovered agents are available, resolves agentId adaptively.
 */
function getStageMapping(stageId) {
  const mapping = getResolvedStageAgentMap()[stageId] || null;
  if (!mapping) return null;
  if (_discoveredAgents) {
    const resolved = resolveAgent(stageId, _discoveredAgents);
    return { ...mapping, agentId: resolved.agentId };
  }
  return mapping;
}

/**
 * Parse FR items and their implementation status from a spec file.
 * Format: "#### FR-XXX: description ｜ status"
 * Returns [{ id, title, status: 'implemented'|'not_implemented' }]
 */
function parseFRsFromSpec(specPath) {
  let content;
  try {
    content = fs.readFileSync(specPath, 'utf8');
  } catch {
    return [];
  }

  const frs = [];
  const FR_RE = /^####\s+(FR-[A-Z0-9]+):\s*(.+?)(?:\s*[｜|]\s*(.+))?$/gm;
  let match;
  while ((match = FR_RE.exec(content)) !== null) {
    const id = match[1].trim();
    const title = match[2].trim();
    const rawStatus = (match[3] || '').trim().toLowerCase();
    // Precise status matching — exact token match to avoid false positives from substring collision
    const NOT_IMPL_RE = /^(?:未实现|not[_ ]implemented)$/;
    const IMPL_RE = /^(?:已实现|implemented)$/;
    const notImpl = NOT_IMPL_RE.test(rawStatus);
    const implemented = !notImpl && IMPL_RE.test(rawStatus);
    frs.push({ id, title, status: implemented ? 'implemented' : 'not_implemented' });
  }
  return frs;
}

/**
 * Parse FRs from all spec artifact paths in a pipeline.
 * Returns { total: string[], completed: string[], remaining: string[], details: object[] }
 */
function parseFRTrackingFromArtifacts(artifactPaths) {
  const specPaths = artifactPaths['spec'] || [];
  const allFRs = [];
  const seen = new Set();

  for (const sp of specPaths) {
    for (const fr of parseFRsFromSpec(sp)) {
      if (!seen.has(fr.id)) {
        seen.add(fr.id);
        allFRs.push(fr);
      }
    }
  }

  const total = allFRs.map(f => f.id);
  const completed = allFRs.filter(f => f.status === 'implemented').map(f => f.id);
  const remaining = allFRs.filter(f => f.status !== 'implemented').map(f => f.id);

  return { total, completed, remaining, details: allFRs };
}

export { buildTaskPrompt, getStageMapping, collectArtifactPaths, extractACsFromSpec, parseFRsFromSpec, parseFRTrackingFromArtifacts, DEFAULT_STAGE_AGENT_MAP, DEFAULT_PATHS, discoverAgents, resolveAgent, classifyAgent, STAGE_FALLBACK_CHAIN };
