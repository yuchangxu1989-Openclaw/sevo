/**
 * FR-24: Interactive Setup Wizard (`sevo init`).
 *
 * Guides first-time users through SEVO configuration:
 *   1. Detect environment (openclaw.json, agents)
 *   2. Recommend role assignments per agent
 *   3. Generate SOUL.md templates (FR-22)
 *   4. Auto-configure Single-Agent Mode when applicable
 *   5. Run Doctor check
 *   6. Output quick-start guide
 */

import fs from 'fs';
import path from 'path';
import { discoverAgents } from './task-mapper.js';
import { injectAllRoleTemplates, getAvailableRoles } from './role-templates.js';

const OPENCLAW_ROOT = process.env.OPENCLAW_HOME || path.resolve(
  path.dirname(new URL(import.meta.url).pathname), '../..',
);

// ── Environment Detection ──

function detectEnvironment() {
  const result = {
    openclawInitialized: false,
    configPath: null,
    agentCount: 0,
    agents: [],
    hasSevoConfig: false,
    errors: [],
  };

  const configPath = path.join(OPENCLAW_ROOT, 'openclaw.json');
  try {
    const raw = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    result.openclawInitialized = true;
    result.configPath = configPath;
    const list = raw?.agents?.list;
    if (Array.isArray(list)) {
      result.agents = list.filter(a => a?.id);
      result.agentCount = result.agents.length;
    }
    // Check if SEVO plugin is already configured
    const plugins = raw?.plugins;
    if (Array.isArray(plugins)) {
      result.hasSevoConfig = plugins.some(p => p?.name === 'sevo-pipeline' || p?.id === 'sevo-pipeline');
    }
  } catch (err) {
    result.errors.push(`openclaw.json not found or unreadable: ${err.message}`);
  }

  return result;
}

// ── Role Recommendation ──

const NAMING_HINTS = [
  ['pm', /^pm-/i],
  ['architecture', /^sa-/i],
  ['review', /^audit-/i],
  ['ux', /^ux-/i],
  ['coding', /^(?:dev-\d+|cc|codex|opencode|free-code|hermes)$/i],
];

function recommendRole(agent) {
  const id = agent.id;
  if (typeof agent.role === 'string' && getAvailableRoles().includes(agent.role)) {
    return { role: agent.role, source: 'explicit' };
  }
  for (const [role, pattern] of NAMING_HINTS) {
    if (pattern.test(id)) return { role, source: 'naming-convention' };
  }
  if (agent?.runtime?.type === 'acp') return { role: 'coding', source: 'runtime-type' };
  return { role: 'general', source: 'default' };
}

// ── Doctor Check (AC-4.92) ──

function runDoctorCheck(env, pool) {
  const checks = [];

  // 1. openclaw.json exists
  checks.push({
    name: 'openclaw.json',
    pass: env.openclawInitialized,
    detail: env.openclawInitialized ? 'found' : 'missing — run openclaw init first',
  });

  // 2. At least one agent
  checks.push({
    name: 'agents',
    pass: env.agentCount > 0,
    detail: env.agentCount > 0 ? `${env.agentCount} agent(s) detected` : 'no agents configured',
  });

  // 3. Role coverage — at least pm + coding covered
  const coveredRoles = new Set();
  for (const role of getAvailableRoles()) {
    if ((pool[role] || []).length > 0) coveredRoles.add(role);
  }
  const minRoles = ['pm', 'coding'];
  const missingMin = minRoles.filter(r => !coveredRoles.has(r));
  checks.push({
    name: 'role-coverage',
    pass: missingMin.length === 0 || pool._isSingleAgent,
    detail: pool._isSingleAgent
      ? 'single-agent mode — all roles handled by one agent'
      : missingMin.length === 0
        ? `roles covered: ${[...coveredRoles].join(', ')}`
        : `missing recommended roles: ${missingMin.join(', ')}`,
  });

  // 4. SEVO dist available
  const distPath = path.resolve(
    path.dirname(new URL(import.meta.url).pathname),
    '../../workspace/publish/sevo-pipeline/src/index.ts',
  );
  const distExists = fs.existsSync(distPath);
  checks.push({
    name: 'sevo-dist',
    pass: distExists,
    detail: distExists ? 'SEVO source available' : 'SEVO dist not found — some features may be limited',
  });

  const allPass = checks.every(c => c.pass);
  return { allPass, checks };
}

// ── Main Init Handler ──

/**
 * Execute the sevo init wizard.
 * Returns a structured result string for display to the user.
 */
function handleSevoInit() {
  const lines = [];
  lines.push('[SEVO Init] Starting interactive setup wizard...');
  lines.push('');

  // Step 1: Detect environment (AC-4.90)
  const env = detectEnvironment();
  if (!env.openclawInitialized) {
    lines.push('⚠️  openclaw.json not found.');
    lines.push('   Please run `openclaw init` first to initialize your environment,');
    lines.push('   then re-run `sevo init`.');
    return {
      content: lines.join('\n'),
      success: false,
      reason: 'host-not-initialized',
    };
  }
  lines.push(`✓ Environment detected: ${env.agentCount} agent(s) in openclaw.json`);

  // Step 2: Discover agents and recommend roles (AC-4.91)
  const pool = discoverAgents(env.agents);
  lines.push('');
  lines.push('── Agent Role Assignments ──');
  lines.push('');

  const assignments = [];
  for (const agent of env.agents) {
    const rec = recommendRole(agent);
    assignments.push({ id: agent.id, ...rec });
    const marker = rec.source === 'explicit' ? '(user-declared)' : `(${rec.source})`;
    lines.push(`  ${agent.id.padEnd(14)} → ${rec.role.padEnd(14)} ${marker}`);
  }

  // Step 3: Single-Agent Mode detection (AC-4.93)
  if (pool._isSingleAgent) {
    lines.push('');
    lines.push('ℹ️  Single-Agent Mode: all pipeline stages will be handled by one agent.');
    lines.push('   Quality assurance is reduced but the full pipeline remains functional.');
  }

  // Step 4: Inject SOUL.md templates (FR-22, AC-4.80)
  lines.push('');
  lines.push('── SOUL.md Template Injection ──');
  lines.push('');
  const injectionResults = injectAllRoleTemplates(pool);
  let injected = 0, skipped = 0, errors = 0;
  for (const r of injectionResults) {
    if (r.action === 'created' || r.action === 'appended') {
      lines.push(`  ✓ ${r.agentId}: ${r.action} SEVO Role section (${r.role})`);
      injected++;
    } else if (r.action === 'skipped') {
      lines.push(`  · ${r.agentId}: skipped (${r.reason})`);
      skipped++;
    } else {
      lines.push(`  ✗ ${r.agentId}: error — ${r.error}`);
      errors++;
    }
  }
  lines.push(`  Summary: ${injected} injected, ${skipped} skipped, ${errors} errors`);

  // Step 5: Doctor check (AC-4.92)
  lines.push('');
  lines.push('── Doctor Check ──');
  lines.push('');
  const doctor = runDoctorCheck(env, pool);
  for (const c of doctor.checks) {
    const icon = c.pass ? '✓' : '✗';
    lines.push(`  ${icon} ${c.name}: ${c.detail}`);
  }
  if (!doctor.allPass) {
    lines.push('');
    lines.push('⚠️  Some checks failed. Fix the issues above for optimal SEVO operation.');
  }

  // Step 6: Quick-start guide (AC-4.94)
  lines.push('');
  lines.push('── Next Steps ──');
  lines.push('');
  lines.push('  1. Review agent role assignments above. To override, add `"role": "<role>"` to the agent entry in openclaw.json.');
  lines.push('  2. Create your first pipeline:  sevo:create <project-slug> "task description"');
  lines.push('  3. Check pipeline status:       sevo:status');
  lines.push('  4. Run diagnostics:             sevo:doctor');
  lines.push('');
  lines.push(`[SEVO Init] Setup complete. ${pool._isSingleAgent ? 'Running in Single-Agent Mode.' : `${env.agentCount} agents configured.`}`);

  return {
    content: lines.join('\n'),
    success: true,
    isSingleAgent: pool._isSingleAgent,
    agentCount: env.agentCount,
    assignments,
    doctorPass: doctor.allPass,
  };
}

export { handleSevoInit, detectEnvironment, recommendRole, runDoctorCheck };
