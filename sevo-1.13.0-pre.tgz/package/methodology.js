/**
 * SEVO Methodology — stage-specific methodology prompts.
 * Each function returns string[] for spread-injection into task prompts.
 */

export function specMethodology() {
  return [
    '',
    '## SEVO Spec Methodology',
    'Apply critical thinking to every requirement:',
    '- State assumptions explicitly. If multiple interpretations exist, present them — don\'t pick silently.',
    '- Use first-principles reasoning: what problem does this solve? For whom? What\'s the simplest framing?',
    '- Define conceptual architecture (core object types, processing pipeline, evolution mechanisms) — no tech choices.',
    '- Phase isolation: NO tech stack, NO data models, NO API frameworks, NO implementation details.',
    '  Allowed: "needs persistent storage" / "needs vector search" / "needs Web UI" — never name specific tech.',
    '- Honestly expose blind spots: mark unknowns as open questions, don\'t paper over gaps.',
    '- For each FR: define testable acceptance criteria with verification steps.',
    '- NFR: one line per item with quantifiable metric (e.g., "p95 latency < 200ms").',
    '- Success metrics: max 3, each measurable.',
    '- No revision traces, no AI boilerplate, no redundant descriptions — every line serves the reader.',
  ];
}

export function contractMethodology() {
  return [
    '',
    '## SEVO Contract Methodology (arc42 + ADR)',
    'Phase isolation: this is the ONLY phase for tech choices. Every selection needs an ADR.',
    'arc42 structure (mandatory chapters):',
    '- Context & Scope, Solution Strategy, Building Block View, Runtime View, Deployment View.',
    '- Cross-cutting: security, error handling, logging, i18n.',
    'ADR discipline:',
    '- Each ADR: Context (why decide now) → Decision (what + alternatives considered) → Consequences (tradeoffs accepted).',
    '- Cover: tech stack, storage, architecture pattern, integration strategy.',
    'Gate Check (7 items — all must pass):',
    '1. FR coverage: every FR has a corresponding component.',
    '2. NFR coverage: every NFR has an architectural solution.',
    '3. Decision completeness: key tech choices all have ADRs.',
    '4. Risk identification: known risks and tech debt documented.',
    '5. Consistency: spec → architecture traceability intact.',
    '6. Phase isolation: spec (Phase 1) contains no tech choices or data models.',
    '7. Concept-tech alignment: conceptual architecture maps to technical implementation.',
  ];
}

export function specReviewGateMethodology() {
  return [
    '',
    '## SEVO Review Gate Methodology (Divergent Validation)',
    'Apply 8-dimension divergent review:',
    '1. Requirement blind spots — missing features, scenarios, user stories.',
    '2. Contradictions — internal or cross-document logic conflicts.',
    '3. Feasibility risks — technically, resource, or timeline infeasible items.',
    '4. UX blind spots — unconsidered user paths, edge cases, accessibility.',
    '5. Priority challenges — unjustified or missing priority rationale.',
    '6. Missing NFRs — overlooked performance, security, observability requirements.',
    '7. Deliverable completeness — are all promised deliverables verifiable?',
    '8. External user perspective (stranger test):',
    '   a. Persona defined? — spec must define at least one "never-seen-this-product" persona.',
    '   b. Install / configure / first-use path — spec must have FRs covering discover → install → first success. Missing any stage = P0.',
    '   c. Prerequisites explicit? — every tool, runtime, env var, or config the user needs must be listed. Implicit assumptions (e.g., "user already has Claude Code") = P0.',
    '   d. Error guidance FRs? — when the user hits a failure, is there a corresponding FR for actionable error messages or recovery steps? Missing = P1.',
    '9. User experience flow completeness — does the spec cover the full lifecycle from discover → install → first-use → core-flow → error-recovery → upgrade? Gaps in any stage = P0 block.',
    '10. FR-Code alignment (前置守卫) — spec 中是否有 FR 在当前代码中完全没有对应实现？如果 spec 描述的功能在代码库中找不到任何对应代码、文件或模块，标记为 P1。这是终局收敛的前置检查，越早发现 spec-代码不对齐越好。',
    'Each finding: P0 (blocking) / P1 (important) / P2 (suggestion).',
    'Cross-audit principle: reviewer must NOT be the author. Evaluate independently.',
    'Conclusion: passed / conditional (list blockers) / rejected (list blocking issues).',
  ];
}

export function contractReviewGateMethodology() {
  return [
    '',
    '## SEVO Contract Review Gate Methodology (Tripartite Audit)',
    'Three independent perspectives required:',
    '- Product (pm): spec-architecture alignment, user story coverage, no scope creep.',
    '- Development (coder): implementation feasibility, module decomposition, tech debt risk.',
    '- Quality (auditor): ADR completeness (alternatives + tradeoffs), arc42 chapter coverage, testability, Wave 1 standalone viability.',
    'Apply 7-dimension divergent review (same as spec-review-gate).',
    'Synthesize all perspectives into a single verdict with evidence.',
  ];
}

export function reviewMethodology() {
  return [
    '',
    '## SEVO Review Methodology (Security + Quality)',
    'Git diff-aware review: focus ONLY on changes introduced, not pre-existing issues.',
    'Security categories (OWASP Top 10:2025):',
    '- A01 Broken Access Control: deny by default, server-side enforcement, ownership verification.',
    '- A02 Misconfiguration: hardened configs, disabled defaults.',
    '- A03 Supply Chain: locked versions, integrity verification.',
    '- A04 Crypto Failures: TLS 1.2+, AES-256-GCM, Argon2/bcrypt.',
    '- A05 Injection: parameterized queries, input validation, safe APIs.',
    '- A06 Insecure Design: threat model, rate limiting.',
    '- A07 Auth Failures: MFA, breached password checks, secure sessions.',
    '- A08 Integrity Failures: signed packages, SRI, safe serialization.',
    '- A09 Logging Failures: log security events, structured format.',
    '- A10 Exception Handling: fail-closed, hide internals.',
    'Confidence threshold: only flag issues with >80% exploitability confidence.',
    'Severity: CRITICAL / HIGH / MEDIUM / LOW.',
    'Also check: spec compliance, code quality, test coverage.',
  ];
}

export function implementMethodology() {
  return [
    '',
    '## SEVO Implement Methodology',
    'Surgical Changes: touch only what the spec requires. No adjacent "improvements".',
    'Simplicity First: minimum code that solves the problem. No speculative features, no premature abstractions.',
    '  If 200 lines could be 50, rewrite it.',
    'Goal-Driven Execution: define verifiable success criteria before coding.',
    '  Transform each FR/AC into a concrete check. Loop until verified.',
    'Match existing code style. Remove only what YOUR changes made unused.',
    'Every changed line must trace to a spec requirement.',
    'TDD Cycle (mandatory): write a failing test first → implement until it passes → refactor → confirm all tests green.',
    'Before declaring implementation complete, self-check test coverage: every FR/AC must have at least one corresponding test. Uncovered items must be supplemented before moving on.',
  ];
}

export function testCaseAuthoringMethodology() {
  return [
    '',
    '## SEVO Test Case Authoring Methodology',
    'Coverage rule: at least one test case per acceptance criterion (AC).',
    'For each test case specify: precondition, test steps, expected result, priority.',
    'Include boundary value tests for numeric/string inputs.',
    'Include negative/exception path tests (invalid input, unauthorized access, timeout).',
    'Include integration tests for cross-component interactions.',
    'Priority: P0 (blocks release) / P1 (important) / P2 (nice-to-have).',
  ];
}

export function getUserJourneyTemplate() {
  return {
    stages: [
      { id: 'discover', name: '发现与获取', questions: ['用户从哪里找到这个产品？', '获取方式是什么？(git clone / npm install / download)', '获取过程有没有障碍？'] },
      { id: 'install', name: '安装与配置', questions: ['安装步骤是什么？能一条命令完成吗？', '需要哪些前置依赖？', '配置项有默认值吗？零配置能跑吗？'] },
      { id: 'first-use', name: '首次使用', questions: ['用户第一次用的时候做什么？', '5分钟内能看到第一个成功结果吗？', '首次使用有引导吗？'] },
      { id: 'core-flow', name: '核心流程', questions: ['主要功能的完整使用流程是什么？', '每一步用户看到什么、做什么？', '有没有断点或卡点？'] },
      { id: 'error-recovery', name: '错误恢复', questions: ['出错时用户看到什么？', '错误信息能指导用户修复吗？', '有没有自动恢复机制？'] },
      { id: 'upgrade', name: '升级与维护', questions: ['怎么升级到新版本？', '升级会不会破坏已有配置？', '有没有迁移指南？'] }
    ],
    format: '每个阶段必须回答所有问题。回答不了 = 产品在这个环节有盲区。'
  };
}

export function smokeTestMethodology() {
  return [
    '',
    '## SEVO Smoke Test Methodology',
    'Execute from a real user perspective — not unit tests, but end-to-end flows.',
    'Cover the golden path first, then critical edge cases.',
    'For each AC: verify the actual system behavior matches the expected result.',
    'Attach evidence: command output, screenshots, or API responses.',
    'Independent verifier: smoke tester must NOT be the implementer.',
    'For projects with a Web UI: browser screenshots are MANDATORY verification evidence. Capture key screens and attach file paths in the report.',
    'Failure blocks all subsequent stages — fix and re-run until pass.',
  ];
}

export function strangerDryRunMethodology() {
  return [
    '',
    '## SEVO Stranger Dry-Run Gate Methodology (FR-V09)',
    'Simulate a first-time user who has NEVER seen this project. Execute a 4-dimension walkthrough:',
    '',
    '### Dimension 1: clone/install',
    '- Is the git clone URL correct and accessible?',
    '- Do dependencies install with a single command (no manual steps)?',
    '- Are all system prerequisites (runtime, tools, env vars) explicitly documented?',
    '- Any missing prerequisite or broken install step = P0.',
    '',
    '### Dimension 2: first-use',
    '- Is the first command clearly documented in README?',
    '- Does it run without error on a clean environment?',
    '- Does the user see a meaningful result within 5 minutes?',
    '- Any step where a stranger gets stuck with no guidance = P0.',
    '',
    '### Dimension 3: core-flow',
    '- Is every documented workflow step actually executable?',
    '- Are there undocumented manual steps or implicit assumptions?',
    '- Are there hardcoded paths, internal references, or environment-specific values?',
    '- Any broken or undocumented step in the core flow = P0.',
    '',
    '### Dimension 4: error-handling',
    '- Do error messages tell the user what went wrong and how to fix it?',
    '- Are recovery steps documented for common failure modes?',
    '- Is there guidance for "what to do when X fails"?',
    '- Missing error guidance for critical paths = P1.',
    '',
    'Severity: P0 (stranger cannot complete the step) / P1 (can complete but poor experience) / P2 (suggestion).',
    'P0 in any dimension = stage verdict FAIL, blocks subsequent stages.',
    'Report must be written to reports/ directory with per-dimension results.',
  ];
}
