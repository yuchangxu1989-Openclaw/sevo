/**
 * FR-22: Role Constraint Template Injection.
 *
 * Provides default SEVO role templates (SOUL.md § SEVO Role) for agents
 * that lack one.  Templates describe pipeline responsibilities only —
 * no generic behaviour constraints, no KIVO content.
 *
 * Extensible: add entries to ROLE_TEMPLATES without touching core code (AC-4.84).
 */

import fs from 'fs';
import path from 'path';

const OPENCLAW_ROOT = process.env.OPENCLAW_HOME || path.resolve(
  path.dirname(new URL(import.meta.url).pathname), '../..',
);

// ── Role Template Library (AC-4.82: pm / architecture / review / coding / ux) ──

const ROLE_TEMPLATES = {
  pm: {
    title: 'Product Manager',
    body: [
      'You own the Specify stage of the SEVO pipeline.',
      'Your job is to translate intent into verifiable requirements:',
      '- Define FRs with testable acceptance criteria.',
      '- Maintain scope boundaries — explicitly mark in-scope vs out-of-scope.',
      '- Surface ambiguity early; use structured clarification questions.',
      '- Ensure every FR traces to a user outcome, not an implementation detail.',
      '- Guard phase isolation: Specify produces requirements, not tech choices.',
    ],
  },
  architecture: {
    title: 'Architect',
    body: [
      'You own the Contract stage of the SEVO pipeline.',
      'Your job is to turn requirements into a buildable architecture:',
      '- Produce arc42-structured design with ADRs for every key decision.',
      '- Ensure FR → component traceability and NFR → architectural solution mapping.',
      '- Apply constraint-before-solution thinking: define boundaries first, then fill.',
      '- Evaluate alternatives honestly — document what was rejected and why.',
      '- Guard phase isolation: Contract is the only phase for tech choices.',
    ],
  },
  review: {
    title: 'Quality Auditor',
    body: [
      'You own the Review and Regression stages of the SEVO pipeline.',
      'Your job is independent quality verification:',
      '- Audit code changes against spec and architecture — not style preferences.',
      '- Apply OWASP Top 10 security checks with >80% exploitability confidence.',
      '- Produce structured findings with severity (P0–P3) and evidence.',
      '- You do NOT write or fix code — you find and report issues.',
      '- Cross-audit principle: you must not review your own work.',
    ],
  },
  coding: {
    title: 'Developer',
    body: [
      'You own the Implement stage of the SEVO pipeline.',
      'Your job is bounded implementation within the architecture contract:',
      '- Write the minimum code that satisfies the spec — no speculative features.',
      '- Follow Surgical Changes: touch only what the task requires.',
      '- Every changed line must trace to an FR or AC.',
      '- Run tests before declaring completion; partial pass ≠ full pass.',
      '- Respect architecture boundaries — no decisions that belong in Contract.',
    ],
  },
  ux: {
    title: 'UX Verifier',
    body: [
      'You own the UX Acceptance stage of the SEVO pipeline.',
      'Your job is to verify the user experience end-to-end:',
      '- Execute the Stranger Dry-Run: can a first-time user complete the flow?',
      '- Check install → first-use → core-flow → error-recovery lifecycle.',
      '- Verify documentation matches actual behaviour.',
      '- Report UX gaps with reproduction steps and severity.',
      '- Visual deliverables must be checked in a real browser context.',
    ],
  },
};

// ── SEVO Role Section Marker ──

const SEVO_SECTION_START = '## SEVO Role';
const SEVO_SECTION_RE = /^## SEVO Role\b/m;

/**
 * Build the SEVO Role section content for a given role.
 */
function buildSevoSection(role) {
  const tpl = ROLE_TEMPLATES[role];
  if (!tpl) return null;
  const lines = [
    SEVO_SECTION_START,
    '',
    `**Pipeline Role**: ${tpl.title}`,
    '',
    ...tpl.body.map(l => l),
    '',
  ];
  return lines.join('\n');
}

/**
 * Resolve the SOUL.md path for an agent.
 */
function soulPath(agentId) {
  return path.join(OPENCLAW_ROOT, 'agents', agentId, 'agent', 'SOUL.md');
}

/**
 * Inject SEVO Role section into an agent's SOUL.md.
 *
 * - If SOUL.md does not exist → create with SEVO Role section only.
 * - If SOUL.md exists but has no `## SEVO Role` → append section.
 * - If SOUL.md exists and already has `## SEVO Role` → skip (AC-4.81).
 *
 * Returns { action: 'created' | 'appended' | 'skipped', path: string }
 */
function injectRoleTemplate(agentId, role) {
  const sevoSection = buildSevoSection(role);
  if (!sevoSection) return { action: 'skipped', path: null, reason: `unknown role: ${role}` };

  const filePath = soulPath(agentId);
  const dir = path.dirname(filePath);

  let existing = null;
  try {
    existing = fs.readFileSync(filePath, 'utf8');
  } catch { /* file does not exist */ }

  if (existing !== null) {
    // AC-4.81: already has SEVO Role section → skip
    if (SEVO_SECTION_RE.test(existing)) {
      return { action: 'skipped', path: filePath, reason: 'SEVO Role section already exists' };
    }
    // Append SEVO Role section
    const separator = existing.endsWith('\n') ? '\n' : '\n\n';
    fs.writeFileSync(filePath, existing + separator + sevoSection + '\n', 'utf8');
    return { action: 'appended', path: filePath };
  }

  // Create new SOUL.md with SEVO Role section
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* exists */ }
  fs.writeFileSync(filePath, sevoSection + '\n', 'utf8');
  return { action: 'created', path: filePath };
}

/**
 * Inject SEVO Role templates for all agents in a role pool.
 *
 * @param {Object} agentPool — output of discoverAgents() from task-mapper.js
 * @returns {Object[]} results per agent
 */
function injectAllRoleTemplates(agentPool) {
  const results = [];
  for (const role of Object.keys(ROLE_TEMPLATES)) {
    const agents = agentPool[role] || [];
    for (const agentId of agents) {
      try {
        const r = injectRoleTemplate(agentId, role);
        results.push({ agentId, role, ...r });
      } catch (err) {
        results.push({ agentId, role, action: 'error', error: err.message });
      }
    }
  }
  return results;
}

/**
 * Get available role names (AC-4.84: extensible without code changes
 * by adding to ROLE_TEMPLATES).
 */
function getAvailableRoles() {
  return Object.keys(ROLE_TEMPLATES);
}

export {
  ROLE_TEMPLATES,
  buildSevoSection,
  injectRoleTemplate,
  injectAllRoleTemplates,
  getAvailableRoles,
  soulPath,
};
