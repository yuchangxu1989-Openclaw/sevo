import fs from 'fs';
import path from 'path';

const PLUGIN_DIR = path.dirname(new URL(import.meta.url).pathname);
const STATE_CONFIG_PATH = path.join(PLUGIN_DIR, 'state', 'config.json');

export function normalizePlainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

export function readStateConfig() {
  try {
    return normalizePlainObject(JSON.parse(fs.readFileSync(STATE_CONFIG_PATH, 'utf8')));
  } catch {
    return {};
  }
}

export function resolveConfiguredPath(basePath, candidate, fallback) {
  if (typeof candidate !== 'string' || candidate.trim() === '') {
    return fallback;
  }
  return path.isAbsolute(candidate)
    ? candidate
    : path.resolve(basePath, candidate);
}

const DEFAULT_HOST_CONFIG = {
  workspaceRoot: process.env.OPENCLAW_WORKSPACE_ROOT || path.resolve(PLUGIN_DIR, '../../workspace'),
  specPattern: 'docs/design/product-requirements.md',
  logsDir: 'logs',
  eventsFile: 'sevo-pipeline-events.jsonl',
  progressFile: 'sevo-progress.json',
  agentsListKey: 'agents',
  agentsConfigPath: null,
};

export function resolveHostConfig(pluginConfig) {
  const config = { ...DEFAULT_HOST_CONFIG, ...normalizePlainObject(pluginConfig), ...readStateConfig() };

  const basePath = config.workspaceRoot || DEFAULT_HOST_CONFIG.workspaceRoot;

  return {
    workspaceRoot: resolveConfiguredPath(PLUGIN_DIR, config.workspaceRoot, DEFAULT_HOST_CONFIG.workspaceRoot),
    specFilePath: path.join(basePath, config.specPattern),
    logsPath: path.join(basePath, config.logsDir),
    eventsPath: path.join(basePath, config.logsDir, config.eventsFile),
    progressPath: path.join(basePath, config.logsDir, config.progressFile),
    agents: config.agentsListKey ? (config[config.agentsListKey] ?? null) : null,
    agentIdsSource: config.agentsConfigPath
      ? path.join(basePath, config.agentsConfigPath)
      : null,
  };
}
